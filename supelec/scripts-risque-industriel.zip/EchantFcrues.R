#########################################################################
#
# Auteur : Bertrand Iooss (CEA)
#
# Fichier : EchantFcrues.R
# Date : 2012
#
# Description de la fonction :
# Cette fonction genere un échantillon pour l'exemple de la crue de taille N.
#
# - X[1] = Q débit (en m3/s), distribuée selon une loi gumbel max tronquee (loc=1013,scale=558,min=500,max=3000) ;
# - X[2] = Ks coefficient de Strickler, distribué selon une loi normale tronquee (30,8,min=15) ;
# - X[3] = Zv cote (en m) du fond du cours d'eau en aval du tronçon (en m NGF), de loi triangulaire (50,+-1) ;
# - X[4] = Zm cote (en m) du fond du cours d'eau en amont du tronçon (en m NGF), de loi triangulaire (55,+-1) ;
# - X[5] = Hd (en m) hauteur de la digue, de loi uniforme (7,9) ;
# - X[6] = Cb (en m) cote de la berge, de loi triangulaire (55.5,+-0.5) ;
# - X[7] = L (en m) longueur du troncon d'eau etudie, de loi triangulaire (5000,+-10) ;
# - X[8] = B (en m) largeur du cours d'eau, de loi triangulaire (300,+-5) 
#
# Ces 8 variables sont supposées indépendantes d'un point de vue statistique.
#
# Entrées de la fonction :
# - taille = taille de l'échantillon
#
# Description des réponses : 
# - X = matrice de taille N x 8
#
#########################################################################

library(evd)          # Loi Gumbel
library(triangle)     # Loi triangulaire
source("truncated.R") # Quelques lois tronquees

EchantFcrues <- function(taille){

	X = matrix(NA,taille,8)

	X[,1] = rtgumbel(taille,loc=1013.0,scale=555.0,min=500,max=3000)
	X[,2] = rtnorm(taille,mean=30.0,sd=8,min=15.);
	X[,3] = rtriangle(taille,a=49,b=51,c=50);
	X[,4] = rtriangle(taille,a=54,b=56,c=55);
	X[,5] = runif(taille,min=7,max=9);
	X[,6] = rtriangle(taille,a=55,b=56,c=55.5);
	X[,7] = rtriangle(taille,a=4990,b=5010,c=5000);
	X[,8] = rtriangle(taille,a=295,b=305,c=300);

	return(X)

}#end function

