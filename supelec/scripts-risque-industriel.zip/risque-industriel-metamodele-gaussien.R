#======================================================|
#|          Quantification des Incertitudes            | 
#|          dans les Simulation Numériques             |
#|_____________________________________________________|
#|      Plans d'expriences et métamodèle PG            |
#|_____________________________________________________|
#======================================================|

rm(list=ls())    # efface tout
graphics.off()# ferme tous les graphes

#|-----------------------------------------------------------------------------------|
#| Chargement des packages et de fonctions                                           |
#|-----------------------------------------------------------------------------------|
library(evd)             # Pour avoir loi Gumbel
library(triangle)        # Pour avoir la loi triangulaire
library(sensitivity)     # méthodes d'analyes de sensibilité
library(iplots)          # graphe interectif pour analyse graphique
library(randtoolbox)


source("truncated.R")    # Definit quelques lois tronquees
source("Fcrues.R")       # Fonction de calcul des 2 sorties : la surverse S et le coût C
source("EchantFcrues.R") # Fonction d'échantillonnage des entrées de la fonction Fcrues



#######################################################
# --------------------------------------------------- #
#  1.   criblage - méthode de Morris                  #
# --------------------------------------------------- #
#######################################################
# bien qu'on ne soit pas en grande dimension et que notre problème ne nécessite pas 
# vraiment de faire un analyse des sensibilité qualitative (criblage), il est 
# intéressant de comprendre l'utilisation de la méthode de Morris


d = 8 # nombre de paramètres d'entrées
names = c("Q","Ks","Zv","Zm","Hd","Cb","L","B") 

# pour le cribalge, seules les bornes inf et sup son nécessaires
# Valeurs minimales et maximales
# pour la borne sup de Ks , on prend le quantile à  95% (-> correspond à 43.3)
binf=c(500,15,49,54,7,55,4990,295)
bsup=c(3000,43.3,51,56,9,56,5010,305)

#_____________________________________________________
# 1.1 Méthode de Morris pour la surverse S        
#_____________________________________________________
?morris

morS = morris(model=Fcrues,ans=1,factors=names,design=list(type="oat",levels=4,grid.jump=1),r=10,
              binf=binf,bsup=bsup,scale = TRUE)

plot(morS,col=rainbow(8))   # on pourra utiliser l'option xlim = c(inf, sup)  pour une meilleure viualisation
# paramètre non influents : B, L  (et éventuellement Zm et Cb)
# paramètre influents: 1) linéairement : Hd 
#                      2) non linéairement ou avec intéraction : Ks, Q, Zv                          


# variations des options : 
morS = morris(model=Fcrues,ans=1,factors=names,design=list(type="oat",levels=6,grid.jump=2),r=15,
              binf=binf,bsup=bsup,scale = TRUE)

plot(morS,col=rainbow(8))   # on pourra utiliser l'option xlim = c(inf, sup) pour une meilleure viualisation

#_____________________________________________________
# 1.2 Méthode de Morris pour le coût C      
#_____________________________________________________

morC = morris(model=Fcrues,ans=2,factors=names,design=list(type="oat",levels=4,grid.jump=1),r=10,
               binf=binf,bsup=bsup,scale = TRUE)

plot(morC,col=rainbow(8))
# paramètre non influents : B, L  (et éventuellement Zm et Cb)
# paramètre influents: 1) linéairement : aucun
#                      2) non linéairement ou avec intéraction : Ks, Q, Zv, Hd   

morCp = morris(model=Fcrues,ans=2,factors=names,design=list(type="oat",levels=6,grid.jump=2),r=15,
               binf=binf,bsup=bsup,scale = TRUE)

plot(morCp,col=rainbow(8))

#######################################################
# --------------------------------------------------- #
#  2.   Analyse graphique                             #
# --------------------------------------------------- #
#######################################################

#_____________________________________________________
# 2.1 On construit l'échantillon      
#_____________________________________________________

N = 200
print("")
print(c("Taille de l'echantillon MC = ",N))

x = EchantFcrues(N)	# création de l'échantillon
colnames(x) = names
S = Fcrues(x,ans = 1) # reponse Surverse du modele
Ct = Fcrues(x, ans = 2) # reponse Coût  du modele

#_____________________________________________________
# 2.2 Graphes de S en fonction de chaque paramètre (scatterplot)    
#_____________________________________________________

par(mfcol=c(2,4))
for (i in 1:d){
  plot(x[,i],S, main=names[i])
  lines(lowess(x[,i],S), col = 2, lty = 2, lwd = 2)
}
# influent au premier ordre :  Q, Zv, Hd, Ks
# on ne peut rien dire sur les autres 
#(peut-être leurs interactions jouent-t-elles, on ne peut pas le savoir avec ce graphe)

#_____________________________________________________
# 2.3 Graphes dit "cobweb plot' de S et de chaque paramètre     
#_____________________________________________________

ipcp(data.frame(cbind(x,S)))
# en sélectionnant les valeurs hautes de S (les valeurs basses), on peut voir que : 
# les valuers hautes de Q contribuent plutôt aux valeurs hautes de S
# les valeurs basses de Hd contribuent plutôt aux valeurs hautes de S


#_____________________________________________________
# 2.4 Pour le coût
#_____________________________________________________

par(mfcol=c(2,4))
for (i in 1:d){
  plot(x[,i],Ct, main=names[i])
  lines(lowess(x[,i],Ct), col = 2, lty = 2, lwd = 2)
}
# influent au premier ordre :  Q, Zv, Hd, Ks
# on ne peut rien dire sur les autres 

ipcp(data.frame(cbind(x,Ct)))
# en sélectionnant les valeurs hautes de S (les valeurs basses), on peut voir que : 
# les valuers hautes de Q contribuent plutôt aux valeurs hautes de Ct
# les valeurs basses de Hd contribuent plutôt aux valeurs hautes de Ct
# les valeurs hautes de Zv contribuent plutôt aux valeurs hautes de Ct



#######################################################
# --------------------------------------------------- #
#  3.   Indices de sensibilité linéaires              #
# --------------------------------------------------- #
#######################################################

#_____________________________________________________
# 3.1 Pour quelles réponses ces indices sont appropriés ?
#_____________________________________________________
# Rappel rapide des TP précédents : 
formule = as.formula(z~ Q + Ks + Zv + Zm + Hd + Cb + L + B)

# régression linéaire pour S
lm_S <- lm(formule,data=data.frame(x,z=S))
summary(lm_S)
# un modèle linéaire est correct pour S (voire bien)
# on valide ce modèle linaire (on avait fait du LOO dans TP précédent)

# régression linéaire pour Ct
lm_Ct <- lm(formule,data=data.frame(x,z=Ct))
summary(lm_Ct)
# un modèle linéaire est mauvais pour Ct 
# on ne valide pas ce modèle linaire (on avait fait du LOO dans TP précédent)

# -> on ne peut utiliser les indices de sensibilité liéaires que pour S,
# ces indices sont inappropriés pour Ct

#_____________________________________________________
# 3.2 indices linéaires pour S
#_____________________________________________________
?src
SRC_S = src(x,S)
print("coefficients de régression standard :")
print(SRC_S$SRC)

# les src^2 pour S
SRC2_S = SRC_S$SRC^2
print("Indices de sensibilité linéaire :")
print(SRC2_S)

par(mfcol=c(1,1))
barplot(t(SRC2_S))
# paramètre influents: Q, Ks, Zv, Hd (et un peu Cb)


#######################################################
# --------------------------------------------------- #
#  4.   Indices de Sobol                              #
# --------------------------------------------------- #
#######################################################

# L'estimation des indices de Sobol s'est considérablement améliorée
# nous allons utiliser une des première méthode jusqu'au plus performante
# afin de voir le gain en précision

#_____________________________________________________
# 4.1 indices de Sobol avec sobol2002, n=1e4
#_____________________________________________________
n = 1e4 

# création des deux échantillons pour le calcul des indices de Sobol (voir slide 48 du cours)
xs1 = EchantFcrues(n)
xs2 = EchantFcrues(n)
colnames(xs1) = colnames(xs2) = names

# calcul pour S
sob_S = sobol2002(model = Fcrues, ans=1, X1 = xs1, X2 = xs2, nboot=100)
print(sob_S)
plot(sob_S)

# calcul pour Ct
sob_Ct = sobol2002(model = Fcrues, ans=2, X1 = xs1, X2 = xs2, nboot=100)
print(sob_Ct)
plot(sob_Ct)

# Avec 1e4*(d+2) (voir slide 48 du cours) appels au modèle crues (le code de calcul), 
# les indices de sobol de sont pas estimés assez précisement

# les IC des indices de sobol sont approchés par bootstratp (d'où le nboot = 100)

#_____________________________________________________
# 4.2 indices de Sobol avec sobol2002, n=1e5
#_____________________________________________________
n = 1e5 

# création des deux échantillons pour le calcul des indices de Sobol (voir slide 48 du cours)
xs1 = EchantFcrues(n)
xs2 = EchantFcrues(n)
colnames(xs1) = colnames(xs2) = names

# calcul pour S
sob_S = sobol2002(model = Fcrues, ans=1, X1 = xs1, X2 = xs2, nboot=100)


print(sob_S)
plot(sob_S)

# calcul pour Ct
sob_Ct = sobol2002(model = Fcrues, ans=2, X1 = xs1, X2 = xs2, nboot=100)
print(sob_Ct)
plot(sob_Ct)

# Même avec 1e5*(d+2) (voir slide 48 du cours) appels au modèle crues (le code de calcul), 
# les indices de sobol de sont pas estimés assez précisement

#_____________________________________________________
# 4.3 Interprétation
#_____________________________________________________
# S : influents (dans l'ordre) Q Hd Zv Ks Cb , interactions ?  non ! 
# Ct : influents (dans l'ordre) Q Zv Ks Hd Cb , interactions ? oui ! 
# mais la précision des estimations est très moyenne pour Ct


#_____________________________________________________
# 4.4 indices de Sobol avec sobol2007, n=1e5
#_____________________________________________________
# on utilise les les mêmes échantillons qu'avant

# calcul pour S
sob_S = sobol2007(model = Fcrues, ans=1, X1 = xs1, X2 = xs2, nboot=100)
print(sob_S)
plot(sob_S)

# calcul pour Ct
sob_Ct = sobol2007(model = Fcrues, ans=2, X1 = xs1, X2 = xs2, nboot=100)
print(sob_Ct)
plot(sob_Ct)

# légère amélioration de la précision, mais toujours pas assez précis pour Ct

#_____________________________________________________
# 4.4 indices de Sobol avec soboljansen, n=1e5
#_____________________________________________________

# calcul pour S
sob_S = soboljansen(model = Fcrues, ans=1, X1 = xs1, X2 = xs2, nboot=100)
print(sob_S)
plot(sob_S)

# calcul pour Ct
sob_Ct = soboljansen(model = Fcrues, ans=2, X1 = xs1, X2 = xs2, nboot=100)
print(sob_Ct)
plot(sob_Ct)

# estimations très précises
# on peut essaayer avec n=1e4 pour voir...

# Interprétationplus sûre :
# S : influents (dans l'ordre) Q Hd Zv Ks Cb , interactions ?  non ! 
# Ct : influents (dans l'ordre) Q Zv Ks Hd Cb , interactions ? oui  (pour Q, Ks, Zv et Hd) 

#_____________________________________________________
# 4.5 indices de Sobol avec métamodèle
#_____________________________________________________
# on reprend le métamodèle processus gaussien du TP précédent pour le cout : 

# plans d'expériences 
X = read.table('PEoptimise_n100_d8.dat') # le plan d'expériences exploratoire
X = as.matrix(X)
colnames(X) = names
C = Fcrues(X,ans=2) # le coût aux points du plan

# métamodélisation par processus gaussien
formule <- as.formula(z~ Q + Ks + Zv + Zm + Hd + Cb + L + B) # la tendance du PG
modelePG.C <- km(formula=formule,design=X,response=C)

# validation LOO
LOO.GP.C = leaveOneOut.km(modelePG.C , type="UK", trend.reestim=FALSE)
Q2.LOO.GP.C = 1- mean((C-LOO.GP.C$mean)^2)/var(C)
Q2.LOO.GP.C # prediction bonnes
err.VC.GP.C = mean((LOO.GP.C$mean-C)^2/LOO.GP.C$sd^2)
err.VC.GP.C  # variance correctement calibrée
# => métamodèle validé

# analyse de sensibilité avec le métamodèle (directement)
n = 1e4 

# création des deux échantillons pour le calcul des indices de Sobol 
xs1 = EchantFcrues(n)
xs2 = EchantFcrues(n)
colnames(xs1) = colnames(xs2) = names

sob_C = soboljansen(model = NULL, xs1, xs2, nboot = 100)
X_sob = sob_C$X # extraction du plan pour le calcul des indices de Sobol
#Prediction du métamodèle aux points X_sob : 
C_sob = predict(modelePG.C,newdata=data.frame(X_sob),type="UK")$mean
res_sob.C = tell(sob_C,C_sob) # calcul des indices de Sobol 

plot(res_sob.C)

# On se rend compte que l'on ne tient pas compte de l'erreur de métamodélisation,
# on va la prendre en compte en utilisant la fonction sobolGP,
# cette fonction calcule les indices de Sobol à partir de plusieurs réalisation du PG conditionné
# (et non à partir de la moyenne), on se retrouve  avec un échantillon d'indices de Sobol
# à partir duquel on peut établir des IC sur l'estimation des indices due à l'erreur de métamodélisation
# on peut alors distinguer, dans l'estimation des indices, l'erreur due à l'estimation
# Monte Carlo des indices et celle due à la métamodélisation
# attention, le calcul peut être long !

res_sob_err.C = sobolGP(modelePG.C, type='UK', MCmethod='soboljansen',xs1,xs2,nsim=100,conf=0.95,nboot=100) 
plot(res_sob_err.C)

# Les indices  sont moins précis qu'avant, ils tiennent compte de l'erreur 
# de métamodélisation en plus de l'erreur d'estimation.



