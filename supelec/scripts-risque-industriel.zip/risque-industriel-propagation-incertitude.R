#======================================================|
#|          Quantification des Incertitudes            | 
#|          dans les Simulation Numériques             |
#|_____________________________________________________|
#|      Propagation d'incertitudes                     |
#|_____________________________________________________|
#======================================================|

## On efface toutes les données
rm(list=ls(all=TRUE))


## LIBRAIRIES
## ----------
library(evd)          # Pour avoir loi Gumbel
library(triangle)     # Pour avoir la loi triangulaire
library(ADGofTest)    # pour tests statistiques
library(moments)      # pour le calcul du skewness et du kurtosis
library(boot)         # Pour la méthode du Bootstarp

# fonctions   untilisées
source("truncated.R")  # Definit quelques lois tronquees (loi normale tronquée par exemple), 
# il existe égalment un package

#------------------------------------------------------------------------------#
# Chargement des fonctions du cas "crues"
source("Fcrues.R")
source("EchantFcrues.R")
#------------------------------------------------------------------------------#


#######################################################
# --------------------------------------------------- #
#  1.   Le modèle CRUE                                #
# --------------------------------------------------- #
#######################################################

# Tester les fonctions Fcrues() et EchantFcrues()

# Exemple d'utilisation de EchantFcrues(n)
n = 10
x =  EchantFcrues(n)
summary(x)


# Exemple d'utilisation de Fcrues(x) 
out = Fcrues(x)  # évaluation des 2 réponses
out1 = Fcrues(x,ans=1)  # évaluation de la surverse uniquement
out2 = Fcrues(x,ans=2)  # évaluation du cout uniquement


#######################################################
# --------------------------------------------------- #
#  2.   Tendance centrale                             #
# --------------------------------------------------- #
#######################################################

# Initialisation de la graine du générateur aléatoire (reproductibilite des resultats)
set.seed(12345)     # on fixe la graine

 
## -----------------------------------------------------
## 2.1- 
## -----------------------------------------------------

# génération de  150 réalisations i.id. des paramètres d'entrée
n = 150
X = EchantFcrues(n)   
# on nomme les colonnes de X, on aurait pû faire cela directement dans la fontion EchantFcrues()
colnames(X) = c('Q','Ks','Zv','Zm','Hd','Cb','L','B')   
d = dim(X)[2] # nombre de colonnes de X = nb de paramètres d'entrée

# histogramme
?hist  # -> on regarde toujours comment marche une fonction

par(mfcol=c(2,4)) # partage de la fenêtre graphique 2 lignes et 4 colonnes
for (k in 1:d){
hist(X[,k],prob=T,main=paste('Histogramme de', colnames(X)[k]))
lines(density(X[,k]),col=2)}

# scatterplot
?pairs
pairs(X)

# pour afficher l'histogramme sur la diagonale (trouvé dans l'aide de la fonction pairs() ) 
panel.hist <- function(x, ...){
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, plot = FALSE)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    rect(breaks[-nB], 0, breaks[-1], y, col = "lightblue", ...)}
pairs(X, diag.panel=panel.hist)


## -----------------------------------------------------
## 2.2- 
## -----------------------------------------------------

# propagation des incertitudes, réponse surverse
S = Fcrues(X,ans=1)

# résumé de S
summary(S)

## -----------------------------------------------------
## 2.3- 
## -----------------------------------------------------

# histogramme de la réponse
?hist
par(mfcol=c(1,1)) # partage de la fenêtre graphique 1 ligne et 1 colonne
hist(S)

# plus esthétique : 
hist(S,probability=TRUE,col='lightblue',main='histogramme de la surverse')
lines(density(S),col='blue',lwd=2)

## -----------------------------------------------------
##2.4- 
## -----------------------------------------------------
#test de normalité de Shapiro-Wilk
shapiro.test(S)  # il existe de nombreux test de normalité (voir la libraririe nortest apr exemple)
# -> Normalité non rejetée !

# appréciation graphique
qqnorm(S)
qqline(S)

# test d'Anderson Darling
ad.test(S, pnorm, mean(S), sd(S))
# -> Normalité non rejetée !

## -----------------------------------------------------
## 2.5- 
## -----------------------------------------------------
# moyenne et écart-type
meanS = mean(S)
meanS
sdS = sd(S)
sdS 

# 5% de risque <-> 95% de confiance
alpha = 0.05  

# Intervalle de confiance pour la moyenne avec sigma inconnu 
# (cas gaussien ou par théorème central limite car n>30)


qt2 =   qt(1-alpha/2,n-1) # quantile  à 1-alpha/2 de la loi de Student à n-1 ddl 
IC_meanS = c( meanS - qt2*sdS/sqrt(n)  , meanS + qt2*sdS/sqrt(n)  )     #

IC_meanS

# Intervalle de confiance pour l'écart-type (cas gaussian)
# voir la formule de l'IC slide 22.

c1 =  qchisq(alpha/2,n-1)   # quantile  à alpha/2 de la loi du chi2 à n-1 ddl 
c2 = qchisq(1-alpha/2,n-1)  # quantile  à 1-alpha/2 de la loi du chi2 à n-1 ddl 

IC_sdS =  c(sqrt( (n-1)*sdS^2/c2 ),sqrt( (n-1)*sdS^2/c1 ) )
IC_sdS


## -----------------------------------------------------
## 2.6- 
## -----------------------------------------------------
# propagation des incertitudes, réponse coût
Ct = Fcrues(X,ans=2)

summary(Ct) # résumé
  
hist(Ct,probability=TRUE,col='lightblue',main='histogramme du coût')    # histogramme
lines(density(Ct),col='blue',lwd=2)

shapiro.test(Ct)# test de normalité
# -> Normalité  rejetée !

# moyenne écart-type  
meanCt = mean(Ct)
meanCt
sdCt = sd(Ct)
sdCt

alpha = 0.05  # 5% de risque <-> 95% de confiance

# Intervalle de confiance pour la moyenne avec sigma inconnu 
# (par théorème central limite car n>30)
# même formule que l'IC slide 20, mais on est dans le cas décrtit slide 23.

qt2 =   qt(1-alpha/2,n-1) # quantile  à 1-alpha/2 de la loi de Student à n-1 ddl 
IC_meanCt = c( meanCt - qt2*sdCt/sqrt(n)  , meanCt + qt2*sdCt/sqrt(n)  )     #
IC_meanCt


# écart-type et IC (cas non gaussian et asymptotique)
# même formule que l'IC slide 24

# calcul du kurtosis( librairie moments) nécessaire pour le calcul de l'IC
kurtCt = kurtosis(Ct)
 
qn2 = qnorm(1-alpha/2)     # quantile  à 1-alpha/2 de la loi N(0,1)

IC_sdCt = c( sqrt(sdCt^2 - qn2*sdCt^2*sqrt((kurtCt-1)/n)  ),  sqrt(sdCt^2 + qn2*sdCt^2*sqrt((kurtCt-1)/n)  ) )
IC_sdCt


## -----------------------------------------------------
## 2.7- 
## -----------------------------------------------------
# IC de l'écart-type par une méthode de bootstarp
 
?boot    # -> comprendre ce que faitc ette fonction !

# statistique d'intéret :  écart-type
mysd = function(x,idx){
return(sd(x[idx]) )} 
 
# replications avec remise (tout est déjà codé dans boot)
sdCt_boot = boot(data=Ct,statistic=mysd,R=1000)

# IC bootstarp
?boot.ci
boot.ci(sdCt_boot, conf = 0.95, type = "perc")

IC_sdCt_boot = boot.ci(sdCt_boot, conf = 0.95, type = "perc")$percent[4:5]
IC_sdCt_boot

# statistique d'intéret :  kurtosis
mykurt = function(x,idx){
return(kurtosis(x[idx]) )} 
 
# appeler la fonction boot:
kurtCt_boot = boot(data=Ct,statistic=mykurt,R=1000)

# les IC bootstarp sont déjà, codés, il en existe plusieurs,
# ici, on utilise celui qui se base sur les quantile de la pdf estimées par bootstarp 
# de la statisqtique d'intérêt 
# ils peuvent être plus conservateurs mais ne demandent pas d'hypothèses, sauf que B doit être  grand (au moins 500)
boot.ci(kurtCt_boot, conf = 0.95, type = "perc")

IC_kurtCt_boot = boot.ci(kurtCt_boot, conf = 0.95, type = "perc")$percent[4:5]
IC_kurtCt_boot
 

## -----------------------------------------------------
## 2.8- OPTIONNEL ( si on a le temps ) 
## -----------------------------------------------------


# on connaît la vraie valeur de la moyenne du coût (calculée sur un échantillon de très grande taille >1e7)
meanS_vrai = -10.94644 #mean(Fcrues(EchantFcrues(5e7),ans=1)  )   -> ne pas lancer (trop long !)

M = 1000# nombre de répétition 

# initiatlisatiin pour stocker les résultats
res_S = matrix(NA,nrow=M,ncol=n)
for (k in 1:M){
# nouvelle graine (indispensable ici car nous avions fixé la graine avec set.seed()   )
# si on ne fixe pas la graine, elle change à chaque fois
set.seed(sample(1e7,1))# graine aléatoire entre 1 et 1e7
X = EchantFcrues(n)       # nouvel échantillon pour chaque k
res_S[k,] = Fcrues(X,ans=1)}

# calcul des 500  moyennes et écart-type
res_meanS = apply(res_S ,1,mean) # applique aux lignes de la matrice res_Ct la fonstion mean
res_sdS = apply(res_S ,1,sd) # applique aux lignes de la matrice res_Ct la fonstion sd

# borne inf et sup de l'IC des moyennes des 500 répétitions
res_IC_meanS_inf = res_meanS - qt2*res_sdS/sqrt(n)  
res_IC_meanS_sup = res_meanS + qt2*res_sdS/sqrt(n)  

# booleen négatif si la vraie valeur n'est pas dans l'IC
ind_ICmean = ((meanS_vrai - res_IC_meanS_inf)*(res_IC_meanS_sup - meanS_vrai))<0 

taux_echec = length(which(ind_ICmean==T)) /M
taux_echec


# on en trace 150 au hasard : 

ind_sel = sample(M,150)
plot(1:150,res_meanS[ind_sel],col="white", ylab="intervalle de confiance",xlab="",
axes=T,cex.lab=1.4,ylim=c(min(res_IC_meanS_inf[ind_sel]), max(res_IC_meanS_sup[ind_sel])))
segments(1:150,res_IC_meanS_inf[ind_sel],1:150,res_IC_meanS_sup[ind_sel],
col=c("blue","red")[ind_ICmean+1][ind_sel],lwd=2) 
abline(h=meanS_vrai,lwd=2)


## -----------------------------------------------------
## 2.9- OPTIONNEL ( si on a le temps ) 
## -----------------------------------------------------

# convergence
# on va faire varier la taille n de l'échantillon et calculer 
# la moyenne, l'écart-type et IC95 de la moyenne%
meanS_cv = c()           # initialisation
sdS_cv = c()
IC_meanS_cv = c()

seqn = c(seq(20,10000,by=50))# taille de l'echantillon dans la boucle

for (k in seqn){   # boucle
Xk = EchantFcrues(k)
Sk = Fcrues(Xk,ans=1)
meanS_cv = c(meanS_cv,mean(Sk))
sdS_cv =  c(sdS_cv ,sd(Sk))
IC_meanS_cv = rbind(IC_meanS_cv ,c(mean(Sk)-qt2*sd(Sk)/sqrt(k),mean(Sk)+qt2*sd(Sk)/sqrt(k)))
}

# graphe illustratif
plot(seqn, meanS_cv,col='blue',type='l',xlab='n',ylab='estimation de m',main='estimation de la moyenne en fonction de n')
lines(seqn,IC_meanS_cv[,1],col='orange')
lines(seqn,IC_meanS_cv[,2],col='orange')
abline(h=meanS_vrai,col=1)


#######################################################
# --------------------------------------------------- #
#  3.   Quantiles                                     #
# --------------------------------------------------- #
#######################################################

# Initialisation de la graine du générateur aléatoire (reproductibilite des resultats)
set.seed(987)

 
## -----------------------------------------------------
## 3.1-) 
## -----------------------------------------------------

# génération de 200 réalisations i.id. des paramètres d'entrée
n = 300
X = EchantFcrues(n)
colnames(X) = c('Q','Ks','Zv','Zm','Hd','Cb','L','B')
d = dim(X)[2]

# propagation dans la surverse

S = Fcrues(X,ans=1)
Ct = Fcrues(X,ans=2)


## -----------------------------------------------------
## 3.2-) 
## -----------------------------------------------------
?quantile
qS95 = quantile(S,probs=0.95) # quantile empirique
qS95


## -----------------------------------------------------
## 3.3-) 
## -----------------------------------------------------
source('Wilks.quantile.R') # chargement du fichier pour que R "connaisse" la fct

# => ouvrir le fichier 'Wilks.quantile.R' (fonction codée par nos soins) pour comprendre son utilisation

# on se familiarise...
Wilks.quantile(alpha=0.95,beta=0.95,data=NULL,bilateral=TRUE)
Wilks.quantile(alpha=0.95,beta=0.99,data=rnorm(200),bilateral=FALSE)
# etc...

#  Pour la survsere
#calcul du quantile   de Wilks pour différents taux de confiance
qS95_wilks_95 = Wilks.quantile(alpha=0.95,beta=0.95,data=S,bilateral=FALSE)
qS95_wilks_95
qS95_wilks_95$upper

qS95_wilks_90 = Wilks.quantile(alpha=0.95,beta=0.90,data=S,bilateral=FALSE)
qS95_wilks_90

qS95_wilks_99 = Wilks.quantile(alpha=0.95,beta=0.99,data=S,bilateral=FALSE)
qS95_wilks_99

# graphe en plus : 
hist(S)
abline(v=qS95_wilks_95$upper,col=2,lwd=2)
abline(v=qS95 ,col=3,lwd=2)

## -----------------------------------------------------
## 3.4-) 
## -----------------------------------------------------
# taille assez grande ?
n_min_q99_95 = Wilks.quantile(alpha=0.99,beta=0.95,data=NULL,bilateral=FALSE)
n_min_q99_95


## -----------------------------------------------------
## 3.5-) 
## -----------------------------------------------------
#  Pour le coût

#calcul Intervalle de prévision avec Wilks pour différents taux de confiance

IPCtS95_wilks_90 = Wilks.quantile(alpha=0.95,beta=0.90,data=Ct,bilateral=TRUE)
IPCtS95_wilks_90

IPCtS95_wilks_95 = Wilks.quantile(alpha=0.95,beta=0.95,data=Ct,bilateral=TRUE)
IPCtS95_wilks_95

IPCtS95_wilks_99 = Wilks.quantile(alpha=0.95,beta=0.99,data=Ct,bilateral=TRUE)
IPCtS95_wilks_99


ITCt95 = quantile(Ct,probs=c(0.025,0.975))
# graphe en plus :
hist(Ct)
abline(v=c(IPCtS95_wilks_95$upper,IPCtS95_wilks_95$lower),col=2,lwd=2)
abline(v=ITCt95 ,col=3,lwd=2)


## -----------------------------------------------------
## 3.6-) 
## -----------------------------------------------------
n_min_IP99_95 = Wilks.quantile(alpha=0.99,beta=0.95,data=NULL,bilateral=TRUE)
n_min_IP99_95

n_min_IP99_90 = Wilks.quantile(alpha=0.99,beta=0.90,data=NULL,bilateral=TRUE)
n_min_IP99_90

n_min_IP99_85 = Wilks.quantile(alpha=0.99,beta=0.85,data=NULL,bilateral=TRUE)
n_min_IP99_85

n_min_IP99_80 = Wilks.quantile(alpha=0.99,beta=0.80,data=NULL,bilateral=TRUE)
n_min_IP99_80


## -----------------------------------------------------
## 3.7-) 
## -----------------------------------------------------
source('tolerance_fcts.R')
#fonctions extraites du package tolerance
# ouvrir la fct pour voir l'aide

# attention les notations dans le package tolerance  ne sont pas les mêmes que celles du cours : 
# P -> proportion spécifique : le gamma du cours, le alpha de la fct Wilks.quantile
# alpha -> le risque associé : le 1-beta du cours et la fct de Wilks.quantile

IPCtS95_Kfact_95 = normtol.int(Ct, alpha = 0.05, P = 0.95, side = 2)

# méthode  adaptée au cas  gaussien, or Ct n'est pas gaussien
# -> inadaptée ici !

# valeur du K : 
K.factor(n, alpha = 0.05, P = 0.95, side = 2)


# graphe en plus :
hist(Ct,xlim=c(as.numeric(IPCtS95_Kfact_95[4]),max(Ct)))
abline(v=c(IPCtS95_wilks_95$upper,IPCtS95_wilks_95$lower),col=2,lwd=2)
abline(v=c(IPCtS95_Kfact_95[4:5]),col=4,lwd=2)


#######################################################
# --------------------------------------------------- #
#  4. Probabilité de dépassement de seuil             #
# --------------------------------------------------- #
#######################################################

## -----------------------------------------------------
## 4.1-) 
## -----------------------------------------------------
risque_bateau <- function(x){ 
  result <- Fcrues(x,ans=1) > -7 # boolean
  return(result)
}

n = 1e4
x =  EchantFcrues(n)
Z = risque_bateau(x) 

## -----------------------------------------------------
## 4.2-) 
## -----------------------------------------------------
P =  sum(Z) / n
print(P)

## -----------------------------------------------------
## 4.3-) 
## -----------------------------------------------------
# coefficient de variation : 
# cv = écart-type de Pf / espérance de Pf
cv <- sqrt((1-P)/(n*P))*100
print(cv)

# IC :  meme formule que pour la moyenne mais avec : 
# m_n -> Pf ; sig_n -> sqrt(Pf*(1-Pf))

IC95_Pf =  c(Pf -1.96*sqrt(Pf*(1-Pf))/sqrt(n),Pf +1.96*sqrt(Pf*(1-Pf))/sqrt(n))
print(IC95_Pf)

## -----------------------------------------------------
## 4.4-) 
## -----------------------------------------------------

cvlim <- 0.01 # critère d'arrêt coefficient de variation
Nlim <- 1e8   # critère d'arrêt nombre de tirage

N = 1e5
Nrun = N
cv = 1
Z = NULL
res = NULL

# Si trop long à tourner -> réduire Nlim et/ou augmenter cvlim
while ((Nrun <= Nlim) & (cv > cvlim)){
  X = EchantFcrues(N)
  Z = c(Z,risque_bateau(X))
  pf <- sum(Z) / Nrun
  cv <- sqrt((1-pf)/(Nrun*pf))
  Nrun <- length(Z)
  res <- rbind(res,c(Nrun,pf,cv))
  print(c(Nrun,pf,cv))}


plot(res[,1],res[,2],type='l',col=2,lwd=2,xlab='N',ylab='Pf')





#######################################################
# --------------------------------------------------- #
# 5.Génération de réalisations de variables aléatoires#
# --------------------------------------------------- #
#######################################################
# A faire en tout dernier, si on a le temps.

## -----------------------------------------------------
## 5.1- 
## -----------------------------------------------------
  
# génarateur "maison" (slide 10)
rand = function(n, a = 7^5, c = 0 ,m = 2^31-1 , x0 = sample(1e7,1)) {
x = x0
for (k in 2:n){
x = c( x ,( a*x[k-1] + c )%%m )}
return( x/(m-1) )} 

# générateur de Ripley
u = rand(100,  a = 69069, c = 1 ,m = 2^32)    
  
?set.seed # pour voirr quels sont les générateurs dispo dans R

## -----------------------------------------------------
## 5.2- 
## -----------------------------------------------------

# fonction de répartition incevse de la loi de Weibull 
FinvWeibull = function(u,k,lambda){
return(lambda*(-log(1-u))^(1/k))}

# génération loi uniforme avec notre générateur "maison"
u  = rand(500)
xw = FinvWeibull(u,k=2,lambda=1)  # les x selon weibull

hist(xw,prob=T)
curve(dweibull(x,2,1),add=T,col=2,lwd=2)  # comparaison avec loi implémentée dans R


## -----------------------------------------------------
## 5.3- 
## -----------------------------------------------------

n=2000
# n  réalisations loi triangulaire
xt = rtriangle(n,-1.6,1.6,0)  

# on tire sous la courbe 1.4* pdf loi triangulaire
yc = runif(n,0,1.4*dtriangle(xt,-1.6,1.6,0) )   

# on sélectionne ceux qui sont sous la courbe pdf loi normale
ii = which(yc<=dtnorm(xt,0,0.5, -1.5, 1.5)) # ce sont les indices des points sélectionnés   

# voici les x suivant la loi normale tronquée 
x = xt[ii]    # les    réalisations de la loi 
summary(x)
 
hist(x,nclass=20,prob=T,col=rgb(1,0,0,0.2),xlab='x',ylab='pdf',
cex.lab=1.6,cex.axis=1.4)
curve(dtnorm(x,0,0.5, -1.5, 1.5),col=2,lwd=2,add=T)

# taux d'acceptation
taux = length(ii)/n 

