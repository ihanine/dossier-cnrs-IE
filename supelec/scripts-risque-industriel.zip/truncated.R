
# *********************************************************************
#      truncated.R : fonctions pour lois tronquees :
#                                       normale, lognormale et gumbel
#      avec l'accord des auteurs : G. Pujol et B. Iooss (CEA)
#**********************************************************************

# The Truncated Normal Distribution

# density
dtnorm <- function(x, mean = 0, sd = 1, min = -1e6, max = 1e6){
  out = dnorm(x, mean, sd) / (pnorm(max, mean, sd) - pnorm(min, mean, sd))
  out[(x < min) | (x > max)] = 0
  return(out)
}

# distribution function
ptnorm <- function(q, mean = 0, sd = 1, min = -1e6, max = 1e6){
  out = (pnorm(q, mean, sd) - pnorm(min, mean, sd)) /
    (pnorm(max, mean, sd) - pnorm(min, mean, sd))
  out[q < min] = 0
  out[q > max] = 1
  return(out)
}

# quantile function
qtnorm <- function(p, mean = 0, sd = 1, min = -1e6, max = 1e6){
  return(qnorm((1 - p) * pnorm(min, mean, sd) + p * pnorm(max, mean, sd),
               mean, sd))
}

# random generation
rtnorm <- function(n, mean = 0, sd = 1, min = -1e6, max = 1e6){
  return(qtnorm(runif(n), mean, sd, min, max))
}

#**************************************
# The Truncated Lognormal Distribution

# density
dtlnorm <- function(x, meanlog = 0, sdlog = 1, min = -1e6, max = 1e6){
  out = dlnorm(x, meanlog, sdlog) / (plnorm(max, meanlog, sdlog) - plnorm(min, meanlog, sdlog))
  out[(x < min) | (x > max)] = 0
  return(out)
}

# distribution function
ptlnorm <- function(q, meanlog = 0, sdlog = 1, min = -1e6, max = 1e6){
  out = (plnorm(q, meanlog, sdlog) - plnorm(min, meanlog, sdlog)) /
    (plnorm(max, meanlog, sdlog) - plnorm(min, meanlog, sdlog))
  out[q < min] = 0
  out[q > max] = 1
  return(out)
}

# quantile function
qtlnorm <- function(p, meanlog = 0, sdlog = 1, min = -1e6, max = 1e6){
  return(qlnorm((1 - p) * plnorm(min, meanlog, sdlog) + p * plnorm(max, meanlog, sdlog),
               meanlog, sdlog))
}

# random generation
rtlnorm <- function(n, meanlog = 0, sdlog = 1, min = -1e6, max = 1e6){
  return(qtlnorm(runif(n), meanlog, sdlog, min, max))
}

# ***************************************
# The Truncated Gumbel Distribution

library(evd) # Loi Gumbel

# density
dtgumbel <- function(x, loc = 0, scale = 1, min = -1e6, max = 1e6){
  out = dgumbel(x, loc, scale) / (pgumbel(max, loc, scale) - pgumbel(min, loc, scale))
  out[(x < min) | (x > max)] = 0
  return(out)
}

# distribution function
ptgumbel <- function(q, loc = 0, scale = 1, min = -1e6, max = 1e6){
  out = (pgumbel(q, loc, scale) - pgumbel(min, loc, scale)) /
    (pgumbel(max, loc, scale) - pgumbel(min, loc, scale))
  out[q < min] = 0
  out[q > max] = 1
  return(out)
}

# quantile function
qtgumbel <- function(p, loc = 0, scale = 1, min = -1e6, max = 1e6){
  return(qgumbel((1 - p) * pgumbel(min, loc, scale) + p * pgumbel(max, loc, scale),
               loc, scale))
}

# random generation
rtgumbel <- function(n, loc = 0, scale = 1, min = -1e6, max = 1e6){
  return(qtgumbel(runif(n), loc, scale, min, max))
}
