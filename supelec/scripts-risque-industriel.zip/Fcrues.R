#########################################################################
#
# Auteur : Bertrand Iooss (CEA)
#
# Fichier : Fcrues.R
# Date : 2012
#
# Description de la fonction :
# Cette fonction évalue 
#    - la surverse (en m) difference entre hauteur d'eau et hauteur de la digue
#    - le cout annuel d'entretien de la digue (en millions d'euros)
#
# Description des composantes du vecteur X :
# - X[1] = Q débit (en m3/s), distribuée selon une loi gumbel max tronquee (loc=1013,scale=558,min=500,max=3000) ;
# - X[2] = Ks coefficient de Strickler, distribué selon une loi normale tronquee (30,8,min=15) ;
# - X[3] = Zv cote (en m) du fond du cours d'eau en aval du tronçon (en m NGF), de loi triangulaire (50,+-1) ;
# - X[4] = Zm cote (en m) du fond du cours d'eau en amont du tronçon (en m NGF), de loi triangulaire (55,+-1) ;
# - X[5] = Hd (en m) hauteur de la digue, de loi uniforme (7,9) ;
# - X[6] = Cb (en m) cote de la berge, de loi triangulaire (55.5,+-0.5) ;
# - X[7] = L (en m) longueur du troncon d'eau etudie, de loi triangulaire (5000,+-10) ;
# - X[8] = B (en m) largeur du cours d'eau, de loi triangulaire (300,+-5) 
#
# Description des réponses : 
# - reponse[1] = S (en m) surverse
# - reponse[2] = Cp (en Meuros) cout annuel d'entretien de la digue
#
#########################################################################

Fcrues <- function(X,ans=0){

# ans : parametre permettant de definir la reponse retournee par la fct
#       ans=0 donne les 2 sorties ; ans=1 donne S ; ans=2 donne Cp

  X = matrix(X,ncol=8);

  H = (X[,1] / (X[,2]*X[,8]*sqrt((X[,4] - X[,3])/X[,7])))^(0.6) ;
  S = X[,3] + H - X[,5] - X[,6] ;
  
  Cp = S
  Cp[which(S>0)] = 1
  Cp[which(S<=0)] = 0.2 + 0.8 * (1 - exp(-1000 / S[which(S<=0)]^4)) 
  
  Cp[which(X[,5]>8)] = Cp[which(X[,5]>8)] + X[which(X[,5]>8),5]/20
  Cp[which(X[,5]<=8)] = Cp[which(X[,5]<=8)] + 8/20

  if (ans==0){res = cbind(S,Cp)}
  if (ans==1){res = S}
  if (ans==2){res = Cp}
  

  return(res)

}#end function
