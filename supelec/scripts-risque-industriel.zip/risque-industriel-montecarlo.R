#======================================================|
#|          Quantification des Incertitudes            | 
#|          dans les Simulation Numériques             |
#|_____________________________________________________|
#|                     Monte-Carlo        
#|_____________________________________________________|
#======================================================|


rm(list=ls())    # efface tout
graphics.off()# ferme tous les graphes

## LIBRAIRIES
## ----------
library(evd)          # Pour avoir loi Gumbel
library(triangle)     # Pour avoir la loi triangulaire
library(mistral)      # package pour les événements rares

## fonction pour lois tronquees
## ----------
source("truncated.R")  # Definit quelques lois tronquees (loi normale tronquée par exemple)

## fonctions pour le cas crues
## ----------
source("Fcrues.R")
source("EchantFcrues.R")

## Graine fixée pour reproductibilité des résultats
## ----------
set.seed(12345)


#######################################################
# --------------------------------------------------- #
#  1.   Echantillonnage MC                            #
# --------------------------------------------------- #
#######################################################

## -----------------------------------------------------
## 1.1. 
## -----------------------------------------------------
d = 8
n = 1e4
X = EchantFcrues(n)

# estimation de Pf
Pf_MC_S = sum(Fcrues(X,ans=1)>-7)/n
Pf_MC_S
## -----------------------------------------------------
## 1.2. 
## -----------------------------------------------------

var_Pf_MC_S = (Pf_MC_S)*(1-Pf_MC_S)/n
var_Pf_MC_S 

# cv = écart-type de Pf / espérance de Pf
cv_MC_S  = sqrt((1-Pf_MC_S)/(n*Pf_MC_S))*100
print(cv_MC_S)

IC95_Pf_MC_S =  c(Pf_MC_S -1.96*sqrt(Pf_MC_S*(1-Pf_MC_S))/sqrt(n),
                  Pf_MC_S +1.96*sqrt(Pf_MC_S*(1-Pf_MC_S))/sqrt(n))
print(IC95_Pf_MC_S)

## -----------------------------------------------------
## 1.3. 
## -----------------------------------------------------
cvlim = 0.01 # critère d'arrêt coefficient de variation
Nlim = 1e8   # critère d'arrêt nombre de tirage

N = 1e5
Nrun = N
cv = 1
Z = NULL
res = NULL

# Si trop long à tourner -> réduire Nlim et/ou augmenter cvlim
while ((Nrun <= Nlim) & (cv > cvlim)){
  Z = c(Z,Fcrues(EchantFcrues(N),ans=1)>-7)
  pf = sum(Z) / Nrun
  cv = sqrt((1-pf)/(Nrun*pf))
  Nrun = length(Z)
  res = rbind(res,c(Nrun,pf,cv))
  print(c(Nrun,pf,cv))}


plot(res[,1],res[,2],type='l',col=2,lwd=2,xlab='N',ylab='Pf')


## -----------------------------------------------------
## 1.4. 
## -----------------------------------------------------
# estimation de Pf
Pf_MC_Ct = sum(Fcrues(X,ans=2)>???)/n
Pf_MC_Ct

cv_MC_Ct  = sqrt((1-Pf_MC_Ct)/(n*Pf_MC_Ct))*100
print(cv_MC_Ct)

IC95_Pf_MC_Ct =  c(Pf_MC_Ct -1.96*sqrt(Pf_MC_Ct*(1-Pf_MC_Ct))/sqrt(n),
                  Pf_MC_Ct +1.96*sqrt(Pf_MC_Ct*(1-Pf_MC_Ct))/sqrt(n))
print(IC95_Pf_MC_Ct)

# augmenter n

# on ne refait pas la convergence






#######################################################
# --------------------------------------------------- #
#  3.Transformation iso-prob. et fct d'état limite  S  #
# --------------------------------------------------- #
#######################################################

## -----------------------------------------------------
## 3.1. 
## -----------------------------------------------------

# Passage de l'espace physqique à l'espace gaussien (le package mistral fonctionne ainsi)
# les paramètres d'entrée sont indépendants donc c'est facile : 
# Soient: U une va N(0,1) de cdf F_U; X une va de cdf F_X
# on a biensûr : X = F_X^{-1}(F_U(U)) et U = F_U^{-1}(F_X(X))
# en R : F_Y(y) = p'nom_loi'(y,param_loi_Y)  (exemple : pnorm(y,0,1)))
# en R : F_Y^{-1}(y) = q'nom_loi'(y,param_loi_Y)  (exemple : qnorm(y,0,1)))

# à faire pour la première composante de X, nommée X1 pour l'occasion : 
# X1 ~ gumbel tronquée de paramètres : loc=1013.0,scale=555.0,min=500,max=3000
# regarder le fichier EchantFcrues.R pour le 'nom_loi'
# on cherche à passer de U à X1 :

U1 = rnorm(100)
X1 = qtgumbel(pnorm(U1),loc=1013.0,scale=555.0,min=500,max=3000)



## -----------------------------------------------------
## 3.2. 
## -----------------------------------------------------
# chargement de la fonction utile pour passer de U à X  
source('passage_U_X.R')

Utest = matrix(rnorm(100)*d,ncol=d)
Xtest = passage_U_X(Utest)
XX = EchantFcrues(100)
summary(Xtest)
summary(XX)

## -----------------------------------------------------
## 3.3- Fonction d'état limite
## -----------------------------------------------------

# écrire la fonction d'état limite de l'événement "S est supérieur à 7m"
# RAPPEL :  il ya "défaillance" quand la fonction d'état limite est < 0

etat_limite_S <- function(U){
  # l'arguement U doir être sous la forme dimension x nb_simulationspour les besoins 
  # du package mistral qui veut U en t(U) par rapport à nos usages
  # marche comme avant mais adaptés au package
  U  <- as.matrix(U)
  U = t(U) 
  X = passage_U_X(U)
  G <- - Fcrues(X,ans=1) - 7 # défaillanece qd G<0 
  return(G)
}

etat_limite_Ct <- function(U){
  # l'arguement U doir être sous la forme dimension x nb_simulationspour les besoins 
  # du package mistral qui veut U en t(U) par rapport à nos usages
  # marche comme avant mais adaptés au package
  U  <- as.matrix(U)
  U = t(U) 
  X = passage_U_X(U)
  G <- - Fcrues(X,ans=2) +1 # défaillanece qd G<0 
  return(G)
}


#######################################################
# --------------------------------------------------- #
#  4.   Echantillonnage conditionné                   #
# --------------------------------------------------- #
#######################################################

## -----------------------------------------------------
## 4.1- Subset simulation 
## -----------------------------------------------------

res_subset_S = SubsetSimulation( dimension = d, lsf = etat_limite_S, p_0=0.1, N=1e3)

Pf_subset_S = res_subset_S$p
Pf_subset_S

N.calls_subset = res_subset_S$Ncall
N.calls_subset

# coef var
cv_Pf_subset_S = res_subset_S$cov
cv_Pf_subset_S

# IC
IC_Pf_subset_S = c(Pf_subset_S *(1-1.96*cv_Pf_subset_S ),Pf_subset_S *(1+1.96*cv_Pf_subset_S ))
IC_Pf_subset_S

# avec Monte Carlo
IC95_Pf_MC_S

# Autre test
res_subset_S = SubsetSimulation( dimension = d, lsf = etat_limite_S, p_0=0.2, N=500)

## -----------------------------------------------------
## 4.2- Moving particles 
## -----------------------------------------------------
res_MP_S = MP( dimension = d, lsf = etat_limite_S  ,N=1e3, q=0 )

res_MP_S$Ncall
Pf_MP_S = res_MP_S$p
Pf_MP_S

IC_Pf_MP_S =res_MP_S$p_int

IC_Pf_MP_S 
IC_Pf_subset_S

# Autre test
res_MP_S = MP( dimension = d, lsf = etat_limite_S  ,N=1e3, q=0 ,N.batch=5)
res_MP_S$Ncall
Pf_MP_S = res_MP_S$p
Pf_MP_S

IC_Pf_MP_S =res_MP_S$p_int

IC_Pf_MP_S 
IC_Pf_subset_S

## -----------------------------------------------------
## 4.3- Pour le coût 
## -----------------------------------------------------

# subset
res_subset_Ct = SubsetSimulation( dimension = d, lsf = etat_limite_Ct, p_0=0.1, N=1e3)

Pf_subset_Ct = res_subset_Ct$p
cv_Pf_subset_Ct = res_subset_Ct$cov
cv_Pf_subset_Ct

# IC
IC_Pf_subset_Ct = c(Pf_subset_Ct  *(1-1.96*cv_Pf_subset_Ct  ),Pf_subset_Ct  *(1+1.96*cv_Pf_subset_Ct  ))


IC_Pf_subset_Ct

# avec Monte Carlo
IC95_Pf_MC_Ct

# moving particles
res_MP_Ct = MP( dimension = d, lsf = etat_limite_Ct  ,N=1e3, q=0 ,N.batch=5)
res_MP_Ct$Ncall
Pf_MP_Ct = res_MP_Ct$p
Pf_MP_Ct

IC_Pf_MP_Ct =res_MP_Ct$p_int

IC_Pf_MP_Ct 
IC_Pf_subset_Ct

#######################################################
# --------------------------------------------------- #
#  5.   FORM                                          #
# --------------------------------------------------- #
#######################################################
## -----------------------------------------------------
## 5.1
## -----------------------------------------------------
# pour que la fonction marche : 
distributions = list()
for (k in 1:d){distributions[[k]] = list(type="norm", mean = 0, sd = 1)}


res_FORM_S = FORM(f=etat_limite_S ,u.dep = rep(0,d),
             inputDist=distributions,N.calls = 1000)


res_FORM_S$pf
res_FORM_S$compt.f
res_FORM_S$design.point

res_subset_S$p

# tester d'autres points de départ : 
ResuFORMS_2 = FORM(f=etat_limite_S ,u.dep = rep(-1,d),
                   inputDist=distributions,N.calls = 1000)
ResuFORM1$pf

## -----------------------------------------------------
## 5.2- Méthode FORM et IS ensuite : 
## -----------------------------------------------------
res_FORM_IS_S = FORM(f=etat_limite_S ,u.dep = rep(0,d),
                  inputDist=distributions,N.calls = 1e4,IS=TRUE)



res_FORM_IS_S$pf
res_FORM_IS_S$compt.f
res_FORM_IS_S$design.point
res_FORM_IS_S$conf

res_subset_S$p
IC_Pf_subset_S

# augmenter N.calls

## -----------------------------------------------------
## 5.3- le coût
## -----------------------------------------------------


res_FORM_Ct = FORM(f=etat_limite_Ct ,u.dep = rep(0,d),
                  inputDist=distributions,N.calls = 1000)


res_FORM_Ct$pf
res_FORM_Ct$compt.f
res_FORM_Ct$design.point

res_subset_Ct$p
IC_Pf_subset_Ct

#######################################################
# --------------------------------------------------- #
#  6.   Théorie des valeurs extrêmes                  #
# --------------------------------------------------- #
#######################################################

## -----------------------------------------------------
## 6.1 Méthode des maxima pour S
## -----------------------------------------------------

max_S = max_Ct = c()
for (k in 1:50){

data = Fcrues(EchantFcrues(20))
max_S = c(max_S,max(data[,1])) 
max_Ct = c(max_Ct,max(data[,2]))  }  

summary(max_S)

hist(max_S)
fitgev_max_S = fgev(max_S)
fitgev_max_S 


par(mfrow=c(2,2))
plot(fitgev_max_S,col='blue' )

plot(profile(fitgev_max_S ))

# domaine d'attraction : ?

# extrapolation P(S>-7) : 
loc_max_S = fitgev_max_S$param[1]
scale_max_S = fitgev_max_S$param[2]
shape_max_S = fitgev_max_S$param[3]



Pf_max_S_extrapol = -1/length(max_S)*log(pgev(-7,loc_max_S,scale_max_S,shape_max_S))
as.numeric(Pf_max_S_extrapol)

## -----------------------------------------------------
## 6.2 Méthode des maxima pour Ct
## -----------------------------------------------------
# faire plutôt les maxima par blocs à partir de
data = Fcrues(EchantFcrues(1e3))

# pour le coût
summary(max_Ct)

par(mfrow=c(1,1))
hist(max_Ct)
fitgev_max_Ct = fgev(max_Ct)



par(mfrow=c(2,2))
plot(fitgev_max_Ct,col='red' )

plot(profile(fitgev_max_Ct ))

# extrapolation P(Ct>1) : 
loc_max_Ct = fitgev_max_Ct$param[1]
scale_max_Ct = fitgev_max_Ct$param[2]
shape_max_Ct = fitgev_max_Ct$param[3]

# domaine d'attraction 

Pf_max_Ct_extrapol = -1/length(max_Ct)*log(pgev(1,loc_max_Ct,scale_max_Ct,shape_max_Ct))
as.numeric(Pf_max_Ct_extrapol)

## -----------------------------------------------------
## 6.3 Méthode des excès pour Ct
## -----------------------------------------------------

data = Fcrues(EchantFcrues(1e3))

# choix du seuil : 
par(mfrow=c(1,1))
mrlplot(data[,2])

mrlplot(data[,2],tlim=c(0.64,0.74))


par(mfrow=c(1,2))
tcplot(data[,2],tlim=c(0.64,0.73))
tcplot(data[,2],tlim=c(0.66,0.72))

u_Ct = 0.68 # à changer suivant ce que vous trouvez sur votre échantillon


par(mfrow=c(1,1))
fitgpd_exces_Ct = fpot(data[,2], u_Ct)


par(mfrow=c(2,2))
plot(fitgpd_exces_Ct,col='blue')

par(mfrow=c(1,2))
plot(profile(fitgpd_exces_Ct ))



# extrapolation

fitgpd_exces_Ct = fpot(data[,2], u_Ct)
scale_exces_Ct = fitgpd_exces_Ct$estimate[1]
shape_exces_Ct = fitgpd_exces_Ct$estimate[2]



Pf_exces_Ct_extrapol = (sum(data[,2]>u_Ct)/dim(data)[1])*(1-pgpd(1,u_Ct,scale_exces_Ct,shape_exces_Ct))
as.numeric(Pf_exces_Ct_extrapol)

# tester d'autres seuils u_Ct ! 
# Regarder son influence sur Pf
