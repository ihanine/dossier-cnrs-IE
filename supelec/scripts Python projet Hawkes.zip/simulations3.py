import scipy.integrate as integrate
import random as rd
import matplotlib.pyplot as plt
import numpy as np
plt.close()
###POISSON PROCESS
def Lambda(tupper):
    return(integrate.quad(lambda x: lamb*x, 0, tupper)[0])
    
def lambda_inv(s, t_max):
    inf = float('inf')
    v_values = np.linspace(0, t_max+3, 1000)
    integrated_values = []

    for v in v_values:
        integrated_values.append(Lambda(v))

    min_v = inf
    for i in range(len(v_values)):
        if min_v > v_values[i] and integrated_values[i] >= s:
            min_v = v_values[i]

    return min_v
    
def poisson_process(tmax):
    t=0
    s=0
    X=[]
    while t<=tmax:
        u=rd.uniform(0, 1)
        s=s-np.log(u)
        t=lambda_inv(s, tmax)
        X.append(t)
    return(X)
###
lamb = 40/100
lamb2=5
tmax=50
I=poisson_process(tmax)
R=poisson_process(tmax)

def fonction_principale(QI0, QS0, QR0):

    t=0
    T=[0]
    NI=0
    NR=0
    fI=[0]
    fR=[0]
    QI=[QI0]
    QS=[QS0]
    QR=[QR0]
    deltaL=[]
    deltaLI=[]
    
    def actualiserf():
        fI.append(fI[-1]+(T[-1]-T[-2])*QI[-1]*QS[-1])
        fR.append(fR[-1]+(T[-1]-T[-2])*QI[-1])
        
    while T[-1]<tmax and NI<len(I)-2 and NR<len(R)-2:
        nI=NI+1
        deltaI=(I[nI]-fI[-1])/(QI[-1]*QS[-1])
        deltaLI.append([I[nI], fI[-1], QI[-1], QS[-1], deltaI])
        
        nR=NR+1
        deltaR=(R[nR]-fR[-1])/QI[-1]
        deltaL.append([deltaI, deltaR])
        if deltaI<deltaR:
            T.append(T[-1]+deltaI)
            NI+=1
        else:
            T.append(T[-1]+deltaR)
            NR+=1
        
        actualiserf()
        
        QI.append(QI[0]+NI-NR)
        QS.append(QS[0]-NI)
        QR.append(NR)
        print(QS[-1])

#    print(deltaL)    
#    n=len(fI)
#    F=[[fI[i], fR[i], fR[i]-fI[i]] for i in range(n)]
#    print(F)
    
    plt.plot(log(T), QI)
    plt.plot(log(T), QS)
    plt.plot(log(T), QR)
    plt.show()

fonction_principale(10,195,0)    