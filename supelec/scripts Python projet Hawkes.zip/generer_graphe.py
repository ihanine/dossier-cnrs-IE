import random as rd
import numpy as np

def generer_graphe(N):
    graphe=[[] for i in range(N)]
    for i in range(N):
        nbre_voisins=rd.randint(1, N)
        L=[k for k in range(N)]
        
        for j in range(nbre_voisins):
           
            indice_voisin=rd.randint(0, len(L)-1)
            voisin=L[indice_voisin]
            poids=rd.random()
            graphe[i].append((L[indice_voisin], poids))
            L.remove(voisin)
    return(graphe)
            

    
    