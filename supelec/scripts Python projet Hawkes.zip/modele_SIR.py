from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt

plt.close("all")
def SIR(Q,t,b,g,N):
    [Qs, Qi, Qr]=Q
    dQdt= [-(b*Qs*Qi)/N,(b*Qs*Qi)/N-g*Qi,g*Qi]
    return dQdt

""" CONDITIONS INITIALES """

N=100
qi=1
qr=0
qs=N-qi

q0=[qs,qi,qr]

"""vecteur T"""
t = np.linspace(0, 2, 1001)

"""parametres"""

b=40
g=5

"""resolution"""

sol=odeint(SIR, q0, t, args=(b, g, N))
plt.plot(t, sol[:, 0], 'b', label='Qs(t)')
plt.plot(t, sol[:, 1], 'g', label='Qi(t)')
plt.plot(t, sol[:, 2], 'r', label='Qr(t)')
plt.xlabel('t')
plt.grid()
plt.show()
