import numpy as np
import random as rd
import pylab
from matplotlib import pyplot as plt
import copy


plt.close()
def generer_grapheSeuil(N):
    graphe=[[] for i in range(N)]
    for i in range(N):
        nbre_voisins=np.random.poisson((N//3)+1)
        L=[k for k in range(N)]
        poids_total=0
        for j in range(nbre_voisins):  
            indice_voisin=rd.randint(0, len(L)-1)
            voisin=L[indice_voisin]
            poids=rd.random()
            poids_total+=poids
            graphe[i].append((voisin, poids))  #vu la structure du graphe ici les poids sont les poids des arrêtes allant vers le noeud en question
            L.remove(voisin)
        
#        if poids_total>1: #renormalisation des poids pour que la somme soit inférieur à 1
##            
#            for j in range(nbre_voisins):
#                voisin=graphe[i][j][0]
#                graphe[i][j]=(voisin,graphe[i][j][1]/poids_total)                
#        
        
        liste=copy.copy(graphe[i])       #le seuil est égal à la somme des poids d'une partition aléatoire sur l'ensemble des voisins
        rd.shuffle(liste)
        cut=rd.randint(0, len(liste))
        liste=liste[:cut]
        seuil=sum(i[1] for i in liste)/1.0001
        graphe[i].append(seuil)
    return(graphe)
    

def generer_infecte(N,graphe):
    I=[False for k in range(len(graphe))]
    for i in range (N):
        n=rd.randint(0,len(graphe)-1)
        I[n]=True 
            #dans l'algorithme seuil la structure qui nous intéresse c'est si on est infecté ou non et à quel moment
            #(le temps est traité dans l'algo modele_seuil) les parents peuvent être multiples
    return I

    
def modele_seuil(graphe, tmax, NombreInfecte):
    
    chemin=[(False,-1) for k in range(len(graphe))]
    t=0
    I=generer_infecte(NombreInfecte, graphe)
    while(t<=tmax):
        
        for j in range (len(chemin)):  #mise à jour des nouveaux infectés avec le temps
            if not(chemin[j][0]) and I[j]:
                chemin[j]=(True,t)
        
        for i in range (len(graphe)):
            activation=0
            if not(I[i]): #si i n'est pas déjà infecté alors :
                for j in range (len(graphe[i])-1):
                    if I[j]: #si le voisin est affecté
                        activation+=graphe[i][j][1]
                if activation >= graphe[i][-1]:
                    I[i]=True
                    
        t+=1
        
    return chemin
C=[]               
for x in range (100):
    moyenne=0
    for y in range(50):
        graphe=generer_grapheSeuil(100)
        chemin=modele_seuil(graphe, 100, x+1)
        for k in range(len(chemin)):
            if chemin[k][0]==True:
                moyenne+=1
    C.append(moyenne//50)
n=np.linspace(1,100,100)    
plt.plot(n,C,label="moyenne")


#graphe=generer_grapheSeuil(100)
#chemin=modele_seuil(graphe, 100, 20)
#print(chemin)
        
        



                    
