import numpy as np
import random as rd
import matplotlib.pyplot as plt
import numpy.random as alea

def intensite(lambda0, alpha, beta, P, t):
    r=lambda0;
    for elt in P:
        r=r+alpha*np.exp(-beta*(t-elt))
    return(r);
    
def escalier(x, y):
    if len(x)==len(y):
        n=len(x);
        for i in range(n-1):
            plt.plot([x[i], x[i+1]], [y[i], y[i]], 'r-')

def hawkesbythinning(lambda0, alpha, beta, T):
    eps = 10**(-10);#avoir accés à t+
    P, Q = [], [];#temps points gardés, temps points rejetés
    uP, uQ =[], [];#intensités correspondantes
    t=0;
    intens = [];#lambda
    time=[];

    while t<T:
        M=intensite(lambda0, alpha, beta, P, t+eps);
        u=rd.uniform(0, 1);
        E=-np.log(u/M);
        #E=np.exp(M);
        t=t+E;
        time0 = np.arange(t-E, t, 0.01).tolist();
        time=time+time0;
        for elt in time0:
            intens.append(intensite(lambda0, alpha, beta, P, elt));
        U=rd.uniform(0,M);
        if t<T:
            if U<intensite(lambda0, alpha, beta, P, t):
                P.append(t);
                uP.append(U);
            else:
                Q.append(t);
                uQ.append(U);
                
    nP=len(P); 
    compteP=[k for k in range(nP)];
#    escalier(P, compteP);
    plt.plot(time, intens);
    plt.plot(P, uP, 'ro');
    plt.plot(Q, uQ, 'bo');
    plt.show();
    
    return P;

"""   

def hawkesbyclusters(T, lamb, alpha, beta):
    P=[];
    #Immigrants
    k=alea.poisson(T*lamb);
    C=[rd.unif(0, T) for i in range(k)];
    #Descendants
    D=[alea.poisson(alpha/beta) for i in range(k)];
    
    for i in range(0, k):
        if D[i]!=0:
            E=[alea.exponential(beta) for J in range(D[i])];
            P=P+[C[i] + E[j] for j in range(D[i])];
    P=P+[C[i] for i in range(k)];
    P=P.sort();
    return(P)
"""