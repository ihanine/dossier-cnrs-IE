import pylab
from matplotlib import pyplot as plt
import numpy as np

plt.close("all")

# let's say that lambda is our background intensity, a the new arrivals excitement, 
# and b the arrival influence declining.
# In ordre to avoid "explosion" b must be greater than a
def lambda_etoile(l,a,b,H,t):
    result=l
    for tau in H:
        if tau<t:
            result=result+a*(pylab.exp(-b*(t-tau)))
    return result


def HP_by_thinning(l,a, b, T):
    epsilon=float(10^-8)
    H=list()
    t=0.0
    while t<T:
        M=lambda_etoile(l,a,b,H,t+epsilon)
        E=pylab.exp(M/5)
        t=t+E
        U=np.random.uniform(0.0,M)
        if (U<lambda_etoile(l,a,b,H,t) and t<T):
            H.append(t)
    return H

def Count(H):
    N=[0]
    for i in range (len(H)):
        N.append(i+1)
    return N
#valeur 
Li=
Ai=
Bi=

I=Count(HP_by_thinning(Li,Ai, Bi, T))
R=Count(HP_by_thinning(Lr,Ar, Br, T))

def SIR(Qr0,Qs0,Qi0,T):
    t=0
    H=[0]
    fI=[0]
    fR=[0]
    Qi=[Qi0]
    Qr=[Qr0]
    Qs=[Qs0]
    
    fI.append(fI[-1]+(H[-1]-H[-2])*Qi[-1]*Qs[-1])
    fR.append(fR[-1]+(H[-1]-H[-2])*Qi[-1])
    while H[-1]<T:
        
    
    