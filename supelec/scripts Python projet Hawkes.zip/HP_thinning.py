import pylab
from matplotlib import pyplot as plt
import numpy as np

plt.close("all")

# let's say that lambda is our background intensity, a the new arrivals excitement, 
# and b the arrival influence declining.
# In ordre to avoid "explosion" b must be greater than a
def lambda_etoile(l,a,b,H,t):
    result=l
    r=0
    for tau in H:
        if tau<t:
            result=result+a*(pylab.exp(-b*(t-tau)))
            r+=1
    
    return (1-r/200)*result


def HP_by_thinning(l,a, b, T):
    epsilon=10**(-12)
    H=list()
    t=0.0
    while t<T:
        M=lambda_etoile(l,a,b,H,t+epsilon)
        u=np.random.uniform(0.1,M)
        E=pylab.log(M/u)
        t=t+E
        U=np.random.uniform(0.0,M)
        if (U<lambda_etoile(l,a,b,H,t) and t<T):
            H.append(t)
    return H

def Count(H):
    N=[0]
    for i in range (len(H)):
        N.append(i+1)
    return N


#Valeurs
l=1
a=1
b=1.1
T=30
H=HP_by_thinning(l,a,b,T)
t = np.linspace(0., T, 300)
L=list()
for x in t:
    L.append(lambda_etoile(l,a,b,H,x))


#Tracé

plt.subplot(2, 1, 1)

plt.grid(True)
plt.plot(t, L)
plt.title('Hawkes Process')
plt.ylabel('intensity')

plt.subplot(2, 1, 2)
plt.grid(True)
plt.plot([0]+H, Count(H))
plt.xlabel('time')
plt.ylabel('count')

plt.show()


        



