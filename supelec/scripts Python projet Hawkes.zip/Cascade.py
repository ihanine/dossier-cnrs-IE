import numpy as np
import random as rd
import pylab
from matplotlib import pyplot as plt
import copy

plt.close()
"""exemple"""
I=[(0,-1,0),(4,-1,0)] #les infectés de base sous la forme de tuple (numéro,parent,temps d'infection) 
           #si pas de parent alors valeur par défaut -1
P=[[(1,0.4),(2,0.7),(4,0.1)],
         [(4,0.6)],
         [(3,0.2)],
         [(4,0.35)],
         [(1,0.7),(3,0.9),(2,0.1)]]
    

def generer_grapheProfil(N):
    graphe=[[] for i in range(N)]
    for i in range(N):
        nbre_voisins=np.random.poisson(N//3)
        L=[k for k in range(N)]
        
        for j in range(nbre_voisins):
           
            indice_voisin=rd.randint(0, len(L)-1)
            voisin=L[indice_voisin]
            poids=rd.random()/(N/10)
            graphe[i].append((L[indice_voisin], poids))
            L.remove(voisin)
    return(graphe)
    
#def Hawkes(a,b,t):
#    result=0
#    tau=0
#    while tau<t:
#        result=result+a*(pylab.exp(-b*(t-tau)))
#        tau+=1
#    return result
    
def generer_infecte(N,graphe):
    I=[]
    for i in range (N):            
        n=rd.randint(0,len(graphe)-1)   
        if not((n,-1,0) in I):
            I.append((n,-1,0))
    return I

def parcours_largeur(Profil,I):
    Chemin=[]
    Vu=[]
    Infecte=copy.copy(I)
    while Infecte != []:
        n = Infecte.pop(0)
        if not (n[0] in Vu):
            Vu.append(n[0])
            Chemin.append(n)
            for i in Profil[n[0]]:
                U=np.random.uniform(0.0,1)
                if U<=i[1] and not(i[0] in Vu): #si inférieur au poids donné
                    Infecte.append((i[0],n[0],n[2]+1))
    return Chemin

def comptage_chemin(Profil, Infecte): 
    N=[len(Infecte)]
    t=1
    Chemin=parcours_largeur(Profil,Infecte)
    Nt=N[-1]
    while (True):
        for i in Chemin:
            if i[2]==t:
                Nt+=1
        if(Nt==N[-1]):
            break
        N.append(Nt)
        t+=1
    return N

graphe=generer_grapheProfil(1000)
Infecte=generer_infecte(20,graphe)
N=comptage_chemin(graphe,Infecte)
chemin=parcours_largeur(graphe,Infecte)

print(N)
S=[1000-i for i in N]
print(S)

t=np.linspace(0,len(N),len(N))
plt.plot(t,N,"r",label="infecté")
plt.plot(t,S,"b",label="suceptible")
            
        
        
          
            
                

                