from random import *
from numpy import *
def Poisson(l):
    t=1.0/expovariate(l)
    return int(t)

print(random.poisson(15))

