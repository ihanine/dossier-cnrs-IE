import pylab
from matplotlib import pyplot as plt
import numpy as np

plt.close("all")


Tmax=2000

def lambda_etoileHr(l,a,b,H,t):
    result=l
    r=0
    for tau in H:
        if tau<t:
            result=result+a*(pylab.exp(-b*(t-tau)))
            r+=1
    return (1-r/200)*result

def lambda_etoileHi(l,a,b,H,Hr,t):
    result=l
    r=0
    i=0
    for tau in H:
        if tau<t:
            result=result+a*(pylab.exp(-b*(t-tau))
            if len(Hr)>H.index(tau) and Hr[H.index(tau)]>t:
                r+=1
                i+=1
    return (1-r/200)*result


def HP_by_thinningHi(l,a, b, Hi,Hr,t):
    epsilon=10**(-12)
    temps=t
    
    while temps<Tmax:
        M=lambda_etoileHi(l,a,b,Hi,Hr,temps+epsilon)
        print(M)
        u=np.random.uniform(0.1,M)
        E=pylab.log(M/u)
        temps=temps+E
        U=np.random.uniform(0.0,M)
        if (U<lambda_etoileHi(l,a,b,Hi,Hr,temps) and temps<Tmax):
            Hi.append(temps)
            break
    return Hi


def HP_by_thinningHr(l,a, b, Hr,t):
    
    epsilon=10**(-12)
    temps=t
    while temps<Tmax:
        M=lambda_etoileHr(l,a,b,Hr,temps+epsilon)
        u=np.random.uniform(0.1,M)
        E=pylab.log(M/u)
        temps=temps+E
        U=np.random.uniform(0.0,M)
        if (U<lambda_etoileHr(l,a,b,Hr,temps) and temps<Tmax):
            Hr.append(temps)
            break
    return Hr


def SIR(Qr0,Qs0,Qi0):
    Hi=[0]
    Hr=[0]
    T=[0]
    Li=1
    Ai=1
    Bi=1.1
    
    Lr=1
    Ar=1
    Br=1.1
      
    Qi=[Qi0]
    Qr=[Qr0]
    Qs=[Qs0]
    t=0
    Ni=0
    Nr=0
    
    while(t<Tmax):
        min=Tmax
        lettre='none'
        for i in Hi:
            if(i<T[-1]):
                break
            elif(i<min):
                min=i
                lettre='i'
                
        for i in Hr:
            if(i<T[-1]):
                break
            elif(i<min):
                min=i
                lettre='r'
        t=min
        T.append(t)        
        Hi=HP_by_thinningHi(Li,Ai, Bi, Hi,Hr,t)
        Hr=HP_by_thinningHr(Lr,Ar, Br, Hr,t)
        
        if lettre=='r':
            Nr+=1
        elif lettre=='i':
            Ni+=1
        
        Qi.append(Qi[0]+Ni-Nr)
        Qr.append(Qr[0]+Nr)
        Qs.append(Qs[0]-Ni)
    
    
        
        
        
    
    
    plt.plot(T, Qi,'b')
    plt.plot(T, Qr,'g')
    plt.plot(T,Qs,'r')
    plt.show()
SIR(0,190,10)  
   

    

    