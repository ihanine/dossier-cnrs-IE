# -*- coding: utf-8 -*-
"""
================================================================================
 Map Matching  --  réalignement de traces GPS sur un réseau routier (OpenStreetMap)
 Auteurs : T. Gasq, I. Hanine, T. Bohe  (Projet de conception, L2S / CentraleSupélec, 2019)
================================================================================
 Version nettoyée et portée Python 3. Les corrections par rapport au code
 d'origine sont signalées par des commentaires « [FIX] ». La logique de
 l'algorithme est conservée à l'identique ; seules les corrections strictement
 nécessaires à l'exécution (imports manquants, API NumPy obsolète, chemin de
 fichier codé en dur) et une correction de décalage d'indice dans Viterbi
 (conforme à la version de référence laissée en commentaire par les auteurs)
 ont été apportées. Voir la « notice_explicative » pour le détail.

 Utilisation : voir README.txt (deux phases : génération de la séquence de
 segments, puis tracé du matching).
================================================================================
"""

import json
import math
from math import sqrt, floor, pi, exp            # [FIX] imports explicites (étaient utilisés sans import)
import numpy as np
import matplotlib.pyplot as plt

# --- Configuration ------------------------------------------------------------
# [FIX] chemin de données rendu configurable (était codé en dur vers un poste précis).
JSON_PATH = "medium.json"                          # adapter au besoin

##PARTIE DATA

with open(JSON_PATH, encoding="utf-8") as json_data:
    data_dict = json.load(json_data)

    
trackpoint=[[2.164886, 48.70967102],
       [2.16488099, 48.70970154],
       [2.16487908, 48.70972443],
       [2.16490293, 48.70975113],
       [2.16495204, 48.70976257],
       [2.16501403, 48.70975876],
       [2.16507792, 48.70975113],
       [2.16514397, 48.70974731],
       [2.16521311, 48.70973969],
       [2.16528511, 48.70973587],
       [2.16535807, 48.70973587],
       [2.16543007, 48.70973587],
       [2.16550708, 48.70973969],
       [2.16558599, 48.7097435],
       [2.16566396, 48.7097435]]

def transfo_coord(l,lg):
    x=6371000.*math.cos(l*math.pi/180.)*math.cos(lg*math.pi/180.)
    y=6371000.*math.cos(l*math.pi/180.)*math.sin(lg*math.pi/180.)
    return (x,y)

def max_id(L):
    max=0
    for i in L:
        if(i['id']>max):
            max=i['id']
    return max
        

def list_node(json):
    dico = json['elements']
    
    #Création des listes de routes et de noeuds
    node_list = []
    
    for i in dico:
        if i['type'] == "node":
            node_list.append(i)
    return node_list

def segments_node(json):
    dico = json['elements']
    
    #Création des listes de routes et de noeuds
    node_list = []
    way_list = []
    for i in dico:
        if i['type'] == "node":
            node_list.append(i)
        elif i['type'] == "way":
            way_list.append(i)
    
    '''à partir de là on va créer une liste de couple de deux noeuds du réseau
    chaque couple étant un segment enfait; on repérera ce segment par sa position dans la liste (cf.plus tard)'''
    
    seg_list=[]
    
    
    '''pour éviter les problèmes de redondance on utilisera un compteur 
    typiquement si le noeud 0 de node list a déjà été parcourue alors tous les segments 
    contenant ce noeud 0 seront déjà comptabilisés et donc pas la peine de les remettre une nouvelle fois dans la liste (cf. if node_list.get_index(n_id)<i)'''
    i=0
    for n in node_list:
        for w in way_list:
            if n['id'] in w['nodes']:
                index=w['nodes'].index(n['id'])
                l=len(w['nodes'])
                
                if(index==l-1):
                    id=w['nodes'][index-1]
                    n_id=next(item for item in node_list if item['id'] == id)
                    if(node_list.index(n_id)>i): #ici le test de redondance
                        A=n.copy()
                        B=n_id.copy()
                        seg_list.append((A,B))
                
                elif(index<l-1 and index>0):
                    id1=w['nodes'][index-1]
                    id2=w['nodes'][index+1]
                    n_id1=next(item for item in node_list if item['id'] == id1)
                    n_id2=next(item for item in node_list if item['id'] == id2)
                    if(node_list.index(n_id1)>i and node_list.index(n_id2)>i): #ici le test de redondance
                        A=n.copy()
                        B=n_id1.copy()
                        C=n_id2.copy()
                        seg_list.append((A,B))
                        seg_list.append((A,C))
                    elif(node_list.index(n_id1)>i and node_list.index(n_id2)<i):
                        A=n.copy()
                        B=n_id1.copy()
                        seg_list.append((A,B))
                    elif(node_list.index(n_id2)>i and node_list.index(n_id1)<i):
                        A=n.copy()
                        B=n_id2.copy()
                        seg_list.append((A,B))
                    
                    
                elif(index==0):
                    id=w['nodes'][index+1]
                    n_id=next(item for item in node_list if item['id'] == id)
                    if(node_list.index(n_id)>i): #ici le test de redondance
                        A=n.copy()
                        B=n_id.copy()
                        seg_list.append((A,B))
                    
        i+=1
    return seg_list



def list_points(json, seg_list): 
    '''renvoie un dico avec la clef étant l'id et la valeur : coordonnées et la liste de tous les segments partant de ce point'''
    id=max_id(list_node(json))+1
    P={}
    m=2 #marche
    
    for s in seg_list:
        c1=transfo_coord(s[0]['lat'],s[0]['lon'])
        if(s[0]['id'] in P.keys()):    
            P[s[0]['id']].append(seg_list.index(s))
        else:
            P[s[0]['id']]=[c1]
            P[s[0]['id']].append(seg_list.index(s))
        
        #idem pour le deuxième point
        c2=transfo_coord(s[1]['lat'],s[1]['lon'])
        if(s[1]['id'] in P.keys()):
            P[s[1]['id']].append(seg_list.index(s))
        
        else:
            P[s[1]['id']]=[c1]
            P[s[1]['id']].append(seg_list.index(s))
        
        l=math.sqrt((c1[0]-c2[0])**2+(c1[1]-c2[1])**2)
        N=int(floor(l/m))
        
        if(N>1): 
            '''ici on ajoute des points régulièrement espacés pour ne plus avoir ce problème de détection des segments proches '''
            for k in range(1,N):
                
                c=(k*(c2[0]-c1[0])/N+c1[0],k*(c2[1]-c1[1])/N+c1[1])
                
                P[id]=[c,seg_list.index(s)]
                id+=1
                
        
    return(P)

def max_id_liste_points(list_points):#va nous servir pour créer des noeuds GPS pour le dijkstra
    return list(list_points.keys())[-1]
    
def voisins(c1,c2):
    return(((c1[0]-c2[0])**2+(c1[1]-c2[1])**2)<=50)
    
def trackpoint_creation(trackpoint,json): #création de la liste des traces à partir de la liste des lon, lat
    traces=[]
    id=max_id(list_node(json))+1
    for n in trackpoint:
        traces.append({'id': id, 'lat':n[1], 'lon':n[0]})
        id+=1
    return traces
        
def adjacent_seg(json, node, seg_list):
    c=transfo_coord(node['lat'],node['lon'])
    '''disons que l'on va chercher dans un rayon de 50 mètres autour du point GPS'''
    set_seg=set({})
    P=list_points(json, seg_list)
    
    for p in P.values():
        if(voisins(c,p[0])):
            for s in p[1:]:
                set_seg=set_seg.union({s})
    
    return list(set_seg)
                
def ensemble_segments(json, traces, seg_list):
    liste=[]
    for t in traces:
        liste+=adjacent_seg(json, t, seg_list)
    return list(set(liste))



def dis_pt_pt(pt1,pt2):
    c1=transfo_coord(pt1['lat'],pt1['lon']) #coordonnées du point 1 
    c2=transfo_coord(pt2['lat'],pt2['lon']) #coordonnées du point 2 
    return sqrt((c1[0]-c2[0])**2+(c1[1]-c2[1])**2)

def vecteur(pt1,pt2):
    c1=transfo_coord(pt1['lat'],pt1['lon']) #coordonnées du point 1 
    c2=transfo_coord(pt2['lat'],pt2['lon']) #coordonnées du point 2 
    return (-(c1[0]-c2[0]),-(c1[1]-c2[1])) #coordonnées du vecteur

def dis_pt_pt2(pt1,c2): 
    '''nouvelle fonction dans le cas où l'on ait que les coordonnées des points, pas forcément la structure de node'''
    c1=transfo_coord(pt1['lat'],pt1['lon']) #coordonnées du point 1 
    
    return sqrt((c1[0]-c2[0])**2+(c1[1]-c2[1])**2)

def vecteur2(pt1,c2): #idem précédent
    c1=transfo_coord(pt1['lat'],pt1['lon']) #coordonnées du point 1 
     
    return (-(c1[0]-c2[0]),-(c1[1]-c2[1])) #coordonnées du vecteur

def produit_scalaire(v1,v2):
    return (v1[0]*v2[0]+v1[1]*v2[1])
    

def pt_projete(c1,c2,c_gps,d12):
    xgps=c_gps[0]
    ygps=c_gps[1]
    x1=c1[0]
    x2=c2[0]
    y1=c1[1]
    y2=c2[1]
    d_projete= ((xgps-x1)*(x2-x1)+(ygps-y1)*(y2-y1))/d12 #distance point1
    #projete orthogonal    
    xproj=x1 + (x2-x1)*d_projete/d12
    yproj=y1 + (y2-y1)*d_projete/d12    
    return (xproj,yproj)
    
    

def dist_pt_segments(traces, json):#retourne une liste de dicos, chaque trace a son dico
    id=max_id(list_node(json))+1
    S=segments_node(json) #liste de tous les segments avec les noeuds associés (le numéro du segment correspond à sa position dans la liste)
    D=[]
    for t in traces:
        list_seg=adjacent_seg(json, t,S) #liste des segments proches de la trace GPS
        
        d={} 
        '''notre valeur de retour contiendra est dico : 'id segments':distance, coord du projeté, noeud à partir duquel faire le dijkstra'''
        
        
        for s in list_seg:
            pt1=S[s][0]
            pt2=S[s][1]
            d12=dis_pt_pt(pt1,pt2)
            c1=transfo_coord(pt1['lat'],pt1['lon']) #coordonnées du point 1 du segment
            c2=transfo_coord(pt2['lat'],pt2['lon']) #coordonnées du point 2 du segment
            c_gps=transfo_coord(t['lat'],t['lon']) #coordonnées du point gps
                  
            c_proj=pt_projete(c1,c2,c_gps,d12)
            
            '''on va distinguer alors les cas ou le projeté se situe sur le segment ou à l'extérieur...
            pour ça on va calculer le produit scalaire (pt1.pt_GPS)x(pt1.pt2)  et le comparer avec (pt1.pt2)x(pt1.pt2)'''
            scal1=produit_scalaire(vecteur2(pt1,c_proj), vecteur(pt1,pt2))
            scal2=produit_scalaire(vecteur(pt1,pt2), vecteur(pt1,pt2))
    
            if scal1<0: #le projeté se trouve à gauche du point 1
                pt=pt1.copy()
                d[s]=(dis_pt_pt(pt1,t),c1,pt)
                
            elif scal1>scal2: #le projeté se trouve à droite du point 2
                pt=pt2.copy()
                d[s]=(dis_pt_pt(pt2,t),c2,pt)
                
            else: 
                #le projeté est dans le segment, on applique pythagore
                #hypothénuse:
                a=dis_pt_pt(pt1,t)
                #petit côté:
                b=dis_pt_pt2(pt1,c_proj)
                #la distance au segment:
                dis=a**2-b**2
                #création du point projeté utilisable dans le graphe:
                pt={'id':id,'x':c_proj[0],'y':c_proj[1]}
                d[s]=(dis,c_proj,pt)
                id+=1
                
            
        D.append(d)            
        
    
    return D

##PARTIE GRAPHE
            
def graphe(json, traces):
    
    S=segments_node(json)
    L=list_points(json, S)
    G={}
    id=max_id(list_node(json))+1
    for i, p in L.items():
        if(i<id):
            G[i]=[]        
            for s in p[1:]:
                d=dis_pt_pt(S[s][0],S[s][1])
                if(S[s][0]['id']==i):
                    G[i].append((S[s][1]['id'],d))
                else:
                    G[i].append((S[s][0]['id'],d))
    for t in traces:                
        #puis on ajoute dans le graphe à la main le projeté des traces (si elle se situe sur le segment, sinon on prend le point le plus proche cf. algo précédent)
        list_seg=adjacent_seg(json, t, S) #liste des segments proches de la trace GPS
        d={} #notre valeur de retour contiendra est dico : 'id segments':distance, coord du projeté, noeud à partir duquel faire le dijkstra
        for s in list_seg:
            pt1=S[s][0]
            pt2=S[s][1]
            d12=dis_pt_pt(pt1,pt2)
            c1=transfo_coord(pt1['lat'],pt1['lon']) #coordonnées du point 1 du segment
            c2=transfo_coord(pt2['lat'],pt2['lon']) #coordonnées du point 2 du segment
            c_gps=transfo_coord(t['lat'],t['lon']) #coordonnées du point gps
                  
            c_proj=pt_projete(c1,c2,c_gps,d12)
            
            
            '''on va distinguer alors les cas ou le projeté se situe sur le segment ou à l'extérieur...
            pour ça on va calculer le produit scalaire (pt1.pt_GPS)x(pt1.pt2)  et le comparer avec (pt1.pt2)x(pt1.pt2)'''
            scal1=produit_scalaire(vecteur2(pt1,c_proj), vecteur(pt1,pt2))
            scal2=produit_scalaire(vecteur(pt1,pt2), vecteur(pt1,pt2))        
            if(0<=scal1 and scal1<=scal2):
                #distance au point 1
                a=dis_pt_pt2(pt1,c_proj)
                #distance au point 2
                b=dis_pt_pt2(pt2,c_proj)
                #création du point projeté utilisable dans le graphe:
                G[id]=[(pt1['id'],a),(pt1['id'],a)]
                
                id+=1
        
        
                
    return G
            
def dijkstra(pt1, G):
    chemin={}
    for id in G.keys():
        chemin[id]={'parent':0,'distance':-1}
    chemin[pt1['id']]['distance']=0
    frontiere=[pt1['id']]
    while (len(frontiere)>0):
        #on pop le noeud dans la frontière avec la plus courte distance du point 1
        min=chemin[frontiere[0]]['distance']
        i=0 #indice de l'objet courant dans la liste frontière
        j=0 #indice de l'objet courant ayant la plus courte distance
        for id in frontiere:
            if chemin[id]['distance']<min:
                min=chemin[id]['distance']
                j=i
            i+=1
        id=frontiere.pop(j)
        
        for voisin in G[id]:
            if(chemin[voisin[0]]['parent']==0):
                frontiere.append(voisin[0])
            nouvelle_dist=voisin[1]+chemin[id]['distance']
            if(chemin[voisin[0]]['distance']==-1 or chemin[voisin[0]]['distance']>nouvelle_dist):#mise à jour des distances 
                chemin[voisin[0]]['distance']=nouvelle_dist
                chemin[voisin[0]]['parent']=id
                
    return chemin
    
   
def chemin(pt1, pt2, G):
    dij=dijkstra(pt1,G)
    id=pt2['id']
    chemin=[]
    while id!=pt1['id']:
        chemin.append(id)
        id=dij[id]['parent']
    chemin.append(id)
    chemin.reverse()
    return chemin


##PARTIE STOCHASTIQUE 

# ATTENTION : les deux fonctions d'estimation ci-dessous (compute_sigma, compute_beta)
# supposent de disposer de traces de RÉFÉRENCE associées à leur vrai segment.
# Elles ne sont PAS branchées sur la chaîne de démonstration (qui fixe sigma=beta=2)
# et présentent des incohérences de signature (pt_projete attend 4 arguments,
# dijkstra renvoie un dictionnaire) : à reprendre avant tout usage réel.
#Parameter estimation
#sigma
def compute_sigma(traces, liste_segments):
    '''fonction qui estime sigma a partir de traces associées à leur vrais segments. Les deux listes ont donc même longueur.'''
    liste_proj = []
    for i in range(len(traces)):
        liste_proj.append(pt_projete(traces[i], liste_segments[i]))
    liste = []
    for i in range(len(traces)):
        liste.append(dis_pt_pt(traces[i], liste_proj[i]))
    return 1.4826*np.median(np.array(liste))

#beta
def compute_beta(traces, liste_segments):
    '''fonction qui estime beta a partir des mêmes bails que sigma'''
    liste_proj = []
    for i in range(len(traces)):
        liste_proj.append(pt_projete(traces[i], liste_segments[i]))
    liste = []
    for i in range(len(traces)-1):
        liste.append(dis_pt_pt(traces[i],traces[i+1]) - dijkstra(liste_proj[i], liste_proj[i+1]))
    return (1/np.log(2))*np.median(np.array(liste))


def normalisation(liste):
    '''fonction pour normaliser une liste de probabilités, de facon a avoir des lignes de somme egale à 1 dans les matrices
    de probabilités A et B, pour utiliser Viterbi.'''
    somme = sum(liste)
    if somme!=0:
        liste_norm = []
        for i in liste:
            liste_norm.append(i/somme)
        return liste_norm
    else: 
        return liste


def matrice_emission(traces, liste_segments, sigma, json, seg_list, D):
    '''liste_segments est une liste des id (entier) de segments
    sigma parametres
    traces est la liste de nos traces GPS sous la forme de noeuds'''
    n = len(liste_segments)
    m = len(traces)
    B = np.zeros((n, m))        # [FIX] zeros -> np.zeros
    
    for j in range(m):
        d=D[j]
        for i in range(n):
            if liste_segments[i] in adjacent_seg(json, traces[j], seg_list):
                # NB: implémentation simplifiée ; la formule (Gaussienne) du rapport comporte un carré : (d/sigma)**2
                B[i][j] = 1/(sigma*sqrt(2*pi)) * exp(-0.5*(d[liste_segments[i]][0]/sigma))
    
    for ligne in range(n):
        B[ligne] = normalisation(B[ligne])

            
    return B
            
    
def matrice_transition(t, traces, liste_segments, beta, json, G,D, seg_list):
    dis1=D[t]
    dis2=D[t+1]
    n = len(liste_segments)
    A = np.zeros((n, n))        # [FIX] zeros -> np.zeros
    liste1=adjacent_seg(json, traces[t], seg_list)
    liste2=adjacent_seg(json, traces[t+1], seg_list)
    for i in range(n):
        if liste_segments[i] in liste2:
            for j in range(n):
                if liste_segments[j] in liste1:
                    pt1=dis1[liste_segments[j]][2]#on récupère ici le point avec lequel on travaille pour dijkstra
                    pt2=dis2[liste_segments[i]][2]
                    
                    dij=dijkstra(pt1,G)
                    plus_court_chemin=dij[pt2['id']]['distance'] 
                    distance=abs(dis_pt_pt(traces[t], traces[t+1])-plus_court_chemin)
                    proba_t = 1/beta*exp(-distance/beta)
                    A[i][j]=proba_t
    for ligne in range(n):
        A[ligne] = normalisation(A[ligne])

    
    return A

#def viterbi(traces, liste_segments, json, beta, sigma, G, D, seg_list):
#    E=matrice_emission(traces, liste_segments, sigma, json, seg_list, D)
#    print(E)
#    n=len(traces)
#    m=len(liste_segments)
#    V=zeros((n,m))
#    ini=adjacent_seg(json, traces[0], seg_list)
#    d=D[0]
#    '''pour l'initialisation on se donne une loi uniforme où la proba est
#    simplement la distance de la 1ère trace au segment adjacent ramenée(puis normalisée)'''
#    for j in range(m):
#        if liste_segments[j] in ini:
#            V[0][j]=d[liste_segments[j]][0]
#            
#    V[0]=normalisation(V[0])
#        
#    for i in range(1,n):#pour chaque étape GPS
#        T=matrice_transition(i-1, traces, liste_segments, beta, json, G, D, seg_list)
#        for j in range(m): #pour chaque segment de routes
#            indice_parent=0
#            max=0
#            for k in range(m): #recherche du plus probable chemin à l'étape i
#                proba=V[i-1][k]*T[j][k]*E[j][i]
#                if proba>=max:
#                    max=proba
#                    indice_parent=k
#            V[i][j]=proba #(proba, indice_parent) normalement...
#        V[i]=normalisation(V[i])
#    
#    return V

def backtrace(z_pred, back, T, labels):
    '''fonction qui renvoit la route dans la maille a la fin de lalgorithme'''
    prev_cursor = z_pred[-1]

    for m in np.arange(T)[::-1]:
        prev_cursor = back[prev_cursor, m]
        z_pred[m] = prev_cursor

    if labels is None:
        return z_pred

    return [labels[z] for z in z_pred]

def viterbi(traces, liste_segments, sigma, beta,json, G, D, seg_list, labels=None):
    '''fonction qui renvoie la route.
    q_size = nombre de routes qu'on garde après tri unique des routes les plus proches
    A = matrice de transition
    X = sequence observee (traces gps)
    B = matrice d emission
    q_init = etat initial = route initiale (a determiner avec ce que renvoie la fonction proba_route_initiale ou avec le dernier point, c'est l'indice dans la liste liste_segments
    de la sequence precedente)'''
    #initialisation, recherche de q_init en prenant simplement la route la plus proche:
    ini=adjacent_seg(json, traces[0], seg_list)
    d=D[0]
    q_init = 0                  # [FIX] valeur par défaut (évite un NameError si aucun segment adjacent)
    best = 0
    for j in range(len(liste_segments)):
        if liste_segments[j] in ini and d[liste_segments[j]][0] >= best:
            best = d[liste_segments[j]][0]
            q_init = j
                                            
    B=matrice_emission(traces, liste_segments, sigma, json, seg_list, D)
    X = np.arange(len(traces))
    A = matrice_transition(0, traces, liste_segments, beta, json, G, D, seg_list)
    q_size = len(liste_segments)
    Q = np.arange(q_size)
    T = len(X)
    p = np.zeros(shape=(len(Q), T))
    back = np.zeros(shape=(len(Q), T), dtype=int)            # [FIX] np.int supprimé depuis NumPy 1.24
    z_pred = np.zeros(shape=(T, ), dtype=int)            # [FIX] np.int supprimé depuis NumPy 1.24

    for q in Q:
        p[q, 0] = A[q_init, q] * B[q, X[0]]
        back[q, 0] = q_init

    # [FIX] la boucle parcourt désormais t = 1..T-1 (l'originale s'arrêtait en T-2,
    # laissant la dernière colonne de p/back non calculée). La transition utilisée
    # est celle de l'étape t-1 vers t, conforme à la version de référence
    # (matrice_transition(i-1, ...)) laissée en commentaire par les auteurs.
    for t in range(1, T):
        A = matrice_transition(t - 1, traces, liste_segments, beta, json, G, D, seg_list)
        for q in Q:
            p[q, t] = np.max([p[qp, t - 1] * A[qp, q] * B[q, X[t]] for qp in Q])
            back[q, t] = np.argmax([p[qp, t - 1] * A[qp, q] for qp in Q])

    z_pred[T - 1] = int(np.argmax([p[q, T - 1] for q in Q]))

    return backtrace(z_pred, back, T, labels) #retourne une liste de routes, reste plus qu'à projeter la trace t  sur la route t
                    

              
    
##PARTIE TRACE  

        
def plot_routes(json, traces, sequence_segments, seg_list, liste_segments, small=False):
    """liste_segments: liste des segments candidats, dont le numéro est l'index dans seg_list
    sequence_segments: sequence des index de segments choisi par Viterbi, index de la liste_segments
    seg_list: liste de tuples de points, ou la position est le numéro du segment"""
    marche=10 #tous les 10 mètres on rajoute un noeud
    dico = json['elements']
    #Création des listes de routes et de noeuds
    node_list = []
    way_list = []
    
    for i in dico:
        if i['type'] == "node":
            node_list.append(i)
        elif i['type'] == "way":
            way_list.append(i)
            
    if small == True:
        way_list = way_list[:50]

    #Création de la figure
    X, Y = {}, {}
    plt.figure(figsize=[10,10])
    for way in way_list:
        color='black'
        x, y = [], []
        for i in way['nodes']:
            for curNode in node_list:
                if i == curNode['id']:
                    c=transfo_coord(curNode['lat'],curNode['lon'])
                    x.append(c[0])
                    y.append(c[1])
        X[str(way['id'])] = x
        Y[str(way['id'])] = y
#        if(way['tags']['highway'] in ['motorway','trunk','motorway_link','trunk_link','escape']):
#            color='red'
#        elif(way['tags']['highway'] in ['primary','secondary','tertiary','unclassified','residential','primary_link','secondary_link','tertiary_link','living_street']):
#            color='green'
#        elif(way['tags']['highway'] in ['footway','bridleway','steps','path','track','road','cycleway']):
#            color='blue'
#        elif(way['tags']['highway'] in ['construction','service','bus_guideway']):
#            color='orange'
        plt.plot(x,y, c='black')
    
    x=[]
    y=[]
    for t in traces:
        x.append(transfo_coord(t['lat'],t['lon'])[0])
        y.append(transfo_coord(t['lat'],t['lon'])[1])
    plt.scatter(x,y,c='red')
   
    
    for s in sequence_segments:
        x=[]
        y=[]
        pt1=seg_list[liste_segments[s]][0]
        pt2=seg_list[liste_segments[s]][1]
        c1=transfo_coord(pt1['lat'],pt1['lon'])
        c2=transfo_coord(pt2['lat'],pt2['lon'])
        x.append(c1[0])
        x.append(c2[0])
        y.append(c1[1])
        y.append(c2[1])
        plt.plot(x,y,c='blue')
        
    
    plt.show()
    return X, Y    

        
   

##PARTIE TEST

if __name__ == "__main__":
    seg_list = segments_node(data_dict)
    traces = trackpoint_creation(trackpoint, data_dict)
    liste_segments = ensemble_segments(data_dict, traces, seg_list)

    # --- PHASE 1 : générer la séquence de segments (décommenter le bloc) -------
    # G = graphe(data_dict, traces)
    # D = dist_pt_segments(traces, data_dict)
    # V = viterbi(traces, liste_segments, 2, 2, data_dict, G, D, seg_list)
    # print(V)   # copier la liste affichée dans la variable seq de la PHASE 2

    # --- PHASE 2 : tracer le matching (décommenter le bloc) --------------------
    # seq = []   # <-- coller ici la liste obtenue en PHASE 1 (entiers séparés par des virgules)
    # plot_routes(data_dict, traces, seq, seg_list, liste_segments)



#noeuds de test pour la fonction chemin:  
    
d={
      "type": "node",
      "id": 1442397068,
      "lat": 48.712637,
      "lon": 2.167883
    }

a={
      "type": "node",
      "id": 1442397072,
      "lat": 48.7118492,
      "lon": 2.1689122
    }





 