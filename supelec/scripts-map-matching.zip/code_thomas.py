# -*- coding: utf-8 -*-
"""
Created on Fri May 17 12:50:31 2019

@author: E5470
"""

def backtrace(z_pred, back, T, labels):
#    '''fonction qui renvoit la route dans la maille a la fin de lalgorithme'''
    prev_cursor = z_pred[-1]

    for m in np.arange(T)[::-1]:
        prev_cursor = back[prev_cursor, m]
        z_pred[m] = prev_cursor

    if labels is None:
        return z_pred

    return [labels[z] for z in z_pred]
    
def viterbi(traces, B, q_init, segments, beta, labels=None):
#    '''fonction qui renvoie la route.
#    q_size = nombre de routes qu'on garde après tri unique des routes les plus proches
#    A = matrice de transition
#    X = sequence observee (traces gps)
#    B = matrice d emission
#    q_init = etat initial = route initiale (a determiner avec ce que renvoie la fonction proba_route_initiale ou avec le dernier point
#    de la sequence precedente)'''
    X = np.arange(len(traces))
    A = matrice_transition(0, traces, segments, beta)
    q_size = len(segments)
    Q = np.arange(q_size)
    T = len(X)
    p = np.zeros(shape=(len(Q), T))
    back = np.zeros(shape=(len(Q), T), dtype=np.int)
    z_pred = np.zeros(shape=(T, ), dtype=np.int)

    for q in Q:
        p[q, 0] = A[q_init, q] * B[q, X[0]]
        back[q, 0] = q_init

    for t in np.arange(T)[1:len(T)-1]:
        A = matrice_transition(t, traces, segments, beta)
        for q in Q:
            p[q, t] = np.max([p[qp, t - 1] * A[qp, q] * B[q, X[t]] for qp in Q])
            back[q, t] = np.argmax([p[qp, t - 1] * A[qp, q] for qp in Q])

    z_pred[T - 1] = np.argmax([p[q, T - 1] for q in Q])

    return backtrace(z_pred, back, T, labels) #retourne une liste de segments, reste plus qu'à projeter la trace t  sur la route t 
    
    
        
def run(route_initiale, traces, liste_segments, sigma, beta, json):
    #route initiale est la route ou on est avant le premier point
    #traces c'est 10 traces successives par exemple
    #segments c'est la liste des segments qui nous intéressent, à savoir ceux proches de nos 10 traces
    #(il faut donc les déterminer avant et la route initiale doit en faire partie)
    #beta et sigma sont à déterminer avant également avec des traces test dont on connait la vraie position sur la route
    #calculer la matrice B
    B = matrice_emission(traces, liste_segments, sigma, json) 
    #lancer viterbi sur les 10 traces sachant que l'état initial doit etre connu
    for ind, seg in enumerate(segments):
        if seg == route_initiale:
            q_init = ind 
    trajet = viterbi(traces, B, q_init, segments, beta, labels=segments)
    liste_proj = []
    for ind, t in enumerate(traces):
        liste_proj.append(pt_projete(t, trajet[ind]))
    return liste_proj        
    
    
    
 