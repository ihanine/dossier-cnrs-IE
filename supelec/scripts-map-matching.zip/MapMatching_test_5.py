import matplotlib.pyplot as plt
import numpy as np
import json
import random as rdm

with open('C:/Users/admin/Documents/Travail/projet conception/small.json') as json_data:
    data_dict = json.load(json_data)

dico = data_dict['elements'] # liste des éléments du json 

GPS_small_test=[(48.7106,2.1650),(48.7102,2.1648),(48.7100,2.1648),(48.7101,2.1645),(48.7104,2.1640)]
GPS_test= [(1.8,4.1),(2.5,3.9),(3,4.05),(4,3.8),(5,4.1),(7.8,4.2),(8.1,5.5),(8,7),(11,9)]

def trace_GPS(liste_points):
    """Dessine les points du relevé GPS"""
    X=[]
    Y=[]
    for point in liste_points : 
        X.append(point[0])
        Y.append(point[1])
    plt.plot(X,Y,'ro')

def dist_pt_pt(pt1,pt2):
    (x1,y1),(x2,y2)=pt1,pt2
    return np.sqrt((x2-x1)**2+(y2-y1)**2)

def dist_pt_segment(pt_gps,segment):
    (xgps,ygps)=pt_gps
    pt1=segment[0]
    pt2=segment[1]
    [(x1,y1),(x2,y2)]=segment
    d12=dist_pt_pt(pt1,pt2) #longueur du segment
    d1gps=dist_pt_pt(pt_gps,pt1) #distance point_GPS/ point1
    d_projete= ( (xgps-x1)*(x2-x1)+(ygps-y1)*(y2-y1) ) / d12 #distance point1#projete orthogonale
    distance_gps_12 = np.sqrt( d1gps**2 - d_projete**2) #distance du point au segment
    
    if (xgps-x1)*(x2-x1)+(ygps-y1)*(y2-y1)<0:
        distance_gps_12 = dist_pt_pt(pt_gps,pt1)
    if (xgps-x2)*(x1-x2)+(ygps-y2)*(y1-y2)<0:
        distance_gps_12= dist_pt_pt(pt_gps,pt2)
    
    return distance_gps_12
    
def pt_projete(pt_gps,segment):
    (xgps,ygps)=pt_gps
    [(x1,y1),(x2,y2)]=segment
    pt1=segment[0]
    pt2=segment[1]
    d12=dist_pt_pt(pt1,pt2) #longueur du segment
    d1gps=dist_pt_pt(pt_gps,pt1) #distance point_GPS/ point1
    d_projete= ( (xgps-x1)*(x2-x1)+(ygps-y1)*(y2-y1) ) / d12 #distance point1#projete orthogonale
    
    xproj=x1 + (x2-x1)*d_projete/d12
    yproj=y1 + (y2-y1)*d_projete/d12
    
    if (xgps-x1)*(x2-x1)+(ygps-y1)*(y2-y1)<0: #si noeud d'intersection ... a revoir
        xproj=x1
        yproj=y1
    if (xgps-x2)*(x1-x2)+(ygps-y2)*(y1-y2)<0:
        xproj=x2
        yproj=y2
    
    return (xproj,yproj)
    

def projete(GPS_test,X,Y,all = False):
    """projete l'ensemble des points GPS sur les routes"""
    X_gps_projete=[] #liste des coordonnés projetés
    Y_gps_projete=[]
    X_gps_projete_all=[] #liste des coordonnés projetés sur toute les routes
    Y_gps_projete_all=[]
    n_nearest_road=2 #on regarde les n routes les plus proches de chaque point
   
    projete_all_all=[]
    n_ways = 3 #nombre de routes les plus proches à considérer pour chaque point
    
    for pt in GPS_small_test:
        projete_gps_way=[]
        xgps,ygps=pt[0],pt[1]
        nearest_ways = rdm.sample(X.keys(),n_nearest_road) #initialise avec une route quelconque
        nearest_way= nearest_ways[0]
        min_dist= dist_pt_segment(pt,[(X[nearest_way][0],Y[nearest_way][0]),(X[nearest_way][1],Y[nearest_way][1])]) #distance  minimale avec toute les routes
    
        xproj,yproj=0,0 #coordonné du projete
    
        for way in X: #Pour chaque route (X et Y ont les mêmes clés)
            min_dist_way= dist_pt_segment(pt,[(X[way][0],Y[way][0]),(X[way][1],Y[way][1])]) #distance minimale avec un segment de la route
    
            for i in range(len(X[way])-1): #Pour chaque segment de la route -> on projete le pt_gps sur la route
                dist=dist_pt_segment((xgps,ygps),[(X[way][i],Y[way][i]),(X[way][i+1],Y[way][i+1])])
                if dist<=min_dist_way:
                    min_dist_way=dist
                    xproj_way,yproj_way=pt_projete((xgps,ygps),[(X[way][i],Y[way][i]),(X[way][i+1],Y[way][i+1])])
    
                if dist<=min_dist:
                    nearest_way=way
                    min_dist=dist
                    xproj,yproj=pt_projete((xgps,ygps),[(X[way][i],Y[way][i]),(X[way][i+1],Y[way][i+1])])
    
            X_gps_projete_all.append(xproj_way)
            Y_gps_projete_all.append(yproj_way)
            projete_gps_way.append([min_dist_way,xproj_way,yproj_way])
    
        X_gps_projete.append(xproj)
        Y_gps_projete.append(yproj)
        
        if projete_all_all==[]:
            #on ajoute les projete du point sur les n_ways routes les plus proches
            projete_all_all= (np.array(sorted(projete_gps_way, key=lambda tup : tup[0])) [:n_ways,1:3]) 
            
        else : 
            projete_all_all=np.concatenate((projete_all_all, np.array(sorted(projete_gps_way, key=lambda tup : tup[0])) [:n_ways,1:3]))
 
    if all : #si on veut projeter sur toute les routes
        plt.plot(X_gps_projete_all,Y_gps_projete_all,'go')
    
    #plt.plot(X_gps_projete,Y_gps_projete,'bo')
    plt.plot(projete_all_all[:,0],projete_all_all[:,1], 'go')

    
    

def classification_node_cell():
    """range les noeuds dans des cellules en effectuant un quadrillage de la fenetre"""
    dico = data_dict['elements']
    
    X_list=[]
    Y_list=[]
    for node in node_list:
        X_list.append(node['lon'])
        Y_list.append(node['lat'])
    
    n_cell_x = 5;
    n_cell_y= 5;
    
    x_max = max(X_list)
    y_max = max(Y_list)
    x_min = min(X_list)
    y_min = min(Y_list)
    
    cells=[]
    for i in range(n_cell_x):
        cells.append([])
        for j in range(n_cell_y):
            cells[i].append([])
            
    for node in node_list:
        x= node['lon']
        y= node['lat']
        i=(int)(((x-x_min)*n_cell_x)//(x_max-x_min))-1
        j=(int)(((y-y_min)*n_cell_y)//(y_max-y_min))-1
        cells[i][j].append(node)
        
def extraction_node_way():
    """Création des listes de routes et de noeuds"""
    node_list = []
    way_list = []
    
    for i in dico:
        if i['type'] == "node":
            node_list.append(i)
        elif i['type'] == "way":
            way_list.append(i)
            
    return (node_list,way_list)
    

def plot_routes(node_list,way_list):
    """Dessine les routes"""
#    if small == True:
#        way_list = way_list[:50]

    #Création de la figure
    X, Y = {}, {}

    for way in way_list:
        x, y = [], []
        for i in way['nodes']:
            for curNode in node_list:
                if i == curNode['id']:
                    x.append(curNode['lat'])
                    y.append(curNode['lon'])
        X[str(way['id'])] = x
        Y[str(way['id'])] = y
        plt.plot(x, y)
    plt.show()
    return X, Y
    
def extract_intersection(X,Y):
    intersection=[]
    for way in X:
        for i in range(len(X[way])):
            for other_way in X:
                if other_way != way:
                    for j in range(len(X[other_way])):
                        if X[way][i]==X[other_way][j] and Y[way][i]==Y[other_way][j]:
                            intersection.append([X[way][i],Y[way][i],way,other_way])
    
    I=np.array(intersection)
    plt.plot(I[:,0],I[:,1],'bo')

    return intersection

def make_graphe(way_list,node_list):
    graphe=[]
    edges={}
    for way in way_list:
        l_nodes_way=[]
        for node_way in way['nodes']:
            for node in node_list:
                if node_way==node['id']:
                    l_nodes_way.append=((node['id'],node['lat'],node['lon']))
                
        edges[str(way['id'])]=l_nodes_way
                    
    for way in edges:
        for i_node in range(len(way)-1):
            node1=way[i_node]
            node2=way[i_node+1]
            pt1=(node1[1],node1[2])
            pt2=(node2[1],node2[2])
            id1=str(node1[0])
            id2=str(node2[0])
            graphe.append((id1,id2,dist_pt_pt(pt1,pt2)))
            
    return edges,graphe
                    
    
    

def run():
    node_list,way_list= extraction_node_way()
    trace_GPS(GPS_small_test)
    X,Y=plot_routes(node_list,way_list)
    projete(GPS_small_test,X,Y)
    intersection = extract_intersection(X,Y)
    
   # return make_graphe(way_list,node_list)
    
    
    
