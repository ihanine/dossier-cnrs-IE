================================================================================
 Map Matching — mode d'emploi
================================================================================

Fichiers
--------
  MapMatching.py            Script principal (chaîne complète : données, graphe,
                            estimation, matrices d'émission/transition, Viterbi,
                            tracé). C'est celui à utiliser.
  code_thomas.py            Version préliminaire de Viterbi/run (historique).
  MapMatching_test_5.py     Prototype de visualisation sur données synthétiques.
  *.gpx                     Traces GPS d'exemple (secteurs Corbeville, Guichet).
  README.txt                Ce fichier.

Prérequis
---------
  Python 3, avec : numpy, matplotlib.
      pip install numpy matplotlib

Données
-------
  L'algorithme attend un export OpenStreetMap au format JSON (objets « node » et
  « way »). Renseigner son chemin dans la variable JSON_PATH, en tête de
  MapMatching.py (par défaut : "medium.json").

  La liste `trackpoint` (en tête de MapMatching.py) contient les traces GPS à
  réaligner, sous la forme [lon, lat]. Par défaut, 15 traces y sont fournies à
  titre d'exemple ; les remplacer par les vôtres au besoin.

Exécution (deux phases)
-----------------------
  Lancer :  python3 MapMatching.py

  PHASE 1 — génération de la séquence de segments
     Dans le bloc « if __name__ == '__main__' », décommenter les lignes :
         G = graphe(data_dict, traces)
         D = dist_pt_segments(traces, data_dict)
         V = viterbi(traces, liste_segments, 2, 2, data_dict, G, D, seg_list)
         print(V)
     La console affiche une liste de segments, p. ex. [25, 32, 0, 0, 0, 0, 121].
     Recommenter ces lignes ensuite.

  PHASE 2 — tracé du matching
     Décommenter les lignes :
         seq = []   # y coller la liste obtenue en PHASE 1 (entiers, séparés par des virgules)
         plot_routes(data_dict, traces, seq, seg_list, liste_segments)
     La figure affiche : la carte (noir), les traces GPS (rouge) et le
     matching (bleu). Les couleurs sont modifiables dans la fonction
     plot_routes (paramètre `c=` des appels plt.plot / plt.scatter).

Remarques
---------
  - Les paramètres sigma et beta sont fixés à 2 dans l'appel de démonstration.
  - La complexité limite l'usage à de petits graphes (voir le rapport, §5).

Bon matching !
