"""
Sélection d'angles de capteurs par Particle Swarm Optimization (PSO).

On minimise directement le critère d'A-optimalité
    MSE(theta) = trace((Phi Phi^H)^{-1})
sur des angles continus, chaque capteur étant contraint à rester dans une plage
autorisée.

NB : par rapport au code d'origine, l'objectif passé à `pso` était
`sum(||ligne de Phi||^2)`, qui vaut EO*K quelles que soient les positions
(les entrées de Phi sont de module 1) -> fonction constante. Il est remplacé ici
par le vrai critère MSE.
"""

import numpy as np
from pyswarm import pso

from model import EO, mse, condition_number, allowed_ranges_rad, is_allowed


def _bounds(n_sensors):
    """Bornes lb/ub : les capteurs sont répartis cycliquement sur les plages autorisées."""
    ranges = allowed_ranges_rad()
    lb, ub = [], []
    for i in range(n_sensors):
        lo, hi = ranges[i % len(ranges)]
        lb.append(lo)
        ub.append(hi)
    return lb, ub


def _constraint_allowed(x):
    """Contrainte d'inégalité pyswarm (>= 0 si admissible) : tous les angles autorisés.

    (Redondante avec les bornes ci-dessus, mais explicite la contrainte physique.)
    """
    return [1.0 if all(is_allowed(xi) for xi in x) else -1.0]


def select(n_sensors, eo=EO, **pso_kwargs):
    """Renvoie les angles (rad, triés) sélectionnés pour `n_sensors` capteurs."""
    lb, ub = _bounds(n_sensors)
    xopt, _ = pso(lambda x: mse(x, eo), lb, ub,
                  f_ieqcons=_constraint_allowed, **pso_kwargs)
    return np.sort(xopt)


def run(eo=EO, l_max=15):
    """Sélection pour K = eo..l_max capteurs ; renvoie une liste de dictionnaires."""
    results = []
    for k in range(eo, l_max + 1):
        sel = select(k, eo)
        results.append({"pos": sel, "mse": mse(sel, eo), "cond": condition_number(sel, eo)})
    return results


if __name__ == "__main__":
    for d in run():
        print("K =", len(d["pos"]), "| MSE =", round(d["mse"], 4),
              "| cond =", round(d["cond"], 4))
