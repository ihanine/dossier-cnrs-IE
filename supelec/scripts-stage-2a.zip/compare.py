"""
Comparaison des trois méthodes de sélection d'angles de capteurs (Frank-Wolfe,
FrameSense et, si pyswarm est installé, PSO) : MSE (A-optimalité) et
conditionnement en fonction du nombre de capteurs K.

Remplace l'ancien `perf.py` (qui ne tournait pas : np.inv, np.transpose.conj,
points.append(a, b, c), appel d'un module comme fonction...).
"""

import matplotlib.pyplot as plt

from model import EO, candidate_angles, mse, condition_number
import frank_wolfe
import frame_sense

try:
    import pso
    HAS_PSO = True
except ImportError:
    HAS_PSO = False   # pyswarm absent : on compare seulement Frank-Wolfe et FrameSense


def compare(eo=EO, l_max=15, step_deg=1.0):
    """Calcule MSE et conditionnement pour chaque méthode et K = eo..l_max."""
    angles = candidate_angles(step_deg)
    ks = list(range(eo, l_max + 1))
    rows = []
    for k in ks:
        # variante "support" : angles distincts (la variante "sommets visités"
        # peut sélectionner des angles dupliqués -> Phi mal conditionnée)
        fw = frank_wolfe.select(k, eo, angles, support=True)
        fs = frame_sense.select(k, eo, angles)
        row = {"K": k,
               "mse_fw": mse(fw, eo), "cond_fw": condition_number(fw, eo),
               "mse_fs": mse(fs, eo), "cond_fs": condition_number(fs, eo)}
        if HAS_PSO:
            ps = pso.select(k, eo)
            row["mse_pso"] = mse(ps, eo)
            row["cond_pso"] = condition_number(ps, eo)
        rows.append(row)
    return ks, rows


def plot_comparison(eo=EO, l_max=15, step_deg=1.0):
    ks, rows = compare(eo, l_max, step_deg)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

    ax1.plot(ks, [r["mse_fw"] for r in rows], "-o", label="Frank-Wolfe")
    ax1.plot(ks, [r["mse_fs"] for r in rows], "-s", label="FrameSense")
    if HAS_PSO:
        ax1.plot(ks, [r["mse_pso"] for r in rows], "-^", label="PSO")
    ax1.set_xlabel("Nombre de capteurs K")
    ax1.set_ylabel("MSE = trace((Phi Phi^H)^-1)")
    ax1.set_yscale("log")
    ax1.set_title("A-optimalite")
    ax1.legend(); ax1.grid(True, which="both", alpha=0.3)

    ax2.plot(ks, [r["cond_fw"] for r in rows], "-o", label="Frank-Wolfe")
    ax2.plot(ks, [r["cond_fs"] for r in rows], "-s", label="FrameSense")
    if HAS_PSO:
        ax2.plot(ks, [r["cond_pso"] for r in rows], "-^", label="PSO")
    ax2.set_xlabel("Nombre de capteurs K")
    ax2.set_ylabel("Conditionnement de Phi")
    ax2.set_title("Qualite numerique")
    ax2.legend(); ax2.grid(True, alpha=0.3)

    fig.suptitle("Comparaison des methodes de selection d'angles")
    fig.tight_layout()
    plt.show()
    return ks, rows


if __name__ == "__main__":
    plot_comparison()
