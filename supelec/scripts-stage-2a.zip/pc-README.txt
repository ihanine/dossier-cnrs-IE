================================================================================
 SÉLECTION OPTIMALE D'ANGLES DE CAPTEURS
================================================================================

Code de stage réorganisé pour la sélection des positions angulaires de capteurs
autour d'une machine tournante, en vue d'estimer au mieux les harmoniques d'ordre
moteur. Trois méthodes sont comparées : PSO, Frank-Wolfe et FrameSense.


PROBLÈME ET CRITÈRE
--------------------------------------------------------------------------------
On veut placer K capteurs à des angles theta choisis dans des plages autorisées
(le reste de la circonférence -- le "casing" -- est interdit au montage). Pour un
jeu d'angles S, la matrice d'observation est :

    Phi(S) = [ phi(theta_j) ]_{j in S}   de taille (EO, K),
    phi(theta) = [ e^{-j·1·theta}, e^{-j·2·theta}, ..., e^{-j·EO·theta} ]^T

où EO est l'ordre moteur maximal. La matrice de Gram G = Phi Phi^H est
proportionnelle à l'information de Fisher ; la covariance d'estimation est
proportionnelle à G^{-1}. On cherche donc les angles minimisant le critère
d'A-optimalité :

    MSE(S) = trace( G^{-1} )

le conditionnement de Phi servant de critère secondaire de qualité numérique.


LES TROIS MÉTHODES
--------------------------------------------------------------------------------
PSO (pso.py)
    Minimise directement MSE(theta) sur des angles continus, chaque capteur étant
    borné à une plage autorisée (bibliothèque pyswarm).

Frank-Wolfe (frank_wolfe.py)
    Relâche le problème en une distribution de probabilité a sur les angles
    candidats, puis l'optimise par descente de Frank-Wolfe (pas gamma = 2/(k+2)).
    Deux extractions : les K sommets visités (frank_wolfe) et les K plus gros
    poids de la distribution finale (frank_wolfe_support).

FrameSense (frame_sense.py)
    Part de tous les angles candidats et retire gloutonnement celui dont la
    suppression minimise le potentiel de trame ||Phi Phi^T||_F^2, jusqu'à n'en
    garder que K.


ORGANISATION DES FICHIERS
--------------------------------------------------------------------------------
    model.py         Modèle commun : configuration (ordre moteur, plages
                     autorisées, grille d'angles) et critères (steering_matrix,
                     mse, condition_number).
    pso.py           Sélection par PSO.
    frank_wolfe.py   Sélection par Frank-Wolfe (+ variante "support").
    frame_sense.py   Sélection par FrameSense.
    compare.py       Comparaison des trois méthodes (MSE et conditionnement vs K)
                     avec tracé.

Chaque module algorithmique expose la même interface : select(K) renvoie les
angles retenus (radians, triés) et run() balaie K = EO ... L_max en renvoyant une
liste de {"pos", "mse", "cond"}.


DÉPENDANCES ET EXÉCUTION
--------------------------------------------------------------------------------
    pip install numpy matplotlib pyswarm
    python compare.py        # comparaison + graphe (FW et FrameSense ; PSO si pyswarm présent)

En interactif :

    import frank_wolfe, frame_sense, pso, model
    frank_wolfe.select(7)             # 7 angles par Frank-Wolfe
    frame_sense.select(7)             # 7 angles par FrameSense
    model.mse(frame_sense.select(7))  # critère A-optimal associé

La géométrie se règle dans model.py : EO (ordre moteur) et ALLOWED_RANGES_DEG
(plages autorisées). Le pas de la grille d'angles se passe en argument :
model.candidate_angles(step_deg=...).


NETTOYAGE EFFECTUÉ (par rapport aux scripts d'origine)
--------------------------------------------------------------------------------
Consolidation de huit scripts redondants vers ce module :

  - PSO.py + PSO_test.py -> pso.py. L'objectif passé à pso était
    sum(||ligne de Phi||^2), qui vaut EO·K quelles que soient les positions (les
    entrées de Phi sont de module 1) : c'était une fonction CONSTANTE. Il est
    remplacé par le vrai critère MSE.

  - frank_wolfe.py + fw_bis_.py + fw_systematique.py -> frank_wolfe.py. La mise à
    jour d'origine  a <- a + gamma·e  (sans le facteur (1-gamma)) ne préservait
    pas une distribution ; corrigée en  a <- (1-gamma)·a + gamma·e. L'idée de
    fw_systematique (itérer longtemps puis échantillonner le support) est reprise
    dans frank_wolfe_support.

  - FrameSense.py -> frame_sense.py (et la copie présente dans opti_stage.py est
    supprimée).

  - opti_stage.py -> SUPPRIMÉ : monolithe recopiant les trois algorithmes avec
    des paramètres divergents ; remplacé par les modules + compare.py.

  - perf.py -> compare.py : l'original ne s'exécutait pas (np.inv,
    np.transpose.conj, points.append(a, b, c), appel d'un module comme une
    fonction...).

Autres corrections : np.matrix (déprécié) et .getH() remplacés par des ndarray et
.conj().T ; grilles d'angles incohérentes d'un fichier à l'autre (0-250°, 0-50°,
plages disjointes...) centralisées dans model.py ; convention d'ordre uniformisée
en 1..EO (certains fichiers utilisaient 0..EO-1) ; pseudo-inverse partout pour la
robustesse lorsque K < EO.


LIMITES CONNUES
--------------------------------------------------------------------------------
La variante "sommets visités" de Frank-Wolfe peut revisiter le même candidat et
donc sélectionner des angles dupliqués (sur une grille grossière), conduisant à
une Phi mal conditionnée ; préférer frank_wolfe_support ou une grille plus fine
(compare.py utilise la variante "support").

FrameSense glouton est en O(L^3) ; augmenter step_deg (donc réduire le nombre de
candidats L) si le calcul est trop long.

