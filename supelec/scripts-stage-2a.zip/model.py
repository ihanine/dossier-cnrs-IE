"""
Modèle commun pour la sélection optimale d'angles de capteurs.

Problème
--------
Placer K capteurs à des angles theta autour d'une machine tournante pour estimer
au mieux les harmoniques d'ordre moteur 1..EO. Pour un jeu d'angles S, la matrice
d'observation (steering matrix) est

    Phi(S) = [ phi(theta_j) ]_{j in S}   de taille (EO, K),
    phi(theta) = [ e^{-j*1*theta}, e^{-j*2*theta}, ..., e^{-j*EO*theta} ]^T.

La matrice de Gram G = Phi Phi^H (EO x EO) est proportionnelle à l'information de
Fisher ; la covariance d'estimation est proportionnelle à G^{-1}. On cherche donc
les angles qui minimisent le critère d'A-optimalité

    MSE(S) = trace( G^{-1} ).

Le conditionnement de Phi fournit un critère secondaire de qualité numérique.

Ce module centralise la configuration (ordre moteur, plages autorisées, grille
d'angles candidats) et les deux critères, partagés par les trois algorithmes.
"""

import numpy as np

# --- Configuration du problème ------------------------------------------------
EO = 5  # ordre moteur maximal (engine order)

# Plages angulaires (en degrés) où un capteur PEUT être placé. Le complément
# correspond au "casing" : zones physiquement interdites au montage d'un capteur.
ALLOWED_RANGES_DEG = [(0, 50), (140, 160), (220, 250), (280, 300)]


def allowed_ranges_rad():
    """Plages autorisées converties en radians."""
    return [(np.deg2rad(a), np.deg2rad(b)) for a, b in ALLOWED_RANGES_DEG]


def candidate_angles(step_deg=1.0):
    """Grille discrète des angles candidats (radians) dans les plages autorisées."""
    angles = []
    for a, b in ALLOWED_RANGES_DEG:
        angles.extend(np.deg2rad(np.arange(a, b, step_deg)))
    return np.asarray(angles, dtype=float)


def is_allowed(theta):
    """True si l'angle theta (rad) appartient à une plage autorisée."""
    return any(lo <= theta <= hi for lo, hi in allowed_ranges_rad())


# --- Matrice d'observation et critères ----------------------------------------
def steering_matrix(angles, eo=EO):
    """Phi de taille (eo, K) : Phi[l-1, j] = exp(-1j * l * angles[j]), l = 1..eo."""
    angles = np.asarray(angles, dtype=float)
    orders = np.arange(1, eo + 1)
    return np.exp(-1j * np.outer(orders, angles))


def gram(angles, eo=EO):
    """Matrice de Gram G = Phi Phi^H, de taille (eo, eo)."""
    phi = steering_matrix(angles, eo)
    return phi @ phi.conj().T


def mse(angles, eo=EO):
    """Critère d'A-optimalité : trace((Phi Phi^H)^{-1}).

    On utilise la pseudo-inverse (robuste lorsque K < eo, où G est singulière).
    """
    return float(np.abs(np.trace(np.linalg.pinv(gram(angles, eo)))))


def condition_number(angles, eo=EO):
    """Conditionnement de la matrice d'observation Phi (critère numérique secondaire)."""
    return float(np.abs(np.linalg.cond(steering_matrix(angles, eo))))
