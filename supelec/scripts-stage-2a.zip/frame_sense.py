"""
Sélection d'angles de capteurs par FrameSense (Ranieri, Chebira, Vetterli, 2014).

Élimination gloutonne "worst-out" : on part de tous les angles candidats et on
retire itérativement celui dont la suppression laisse le plus petit potentiel de
trame (frame potential), proxy de l'A-optimalité, jusqu'à n'en garder que K.

Le potentiel de trame est calculé sur la représentation réelle de la matrice
d'observation : chaque angle est décrit par [cos(l.theta), -sin(l.theta)]_{l=1..eo}
(lignes normalisées), équivalent réel des vecteurs de pointage complexes.
"""

import numpy as np

from model import EO, candidate_angles, mse, condition_number


def _real_frame(angles, eo=EO):
    """Trame réelle normalisée : lignes = angles, colonnes = [cos, -sin] d'ordres 1..eo."""
    angles = np.asarray(angles, dtype=float)
    orders = np.arange(1, eo + 1)
    cos_part = np.cos(np.outer(angles, orders))
    sin_part = -np.sin(np.outer(angles, orders))
    phi = np.hstack([cos_part, sin_part])
    return phi / np.linalg.norm(phi, axis=1, keepdims=True)


def frame_potential(phi):
    """FP(Phi) = ||Phi Phi^T||_F^2."""
    return float(np.linalg.norm(phi @ phi.T) ** 2)


def frame_sense(n_sensors, eo=EO, angles=None):
    """Indices (dans `angles`) des `n_sensors` capteurs retenus."""
    if angles is None:
        angles = candidate_angles()
    phi = _real_frame(angles, eo)
    kept = list(range(len(angles)))
    while len(kept) > n_sensors:
        # retirer l'indice dont la suppression minimise le potentiel de trame restant
        worst, best_fp = kept[0], np.inf
        for idx in kept:
            remaining = [i for i in kept if i != idx]
            fp = frame_potential(phi[remaining])
            if fp < best_fp:
                best_fp, worst = fp, idx
        kept.remove(worst)
    return kept


def select(n_sensors, eo=EO, angles=None):
    """Renvoie les angles (rad, triés) sélectionnés."""
    if angles is None:
        angles = candidate_angles()
    return np.sort(angles[frame_sense(n_sensors, eo, angles)])


def run(eo=EO, l_max=12):
    angles = candidate_angles()
    results = []
    for k in range(eo, l_max + 1):
        sel = select(k, eo, angles)
        results.append({"pos": sel, "mse": mse(sel, eo), "cond": condition_number(sel, eo)})
    return results


if __name__ == "__main__":
    for d in run():
        print("K =", len(d["pos"]), "| MSE =", round(d["mse"], 4),
              "| cond =", round(d["cond"], 4))
