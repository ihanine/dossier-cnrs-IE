"""
Sélection d'angles de capteurs par l'algorithme de Frank-Wolfe.

Relaxation continue : on optimise une distribution de probabilité a sur les angles
candidats. À l'itération k, avec G = (Phi diag(a) Phi^H)^{-1}, le gradient du
critère d'A-optimalité par rapport au poids du candidat i est

    dA_i = | phi_i^H G G phi_i |.

On se déplace vers le sommet (capteur) de plus fort gradient, avec un pas
gamma = 2/(k+2) et la mise à jour  a <- (1-gamma) a + gamma e_{i*}.

Deux extractions des positions sont proposées :
  - frank_wolfe()          : les K sommets visités (extraction standard) ;
  - frank_wolfe_support()  : les K plus gros poids de la distribution finale
                             (idée de l'échantillonnage "systématique").

NB : la maj du code d'origine était  a <- a + gamma e  (sans le facteur (1-gamma)),
donc a ne restait pas une distribution ; corrigé ici.
"""

import numpy as np

from model import EO, candidate_angles, steering_matrix, mse, condition_number


def _grad(phi, a):
    """Gradient dA_i = |phi_i^H G G phi_i| avec G = (Phi diag(a) Phi^H)^{-1}."""
    g = np.linalg.pinv(phi @ np.diag(a) @ phi.conj().T)
    gg = g @ g
    return np.array([np.abs(phi[:, i].conj() @ gg @ phi[:, i]) for i in range(phi.shape[1])])


def frank_wolfe(n_sensors, eo=EO, angles=None):
    """Indices (dans `angles`) des `n_sensors` sommets visités par Frank-Wolfe."""
    if angles is None:
        angles = candidate_angles()
    phi = steering_matrix(angles, eo)          # (eo, L)
    L = phi.shape[1]
    a = np.full(L, 1.0 / L)                    # distribution uniforme initiale
    chosen = []
    for k in range(n_sensors):
        i_max = int(np.argmax(_grad(phi, a)))
        chosen.append(i_max)
        s = np.zeros(L)
        s[i_max] = 1.0
        gamma = 2.0 / (k + 2)
        a = (1.0 - gamma) * a + gamma * s
    return chosen


def frank_wolfe_support(n_sensors, eo=EO, angles=None, n_iter=None):
    """Variante : on itère longtemps puis on garde les `n_sensors` plus gros poids."""
    if angles is None:
        angles = candidate_angles()
    if n_iter is None:
        n_iter = 100 * n_sensors
    phi = steering_matrix(angles, eo)
    L = phi.shape[1]
    a = np.full(L, 1.0 / L)
    for k in range(n_iter):
        i_max = int(np.argmax(_grad(phi, a)))
        s = np.zeros(L)
        s[i_max] = 1.0
        gamma = 2.0 / (k + 2)
        a = (1.0 - gamma) * a + gamma * s
    return list(np.argsort(a)[::-1][:n_sensors])


def select(n_sensors, eo=EO, angles=None, support=False):
    """Renvoie les angles (rad, triés) sélectionnés."""
    if angles is None:
        angles = candidate_angles()
    finder = frank_wolfe_support if support else frank_wolfe
    return np.sort(angles[finder(n_sensors, eo, angles)])


def run(eo=EO, l_max=15, support=False):
    angles = candidate_angles()
    results = []
    for k in range(eo, l_max + 1):
        sel = select(k, eo, angles, support=support)
        results.append({"pos": sel, "mse": mse(sel, eo), "cond": condition_number(sel, eo)})
    return results


if __name__ == "__main__":
    for d in run():
        print("K =", len(d["pos"]), "| MSE =", round(d["mse"], 4),
              "| cond =", round(d["cond"], 4))
