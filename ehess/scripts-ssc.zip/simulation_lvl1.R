# =============================================================================
# SIMULATION NIVEAU 1 — Boucle principale + métriques
# =============================================================================
# JEU COLLECTIF À N JOUEURS (Type 3 Bonacich) :
#   K = nombre TOTAL de coopérants dans la communauté
#   π(C, K) = K * r - c
#   π(D, K) = K * r
# Le réseau social module UNIQUEMENT les empathies et les croyances,
# pas les payoffs.
# =============================================================================

source("init_communaute.R")

library(igraph)
library(Matrix)
library(dplyr)

# =============================================================================
# CONSTANTES DE SIMULATION
# (les paramètres comportementaux sont dans init_communaute.R)
# =============================================================================

T_MAX <- 150L   # nombre de tours

# =============================================================================
# FONCTIONS UTILITAIRES
# =============================================================================

# Payoffs collectifs — définis globalement, écrasés localement si params fournis
payoff_C <- function(K, r=R_JEU, c) K * r - c
payoff_D <- function(K, r=R_JEU)    K * r

p_chapeau <- function(B_ij_j) sum(B_ij_j * THETA)

maj_B_ij <- function(B_vec, s_j, ecog_i) {
  lv        <- if (s_j == "C") THETA^ecog_i else (1 - THETA)^ecog_i
  posterior <- lv * B_vec
  s         <- sum(posterior)
  if (s < 1e-12) return(B_vec)
  posterior / s
}

fermi <- function(lambda_i, delta_A, tc, ta) {
  1 / (1 + exp(-lambda_i * delta_A - tc - ta))
}

maj_bassins <- function(ag, pi_C_real, pi_D_real) {
  h         <- ag$h
  delta_EWA <- ag$ecog
  
  if (ag$strategie_prev == "C") {
    pi_C_delta <- pi_C_real                  # stratégie jouée
    pi_D_delta <- delta_EWA * pi_D_real      # contrefactuel
  } else {
    pi_C_delta <- delta_EWA * pi_C_real      # contrefactuel
    pi_D_delta <- pi_D_real                  # stratégie jouée
  }
  
  ag$hist_pi_C <- c(ag$hist_pi_C, pi_C_delta)
  ag$hist_pi_D <- c(ag$hist_pi_D, pi_D_delta)
  
  idx_court <- max(1, length(ag$hist_pi_C) - DELTA + 1):length(ag$hist_pi_C)
  
  A_C_long <- 0
  A_D_long <- 0
  normalisation <- 0
  for(k in 1:(max(1, length(ag$hist_pi_C) - DELTA))){
    A_C_long <- A_C_long + h**(max(1, length(ag$hist_pi_C) - DELTA)-k)*ag$hist_pi_C[k]
    A_D_long <- A_D_long + h**(max(1, length(ag$hist_pi_D) - DELTA)-k)*ag$hist_pi_D[k]
    normalisation <- normalisation + h**(max(1, length(ag$hist_pi_D) - DELTA)-k)
  }
  A_C_long <- A_C_long / normalisation
  A_D_long <- A_D_long / normalisation
  
  
  A_C_court <- mean(ag$hist_pi_C[idx_court])
  A_D_court <- mean(ag$hist_pi_D[idx_court])
  
  ag$A_C     <- A_C_long + A_C_court
  ag$A_D     <- A_D_long + A_D_court
  ag$n_tours <- ag$n_tours + 1L
  ag
}


maj_eaff <- function(ag, bar_s_communaute) {
  # Signal ∈ [-1,1] : 2*taux_coop_communauté - 1
  signal  <- 2 * bar_s_communaute - 1
  alpha_i <- ag$h * ALPHA_MAX
  ag$eaff <- max(-1, min(1, ag$eaff + alpha_i * (signal - ag$eaff)))
  ag
}

maj_ecog <- function(ag, p_hat_v, strats_voisins) {
  if (length(p_hat_v) == 0) return(ag)
  erreur  <- mean(abs(p_hat_v - as.numeric(strats_voisins == "C")))
  alpha_i <- ag$h * ALPHA_MAX
  ag$ecog <- max(0, min(1, ag$ecog + alpha_i * (1 - erreur - ag$ecog)))
  ag
}

# =============================================================================
# BOUCLE PRINCIPALE
# =============================================================================

#A compléter la liste des paramètres si l'on souhaite par 
#params = list (blabla , blabla = etc.)

simuler_communaute <- function(comm, params = list()) {
  
  agents <- comm$agents
  g      <- comm$g
  n      <- comm$n
  
  # Paramètres du jeu
  r_jeu    <- if (!is.null(params$r_jeu))    params$r_jeu    else R_JEU
  GAMMA <- if (!is.null(params$GAMMA)) params$GAMMA else GAMMA
  
  # Vérification : GAMMA ∈ (0, 1) exclu
  if (GAMMA <= 0 || GAMMA >= 1)
    warning(sprintf("GAMMA=%.3f hors (0,1) — dilemme non garanti", GAMMA))
  
  # C_JEU : même formule que dans init_communaute()
  # GAMMA=0 → c/r = n-1 (très difficile) | GAMMA=1 → c/r = 1 (très facile)
  c_jeu <- ((n - 1) * (1 - GAMMA) + GAMMA) * r_jeu
  
  # Paramètres comportementaux — tous identifiables
  lbar      <- if (!is.null(params$lbar))      params$lbar      else LAMBDA_BAR
  mubar     <- if (!is.null(params$mubar))     params$mubar     else MU_BAR
  nubar     <- if (!is.null(params$nubar))     params$nubar     else NU_BAR
  eta_w     <- if (!is.null(params$eta_w))     params$eta_w     else ETA_W
  eta_w_d   <- if (!is.null(params$eta_w_d))   params$eta_w_d   else ETA_W_D
  alpha_max <- if (!is.null(params$alpha_max)) params$alpha_max else ALPHA_MAX
  delta <- if (!is.null(params$delta)) params$delta else DELTA
  
  metriques <- data.frame(
    tour               = integer(T_MAX),
    taux_coop          = numeric(T_MAX),
    payoff_moy         = numeric(T_MAX),
    eaff_moy           = numeric(T_MAX),
    eaff_sd            = numeric(T_MAX),
    ecog_moy           = numeric(T_MAX),
    ecog_sd            = numeric(T_MAX),
    h_moy              = numeric(T_MAX),
    w_total            = numeric(T_MAX),
    tc_moy             = numeric(T_MAX),
    tc_sd              = numeric(T_MAX),
    ta_moy             = numeric(T_MAX),
    ta_sd              = numeric(T_MAX),
    tewa_moy           = numeric(T_MAX),
    tewa_sd            = numeric(T_MAX),
    deg_moy            = numeric(T_MAX),
    deg_sd             = numeric(T_MAX),
    w_central_moy      = numeric(T_MAX),
    w_marginal_moy     = numeric(T_MAX),
    taux_coop_central  = numeric(T_MAX),
    taux_coop_marginal = numeric(T_MAX)
  )
  
  tc_vec   <- numeric(n)
  ta_vec   <- numeric(n)
  tewa_vec <- numeric(n)
  
  rangs       <- sapply(agents, `[[`, "rang")
  
  # les agents centraux et les agents marginaux 
  
  q1 <- quantile(rangs, 0.20)
  q4 <- quantile(rangs, 0.80)
  est_central <- rangs <= q1    # premier quintile : les plus centraux
  est_marginal <- rangs >= q4   # dernier quintile : les plus marginaux
  
  pb <- txtProgressBar(min=0, max=T_MAX, style=3, width=50)
  
  for (tour in 1:T_MAX) {
    setTxtProgressBar(pb, tour)
    
    W_total  <- sum(E(g)$weight)
    w_moy    <- W_total / max(ecount(g), 1)
    
    # ── 1. Décisions ──
    for (id in 1:n) {
      ag <- agents[[id]]
      v  <- ag$voisins
      
      if (length(v) == 0) {
        agents[[id]]$strategie <- if (runif(1) < 0.5) "C" else "D"
        tc_vec[id] <- 0; ta_vec[id] <- 0; tewa_vec[id] <- 0
        next
      }
      
      p_hat_v  <- sapply(seq_along(v), function(k) p_chapeau(ag$B_ij[k,]))
      lambda_i <- lbar * ag$h
      delta_A  <- ag$A_C - ag$A_D
      
      # Terme cognitif : anticipation du taux de coop moyen des voisins
      # (proxy local du taux collectif)
      # ON RAISONNE EN GAIN MARGINAL DONC IL FAUT RAMENER à N !!!
      tc <- mubar * ag$ecog * abs (mean(p_hat_v) * r_jeu  - (c_jeu / n) )
      
      # # Terme affectif : liens relatifs à la moyenne du réseau
      # ta <- nubar * ag$eaff * mean(ag$poids) / max(w_moy, 1e-12)
      # 
      # Terme affectif : proportion pondérée de coopérants voisins
      # imitation passionnelle spinoziste — liens forts vers coopérants comptent plus
      if (length(v) > 0) {
        strats_prev  <- sapply(v, function(j) agents[[j]]$strategie_prev)
        coop_prev    <- as.numeric(strats_prev == "C")
        poids_v      <- ag$poids
        sum_poids    <- sum(poids_v)
        ta <- if (sum_poids > 1e-12)
          nubar * ag$eaff * sum(poids_v * coop_prev) / sum_poids
        else 0
      } else {
        ta <- 0
      }
      
      
      p_coop <- fermi(lambda_i, delta_A, tc, ta)
      
      tc_vec[id]   <- tc
      ta_vec[id]   <- ta
      tewa_vec[id] <- lambda_i * delta_A
      
      agents[[id]]$strategie_prev <- ag$strategie
      agents[[id]]$strategie      <- if (runif(1) < p_coop) "C" else "D"
    }
    
    # ── 2. Payoffs collectifs (K = total coopérants) ──
    strats  <- sapply(agents, `[[`, "strategie")
    K_total <- sum(strats == "C")   # nombre TOTAL de coopérants
    
    pi_C_real <- payoff_C(K_total, r=r_jeu, c=c_jeu)
    pi_D_real <- payoff_D(K_total, r=r_jeu)
    # Tous les coopérants reçoivent pi_C_real, tous les défecteurs pi_D_real
    
    for (id in 1:n) {
      ag      <- agents[[id]]
      pi_reel <- if (strats[id] == "C") pi_C_real else pi_D_real
      agents[[id]]$payoff_cumul <- ag$payoff_cumul + pi_reel
      
      # ── 3. Bassins SAW+EWA ──
      agents[[id]] <- maj_bassins(agents[[id]], pi_C_real, pi_D_real)
      
      # ── 4. Croyances bayésiennes (sur les voisins) ──
      v <- ag$voisins
      if (length(v) > 0) {
        for (k in seq_along(v))
          agents[[id]]$B_ij[k,] <- maj_B_ij(ag$B_ij[k,], strats[v[k]], ag$ecog)
      }
      
      # ── 5. Empathies ──
      # e_aff : signal = taux de coop COLLECTIF (cohérent avec le jeu)
      agents[[id]] <- maj_eaff(agents[[id]], K_total / n)
      
      # e_cog : qualité de prédiction sur les voisins (observable)
      if (length(v) > 0) {
        p_hat_prev   <- sapply(seq_along(v), function(k) p_chapeau(ag$B_ij[k,]))
        agents[[id]] <- maj_ecog(agents[[id]], p_hat_prev, strats[v])
      }
    }
    
    # ── 6. Poids du graphe ──
    el       <- as_edgelist(g, names = FALSE)
    si_e     <- strats[el[,1]]; sj_e <- strats[el[,2]]
    w <- E(g)$weight
    w[si_e=="C" & sj_e=="C"] <- pmin(w[si_e=="C" & sj_e=="C"] + eta_w,  W_MAX)
    w[si_e=="D" | sj_e=="D"] <- pmax(w[si_e=="D" | sj_e=="D"] - eta_w_d, W_MIN)
    E(g)$weight <- w
    
    poids_mat <- sparseMatrix(i=el[,1], j=el[,2], x=w, dims=c(n,n), symmetric=TRUE)
    for (id in 1:n) {
      v <- agents[[id]]$voisins
      if (length(v) == 0) next
      agents[[id]]$poids <- as.numeric(poids_mat[id, v])
      names(agents[[id]]$poids) <- as.character(v)
    }
    
    # ── 7. Métriques ──
    eaffs <- sapply(agents, `[[`, "eaff")
    ecogs <- sapply(agents, `[[`, "ecog")
    degs  <- sapply(agents, function(a) length(a$voisins))
    w_c   <- sapply(which(est_central), function(id) mean(agents[[id]]$poids))
    w_m   <- sapply(which(est_marginal), function(id) mean(agents[[id]]$poids))
    
    metriques[tour, "tour"]               <- tour
    metriques[tour, "taux_coop"]          <- K_total / n
    metriques[tour, "payoff_moy"]         <- mean(sapply(agents, `[[`, "payoff_cumul")) / tour
    metriques[tour, "eaff_moy"]           <- mean(eaffs)
    metriques[tour, "eaff_sd"]            <- sd(eaffs)
    metriques[tour, "ecog_moy"]           <- mean(ecogs)
    metriques[tour, "ecog_sd"]            <- sd(ecogs)
    metriques[tour, "h_moy"]              <- mean(sapply(agents, `[[`, "h"))
    metriques[tour, "w_total"]            <- sum(E(g)$weight)
    metriques[tour, "tc_moy"]             <- mean(tc_vec)
    metriques[tour, "tc_sd"]              <- sd(tc_vec)
    metriques[tour, "ta_moy"]             <- mean(ta_vec)
    metriques[tour, "ta_sd"]              <- sd(ta_vec)
    metriques[tour, "tewa_moy"]           <- mean(tewa_vec)
    metriques[tour, "tewa_sd"]            <- sd(tewa_vec)
    metriques[tour, "deg_moy"]            <- mean(degs)
    metriques[tour, "deg_sd"]             <- sd(degs)
    metriques[tour, "w_central_moy"]      <- if (length(w_c)>0) mean(w_c, na.rm=TRUE) else NA
    metriques[tour, "w_marginal_moy"]     <- if (length(w_m)>0) mean(w_m, na.rm=TRUE) else NA
    metriques[tour, "taux_coop_central"]  <- if (any( est_central)) mean(strats[ est_central]=="C") else NA
    metriques[tour, "taux_coop_marginal"] <- if (any(est_marginal)) mean(strats[est_marginal]=="C") else NA
  }
  
  close(pb)
  cat(sprintf("\n  Résumé : K_coop_fin=%d/%d (%.0f%%) | eaff=%.3f | ecog=%.3f\n",
              as.integer(metriques$taux_coop[T_MAX]*n), n,
              100*metriques$taux_coop[T_MAX],
              metriques$eaff_moy[T_MAX], metriques$ecog_moy[T_MAX]))
  
  list(agents=agents, g=g, metriques=metriques, n=n)
}

# # =============================================================================
# # LANCEMENT
# # =============================================================================
# 
# cat("\n====== SIMULATION WATTS-STROGATZ ======\n")
# resultats_WS <- lapply(names(communautes_WS), function(nm) {
#   cat(sprintf("\n--- Communauté %s ---\n", nm))
#   simuler_communaute(communautes_WS[[nm]])
# })
# names(resultats_WS) <- names(communautes_WS)
# 
# cat("\n====== SIMULATION BARABÁSI-ALBERT ======\n")
# resultats_BA <- lapply(names(communautes_BA), function(nm) {
#   cat(sprintf("\n--- Communauté %s ---\n", nm))
#   simuler_communaute(communautes_BA[[nm]])
# })
# names(resultats_BA) <- names(communautes_BA)
# 
# cat("\n=== Simulation terminée. ===\n")

# # =============================================================================
# # FIGURES
# # =============================================================================
# 
# library(ggplot2); library(dplyr); library(scales)
# 
# PAL <- c(n5="#0072B2", n50="#009E73", n500="#E69F00", n5000="#D55E00")
# 
# theme_sim <- function()
#   theme_minimal(base_size=12) +
#   theme(panel.grid.minor=element_blank(), legend.position="right",
#         plot.title=element_text(face="bold",size=13),
#         plot.subtitle=element_text(size=10,color="grey40"))
# 
# #fonction de moyenne glissante
# ma <- function(x, w = 15) {
#   n <- length(x)
#   result <- numeric(n)
#   for (i in 1:n) {
#     debut <- max(1, i - w + 1)
#     result[i] <- mean(x[debut:i])
#   }
#   result
# }
# 
# assembler <- function(res_list) {
#   do.call(rbind, lapply(names(res_list), function(nm) {
#     m <- res_list[[nm]]$metriques
#     m$communaute <- factor(nm, levels=names(PAL)); m
#   }))
# }
# 
# #FIGURE WATTS STROGATZ - PETIT MONDE
# 
# res <- resultats_WS$n500
# res_df <- resultats_WS; df <- assembler(res_df); titre_methode <- "Watts-Strogatz"
# 
# # Figure 1 — Taux de coopération
# ggplot(df, aes(x=tour, y=taux_coop, color=communaute)) +
#   geom_line(linewidth=0.8, alpha=0.85) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_y_continuous(labels=percent, limits=c(0,1)) +
#   labs(title="Taux de coopération (K_total/n)",
#        subtitle=paste0(titre_methode," · ",T_MAX," tours · jeu collectif"),
#        x="Tour", y="P(C)") + theme_sim()
# 
# # Figure 2 — Empathies
# ggplot(df %>% mutate(elo=pmax(-1,eaff_moy-eaff_sd), ehi=pmin(1,eaff_moy+eaff_sd)),
#        aes(x=tour, color=communaute, fill=communaute)) +
#   geom_ribbon(aes(ymin=elo,ymax=ehi), alpha=0.12, color=NA) +
#   geom_line(aes(y=eaff_moy), linewidth=1.0) +
#   geom_line(aes(y=ecog_moy), linewidth=0.8, linetype="dashed") +
#   geom_hline(yintercept=0, linetype="dotted", color="grey50", linewidth=0.3) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_fill_manual(values=PAL, name="Taille n") +
#   scale_y_continuous(limits=c(-1,1)) +
#   labs(title="Empathies affective [−1,1] (plein) et cognitive [0,1] (tirets)",
#        subtitle="Signal e_aff = 2·K/n − 1 · Ruban = ±1σ",
#        x="Tour", y="Valeur") + theme_sim()
# 
# # Figure 3 — Termes cognitif et affectif
# nms_dispo <- intersect(c("n50","n500"), as.character(unique(df$communaute)))
# PAL3 <- c("Cognitif.n50"="#009E73","Cognitif.n500"="#66BB6A",
#           "Affectif.n50"="#D55E00","Affectif.n500"="#E69F00")
# df3 <- bind_rows(
#   df %>% filter(as.character(communaute) %in% nms_dispo) %>%
#     transmute(tour, communaute, val=tc_moy, val_lo=tc_moy-tc_sd, val_hi=tc_moy+tc_sd, terme="Cognitif"),
#   df %>% filter(as.character(communaute) %in% nms_dispo) %>%
#     transmute(tour, communaute, val=ta_moy, val_lo=ta_moy-ta_sd, val_hi=ta_moy+ta_sd, terme="Affectif")
# )
# df3$grp <- factor(paste0(df3$terme,".",df3$communaute), levels=names(PAL3))
# df3$terme <- factor(df3$terme, levels=c("Cognitif","Affectif"))
# 
# ggplot(df3, aes(x=tour,y=val,color=grp,fill=grp,linetype=terme)) +
#   geom_ribbon(aes(ymin=val_lo,ymax=val_hi), alpha=0.12, color=NA) +
#   geom_line(linewidth=0.9) +
#   geom_hline(yintercept=0, linetype="dotted", color="grey50", linewidth=0.35) +
#   scale_color_manual(values=PAL3, labels=names(PAL3), name="Terme · Taille") +
#   scale_fill_manual(values=PAL3, labels=names(PAL3), name="Terme · Taille") +
#   scale_linetype_manual(values=c("Cognitif"="solid","Affectif"="dashed"), name="Terme") +
#   labs(title="Termes cognitif (plein) et affectif (tirets)",
#        subtitle="Ruban = ±1σ inter-agents",
#        x="Tour", y="Valeur du terme") + theme_sim()
# 
# # Figure 4 — Centraux vs marginaux MA30
# df4 <- bind_rows(
#   df %>% filter(!is.na(taux_coop_central))  %>% transmute(tour,communaute,taux=taux_coop_central, groupe="Central"),
#   df %>% filter(!is.na(taux_coop_marginal)) %>% transmute(tour,communaute,taux=taux_coop_marginal,groupe="Marginal")
# ) %>% group_by(communaute,groupe) %>% mutate(taux_ma=ma(taux,30)) %>% ungroup()
# 
# ggplot(df4, aes(x=tour,color=communaute,linetype=groupe)) +
#   geom_line(aes(y=taux), linewidth=0.25, alpha=0.20) +
#   geom_line(aes(y=taux_ma), linewidth=1.0, alpha=0.90, na.rm=TRUE) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_linetype_manual(values=c("Central"="solid","Marginal"="dashed"), name="Position") +
#   scale_y_continuous(labels=percent, limits=c(0,1)) +
#   labs(title="Coopération : centraux vs marginaux",
#        subtitle="Trait fin = brut · trait épais = MA30",
#        x="Tour", y="P(C)") + theme_sim()
# 
# # Figure 5 — Degré moyen
# df %>% filter(!is.na(deg_moy)) %>%
#   mutate(dlo=pmax(0,deg_moy-deg_sd), dhi=deg_moy+deg_sd) %>%
#   ggplot(aes(x=tour,y=deg_moy,color=communaute,fill=communaute)) +
#   geom_ribbon(aes(ymin=dlo,ymax=dhi), alpha=0.12, color=NA) +
#   geom_line(linewidth=0.9) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_fill_manual(values=PAL, name="Taille n") +
#   labs(title="Degré moyen du réseau", subtitle="Ruban = ±1σ",
#        x="Tour", y="Degré moyen") + theme_sim()
# 
# # Figure 6 — Force liens centraux vs marginaux
# bind_rows(
#   df %>% filter(!is.na(w_central_moy))  %>% transmute(tour,communaute,w=w_central_moy, groupe="Central"),
#   df %>% filter(!is.na(w_marginal_moy)) %>% transmute(tour,communaute,w=w_marginal_moy,groupe="Marginal")
# ) %>%
#   ggplot(aes(x=tour,y=w,color=communaute,linetype=groupe)) +
#   geom_line(linewidth=0.9, alpha=0.85) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_linetype_manual(values=c("Central"="solid","Marginal"="dashed"), name="Position") +
#   labs(title="Force moyenne des liens — centraux vs marginaux",
#        x="Tour", y="Poids moyen w_ij") + theme_sim()
# 
# # Figure 7 — Distribution des degrés WS vs BA
# df_deg <- do.call(rbind, list(
#   data.frame(degre=degree(communautes_WS$n50$g),  methode="Watts-Strogatz",  n="n = 50"),
#   data.frame(degre=degree(communautes_WS$n500$g), methode="Watts-Strogatz",  n="n = 500"),
#   data.frame(degre=degree(communautes_BA$n50$g),  methode="Barabási-Albert", n="n = 50"),
#   data.frame(degre=degree(communautes_BA$n500$g), methode="Barabási-Albert", n="n = 500")
# ))
# ggplot(df_deg, aes(x=degre, fill=methode)) +
#   geom_histogram(binwidth=1, color="white", linewidth=0.2, alpha=0.85) +
#   facet_grid(n ~ methode, scales="free") +
#   scale_fill_manual(values=c("Watts-Strogatz"="#0072B2","Barabási-Albert"="#D55E00"), guide="none") +
#   labs(title="Distribution des degrés — WS vs BA", subtitle="n=50 et n=500",
#        x="Degré k", y="Nombre d'agents") +
#   theme_minimal(base_size=12) +
#   theme(panel.grid.minor=element_blank(), strip.text=element_text(face="bold"))
# 
# # =============================================================
# # Diagnostic : distribution de e_cog par agent au fil du temps
# # =============================================================
# 
# library(ggplot2)
# library(dplyr)
# 
# # 1. Distribution initiale vs finale de e_cog
# ecog_init <- sapply(res$agents, `[[`, "ecog")  # état final (500 tours)
# # État initial : non stocké directement, mais on a les métriques
# # → on regarde l'évolution de ecog_sd au fil du temps
# 
# df_sd <- data.frame(
#   tour     = res$metriques$tour,
#   ecog_moy = res$metriques$ecog_moy,
#   ecog_sd  = res$metriques$ecog_sd,
#   eaff_moy = res$metriques$eaff_moy,
#   eaff_sd  = res$metriques$eaff_sd
# )
# 
# # 2. Évolution de la dispersion inter-agents
# ggplot(df_sd, aes(x = tour)) +
#   geom_ribbon(aes(ymin = ecog_moy - ecog_sd, ymax = ecog_moy + ecog_sd),
#               fill = "#0072B2", alpha = 0.20) +
#   geom_line(aes(y = ecog_moy), color = "#0072B2", linewidth = 1.0) +
#   geom_ribbon(aes(ymin = eaff_moy - eaff_sd, ymax = eaff_moy + eaff_sd),
#               fill = "#D55E00", alpha = 0.20) +
#   geom_line(aes(y = eaff_moy), color = "#D55E00", linewidth = 1.0,
#             linetype = "dashed") +
#   geom_hline(yintercept = 0, linetype = "dotted", color = "grey50") +
#   scale_y_continuous(limits = c(-1, 1)) +
#   annotate("text", x = 10, y = 0.95, label = "e_cog (bleu)",
#            hjust = 0, color = "#0072B2", size = 3.5) +
#   annotate("text", x = 10, y = 0.85, label = "e_aff (orange)",
#            hjust = 0, color = "#D55E00", size = 3.5) +
#   labs(title    = "Évolution moyenne et dispersion des empathies",
#        subtitle = "Ruban = ±1σ inter-agents · si ruban étroit = convergence homogène",
#        x = "Tour", y = "Valeur") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# # 3. Distribution finale de e_cog et e_aff par rang de centralité
# df_agents <- data.frame(
#   rang  = sapply(res$agents, `[[`, "rang"),
#   ecog  = sapply(res$agents, `[[`, "ecog"),
#   eaff  = sapply(res$agents, `[[`, "eaff"),
#   h     = sapply(res$agents, `[[`, "h")
# )
# 
# #COG
# ggplot(df_agents, aes(x = rang, y = ecog)) +
#   geom_point(alpha = 0.3, size = 0.8, color = "#0072B2") +
#   geom_smooth(method = "loess", se = TRUE, color = "#0072B2",
#               fill = "#0072B2", alpha = 0.2) +
#   labs(title    = "e_cog final selon le rang de centralité",
#        subtitle = "0 = central · 1 = marginal",
#        x = "Rang r_i", y = "e_cog final") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# #AFF
# ggplot(df_agents, aes(x = rang, y = eaff)) +
#   geom_point(alpha = 0.3, size = 0.8, color = "#0072B2") +
#   geom_smooth(method = "loess", se = TRUE, color = "#0072B2",
#               fill = "#0072B2", alpha = 0.2) +
#   labs(title    = "e_aff final selon le rang de centralité",
#        subtitle = "0 = central · 1 = marginal",
#        x = "Rang r_i", y = "e_aff final") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# # 4. Histogramme de la distribution finale
# 
# #COG
# ggplot(df_agents, aes(x = ecog)) +
#   geom_histogram(binwidth = 0.02, fill = "#0072B2", color = "white",
#                  alpha = 0.85) +
#   geom_vline(xintercept = mean(df_agents$ecog), linetype = "dashed",
#              color = "grey30") +
#   labs(title    = "Distribution finale de e_cog",
#        subtitle = sprintf("moy = %.3f · sd = %.3f · min = %.3f · max = %.3f",
#                           mean(df_agents$ecog), sd(df_agents$ecog),
#                           min(df_agents$ecog), max(df_agents$ecog)),
#        x = "e_cog", y = "Nombre d'agents") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# #AFF
# ggplot(df_agents, aes(x = eaff)) +
#   geom_histogram(binwidth = 0.02, fill = "#0072B2", color = "white",
#                  alpha = 0.85) +
#   geom_vline(xintercept = mean(df_agents$eaff), linetype = "dashed",
#              color = "grey30") +
#   labs(title    = "Distribution finale de e_aff",
#        subtitle = sprintf("moy = %.3f · sd = %.3f · min = %.3f · max = %.3f",
#                           mean(df_agents$eaff), sd(df_agents$eaff),
#                           min(df_agents$eaff), max(df_agents$eaff)),
#        x = "e_aff", y = "Nombre d'agents") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# 
# # 5 . Diagnostic de corrélation
# 
# cat(sprintf("\nDispersion e_cog finale : sd=%.4f | min=%.3f | max=%.3f\n",
#             sd(df_agents$ecog), min(df_agents$ecog), max(df_agents$ecog)))
# cat(sprintf("Corrélation(rang, e_cog) : %.3f\n", cor(df_agents$rang, df_agents$ecog)))
# cat(sprintf("Corrélation(h, e_cog)    : %.3f\n", cor(df_agents$h,    df_agents$ecog)))
# 
# cat(sprintf("\nDispersion e_aff finale : sd=%.4f | min=%.3f | max=%.3f\n",
#             sd(df_agents$eaff), min(df_agents$eaff), max(df_agents$eaff)))
# cat(sprintf("Corrélation(rang, e_aff) : %.3f\n", cor(df_agents$rang, df_agents$eaff)))
# cat(sprintf("Corrélation(h, e_aff)    : %.3f\n", cor(df_agents$h,    df_agents$eaff)))
# 
# 
# 
# #FIGURE WATTS STROGATZ - PETIT MONDE
# 
# res <- resultats_BA$n500   # ou n50
# res_df <- resultats_BA; df <- assembler(res_df); titre_methode <- "Barabási-Albert"
# 
# # Figure 1 — Taux de coopération
# ggplot(df, aes(x=tour, y=taux_coop, color=communaute)) +
#   geom_line(linewidth=0.8, alpha=0.85) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_y_continuous(labels=percent, limits=c(0,1)) +
#   labs(title="Taux de coopération (K_total/n)",
#        subtitle=paste0(titre_methode," · ",T_MAX," tours · jeu collectif"),
#        x="Tour", y="P(C)") + theme_sim()
# 
# # Figure 2 — Empathies
# ggplot(df %>% mutate(elo=pmax(-1,eaff_moy-eaff_sd), ehi=pmin(1,eaff_moy+eaff_sd)),
#        aes(x=tour, color=communaute, fill=communaute)) +
#   geom_ribbon(aes(ymin=elo,ymax=ehi), alpha=0.12, color=NA) +
#   geom_line(aes(y=eaff_moy), linewidth=1.0) +
#   geom_line(aes(y=ecog_moy), linewidth=0.8, linetype="dashed") +
#   geom_hline(yintercept=0, linetype="dotted", color="grey50", linewidth=0.3) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_fill_manual(values=PAL, name="Taille n") +
#   scale_y_continuous(limits=c(-1,1)) +
#   labs(title="Empathies affective [−1,1] (plein) et cognitive [0,1] (tirets)",
#        subtitle="Signal e_aff = 2·K/n − 1 · Ruban = ±1σ",
#        x="Tour", y="Valeur") + theme_sim()
# 
# # Figure 3 — Termes cognitif et affectif
# nms_dispo <- intersect(c("n50","n500"), as.character(unique(df$communaute)))
# PAL3 <- c("Cognitif.n50"="#009E73","Cognitif.n500"="#66BB6A",
#           "Affectif.n50"="#D55E00","Affectif.n500"="#E69F00")
# df3 <- bind_rows(
#   df %>% filter(as.character(communaute) %in% nms_dispo) %>%
#     transmute(tour, communaute, val=tc_moy, val_lo=tc_moy-tc_sd, val_hi=tc_moy+tc_sd, terme="Cognitif"),
#   df %>% filter(as.character(communaute) %in% nms_dispo) %>%
#     transmute(tour, communaute, val=ta_moy, val_lo=ta_moy-ta_sd, val_hi=ta_moy+ta_sd, terme="Affectif")
# )
# df3$grp <- factor(paste0(df3$terme,".",df3$communaute), levels=names(PAL3))
# df3$terme <- factor(df3$terme, levels=c("Cognitif","Affectif"))
# 
# ggplot(df3, aes(x=tour,y=val,color=grp,fill=grp,linetype=terme)) +
#   geom_ribbon(aes(ymin=val_lo,ymax=val_hi), alpha=0.12, color=NA) +
#   geom_line(linewidth=0.9) +
#   geom_hline(yintercept=0, linetype="dotted", color="grey50", linewidth=0.35) +
#   scale_color_manual(values=PAL3, labels=names(PAL3), name="Terme · Taille") +
#   scale_fill_manual(values=PAL3, labels=names(PAL3), name="Terme · Taille") +
#   scale_linetype_manual(values=c("Cognitif"="solid","Affectif"="dashed"), name="Terme") +
#   labs(title="Termes cognitif (plein) et affectif (tirets)",
#        subtitle="Ruban = ±1σ inter-agents",
#        x="Tour", y="Valeur du terme") + theme_sim()
# 
# # Figure 4 — Centraux vs marginaux MA30
# df4 <- bind_rows(
#   df %>% filter(!is.na(taux_coop_central))  %>% transmute(tour,communaute,taux=taux_coop_central, groupe="Central"),
#   df %>% filter(!is.na(taux_coop_marginal)) %>% transmute(tour,communaute,taux=taux_coop_marginal,groupe="Marginal")
# ) %>% group_by(communaute,groupe) %>% mutate(taux_ma=ma(taux,30)) %>% ungroup()
# 
# ggplot(df4, aes(x=tour,color=communaute,linetype=groupe)) +
#   geom_line(aes(y=taux), linewidth=0.25, alpha=0.20) +
#   geom_line(aes(y=taux_ma), linewidth=1.0, alpha=0.90, na.rm=TRUE) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_linetype_manual(values=c("Central"="solid","Marginal"="dashed"), name="Position") +
#   scale_y_continuous(labels=percent, limits=c(0,1)) +
#   labs(title="Coopération : centraux vs marginaux",
#        subtitle="Trait fin = brut · trait épais = MA30",
#        x="Tour", y="P(C)") + theme_sim()
# 
# # Figure 5 — Degré moyen
# df %>% filter(!is.na(deg_moy)) %>%
#   mutate(dlo=pmax(0,deg_moy-deg_sd), dhi=deg_moy+deg_sd) %>%
#   ggplot(aes(x=tour,y=deg_moy,color=communaute,fill=communaute)) +
#   geom_ribbon(aes(ymin=dlo,ymax=dhi), alpha=0.12, color=NA) +
#   geom_line(linewidth=0.9) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_fill_manual(values=PAL, name="Taille n") +
#   labs(title="Degré moyen du réseau", subtitle="Ruban = ±1σ",
#        x="Tour", y="Degré moyen") + theme_sim()
# 
# # Figure 6 — Force liens centraux vs marginaux
# bind_rows(
#   df %>% filter(!is.na(w_central_moy))  %>% transmute(tour,communaute,w=w_central_moy, groupe="Central"),
#   df %>% filter(!is.na(w_marginal_moy)) %>% transmute(tour,communaute,w=w_marginal_moy,groupe="Marginal")
# ) %>%
#   ggplot(aes(x=tour,y=w,color=communaute,linetype=groupe)) +
#   geom_line(linewidth=0.9, alpha=0.85) +
#   scale_color_manual(values=PAL, name="Taille n") +
#   scale_linetype_manual(values=c("Central"="solid","Marginal"="dashed"), name="Position") +
#   labs(title="Force moyenne des liens — centraux vs marginaux",
#        x="Tour", y="Poids moyen w_ij") + theme_sim()
# 
# # Figure 7 — Distribution des degrés WS vs BA
# df_deg <- do.call(rbind, list(
#   data.frame(degre=degree(communautes_WS$n50$g),  methode="Watts-Strogatz",  n="n = 50"),
#   data.frame(degre=degree(communautes_WS$n500$g), methode="Watts-Strogatz",  n="n = 500"),
#   data.frame(degre=degree(communautes_BA$n50$g),  methode="Barabási-Albert", n="n = 50"),
#   data.frame(degre=degree(communautes_BA$n500$g), methode="Barabási-Albert", n="n = 500")
# ))
# ggplot(df_deg, aes(x=degre, fill=methode)) +
#   geom_histogram(binwidth=1, color="white", linewidth=0.2, alpha=0.85) +
#   facet_grid(n ~ methode, scales="free") +
#   scale_fill_manual(values=c("Watts-Strogatz"="#0072B2","Barabási-Albert"="#D55E00"), guide="none") +
#   labs(title="Distribution des degrés — WS vs BA", subtitle="n=50 et n=500",
#        x="Degré k", y="Nombre d'agents") +
#   theme_minimal(base_size=12) +
#   theme(panel.grid.minor=element_blank(), strip.text=element_text(face="bold"))
# 
# # =============================================================
# # Diagnostic : distribution de e_cog par agent au fil du temps
# # =============================================================
# 
# library(ggplot2)
# library(dplyr)
# 
# # 1. Distribution initiale vs finale de e_cog
# ecog_init <- sapply(res$agents, `[[`, "ecog")  # état final (500 tours)
# # État initial : non stocké directement, mais on a les métriques
# # → on regarde l'évolution de ecog_sd au fil du temps
# 
# df_sd <- data.frame(
#   tour     = res$metriques$tour,
#   ecog_moy = res$metriques$ecog_moy,
#   ecog_sd  = res$metriques$ecog_sd,
#   eaff_moy = res$metriques$eaff_moy,
#   eaff_sd  = res$metriques$eaff_sd
# )
# 
# # 2. Évolution de la dispersion inter-agents
# ggplot(df_sd, aes(x = tour)) +
#   geom_ribbon(aes(ymin = ecog_moy - ecog_sd, ymax = ecog_moy + ecog_sd),
#               fill = "#0072B2", alpha = 0.20) +
#   geom_line(aes(y = ecog_moy), color = "#0072B2", linewidth = 1.0) +
#   geom_ribbon(aes(ymin = eaff_moy - eaff_sd, ymax = eaff_moy + eaff_sd),
#               fill = "#D55E00", alpha = 0.20) +
#   geom_line(aes(y = eaff_moy), color = "#D55E00", linewidth = 1.0,
#             linetype = "dashed") +
#   geom_hline(yintercept = 0, linetype = "dotted", color = "grey50") +
#   scale_y_continuous(limits = c(-1, 1)) +
#   annotate("text", x = 10, y = 0.95, label = "e_cog (bleu)",
#            hjust = 0, color = "#0072B2", size = 3.5) +
#   annotate("text", x = 10, y = 0.85, label = "e_aff (orange)",
#            hjust = 0, color = "#D55E00", size = 3.5) +
#   labs(title    = "Évolution moyenne et dispersion des empathies",
#        subtitle = "Ruban = ±1σ inter-agents · si ruban étroit = convergence homogène",
#        x = "Tour", y = "Valeur") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# # 3. Distribution finale de e_cog et e_aff par rang de centralité
# df_agents <- data.frame(
#   rang  = sapply(res$agents, `[[`, "rang"),
#   ecog  = sapply(res$agents, `[[`, "ecog"),
#   eaff  = sapply(res$agents, `[[`, "eaff"),
#   h     = sapply(res$agents, `[[`, "h")
# )
# 
# #COG
# ggplot(df_agents, aes(x = rang, y = ecog)) +
#   geom_point(alpha = 0.3, size = 0.8, color = "#0072B2") +
#   geom_smooth(method = "loess", se = TRUE, color = "#0072B2",
#               fill = "#0072B2", alpha = 0.2) +
#   labs(title    = "e_cog final selon le rang de centralité",
#        subtitle = "0 = central · 1 = marginal",
#        x = "Rang r_i", y = "e_cog final") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# #AFF
# ggplot(df_agents, aes(x = rang, y = eaff)) +
#   geom_point(alpha = 0.3, size = 0.8, color = "#0072B2") +
#   geom_smooth(method = "loess", se = TRUE, color = "#0072B2",
#               fill = "#0072B2", alpha = 0.2) +
#   labs(title    = "e_aff final selon le rang de centralité",
#        subtitle = "0 = central · 1 = marginal",
#        x = "Rang r_i", y = "e_aff final") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# # 4. Histogramme de la distribution finale
# 
# #COG
# ggplot(df_agents, aes(x = ecog)) +
#   geom_histogram(binwidth = 0.02, fill = "#0072B2", color = "white",
#                  alpha = 0.85) +
#   geom_vline(xintercept = mean(df_agents$ecog), linetype = "dashed",
#              color = "grey30") +
#   labs(title    = "Distribution finale de e_cog",
#        subtitle = sprintf("moy = %.3f · sd = %.3f · min = %.3f · max = %.3f",
#                           mean(df_agents$ecog), sd(df_agents$ecog),
#                           min(df_agents$ecog), max(df_agents$ecog)),
#        x = "e_cog", y = "Nombre d'agents") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# #AFF
# ggplot(df_agents, aes(x = eaff)) +
#   geom_histogram(binwidth = 0.02, fill = "#0072B2", color = "white",
#                  alpha = 0.85) +
#   geom_vline(xintercept = mean(df_agents$eaff), linetype = "dashed",
#              color = "grey30") +
#   labs(title    = "Distribution finale de e_aff",
#        subtitle = sprintf("moy = %.3f · sd = %.3f · min = %.3f · max = %.3f",
#                           mean(df_agents$eaff), sd(df_agents$eaff),
#                           min(df_agents$eaff), max(df_agents$eaff)),
#        x = "e_aff", y = "Nombre d'agents") +
#   theme_minimal(base_size = 12) +
#   theme(panel.grid.minor = element_blank())
# 
# 
# # 5 . Diagnostic de corrélation
# 
# cat(sprintf("\nDispersion e_cog finale : sd=%.4f | min=%.3f | max=%.3f\n",
#             sd(df_agents$ecog), min(df_agents$ecog), max(df_agents$ecog)))
# cat(sprintf("Corrélation(rang, e_cog) : %.3f\n", cor(df_agents$rang, df_agents$ecog)))
# cat(sprintf("Corrélation(h, e_cog)    : %.3f\n", cor(df_agents$h,    df_agents$ecog)))
# 
# cat(sprintf("\nDispersion e_aff finale : sd=%.4f | min=%.3f | max=%.3f\n",
#             sd(df_agents$eaff), min(df_agents$eaff), max(df_agents$eaff)))
# cat(sprintf("Corrélation(rang, e_aff) : %.3f\n", cor(df_agents$rang, df_agents$eaff)))
# cat(sprintf("Corrélation(h, e_aff)    : %.3f\n", cor(df_agents$h,    df_agents$eaff)))