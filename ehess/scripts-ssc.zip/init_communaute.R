# =============================================================================
# INITIALISATION D'UNE COMMUNAUTÉ — Niveau 1
# =============================================================================

library(igraph)

# =============================================================================
# PARAMÈTRES GLOBAUX
# =============================================================================

# ── Types idéaux ──
THETA   <- c(0.9, 0.7, 0.35, 0.1)
N_TYPES <- 4
H_TYPES    <- c(0.20, 0.80, 0.20, 0.80)
EAFF_TYPES <- c(0.60, 0.60, - 0.60, - 0.60)
ECOG_TYPES <- c(0.30, 0.70, 0.30, 0.70)

# ── Complexion selon centralité ──
ALPHA_H    <- 3.0;  BETA_H    <- 1.5
ALPHA_ECOG <- 3.0;  BETA_ECOG <- 1.5
ALPHA_EAFF <- 1.5;  BETA_EAFF <- 3.0
EPS        <- 0.01

# ── Paramètres du jeu — valeurs par défaut ──
# Jeu collectif à N joueurs (Type 3 Bonacich) :
#   p(C, K) = K * r - c
#   p(D, K) = K * r
# K = nombre TOTAL de coopérants dans la communauté
# Condition de dilemme : 1 < c/r < n-1
# Ces valeurs sont passées en argument à init_communaute()
# GAMMA est entre 0 et 1; 0 signifiant ratio tend vers n-1...
# ...et 1 signifiant ratio tend vers 1 
# R vaut toujours 1 j
R_JEU <- 1
GAMMA <- 0.85

# ── Graphes ──
ws_k <- function(n) max(4L, as.integer(floor(log2(n))))
ws_p <- function(n) max(0.01, 0.15/log2(n))
ba_m <- function(n) max(2L, as.integer(floor(log2(n) / 2)))

# ── Poids ──
W_ALPHA <- 2.0; W_BETA <- 3.0; W_MIN <- 0.05

# ── Paramètres de simulation d
DELTA  <- 10     # fenêtre mémoire courte 
LAMBDA_BAR <- 0.02   # sensibilité aux bassins d'attraction EWA
MU_BAR     <- 3.5    # sensibilité au terme cognitif
NU_BAR     <- 3   # sensibilité au terme affectif
ETA_W      <- 0.2   # taux de renforcement des poids si coop. mutuelle
ETA_W_D    <- 0.1   # taux de dégradation des poids si trahison
W_MAX      <- 1.0    # poids maximal
ALPHA_MAX  <- 0.1   # taux d'apprentissage max des empathies (filtre expo)

# =============================================================================
# GÉNÉRATION DES GRAPHES
# =============================================================================

generer_graphe_WS <- function(n) {
  k <- ws_k(n); p <- ws_p(n)
  g <- sample_smallworld(dim = 1, size = n, nei = k %/% 2, p = p)
  n_extra <- as.integer(floor(p * ecount(g)))
  if (n_extra > 0 && n > 4) {
    paires       <- which(upper.tri(matrix(0, n, n)), arr.ind = TRUE)
    existant     <- as_edgelist(g, names = FALSE)
    existant_key <- paste(existant[,1], existant[,2])
    candidats    <- paires[!paste(paires[,1], paires[,2]) %in% existant_key, , drop = FALSE]
    if (nrow(candidats) > 0) {
      sel <- candidats[sample(nrow(candidats), min(n_extra, nrow(candidats))), , drop = FALSE]
      g   <- add_edges(g, as.vector(t(sel)))
    }
  }
  E(g)$weight <- pmax(rbeta(ecount(g), W_ALPHA, W_BETA), W_MIN)
  cat(sprintf("  [WS] n=%d : k=%d, p=%.2f | arêtes=%d | densité=%.4f | clustering=%.3f\n",
              n, k, p, ecount(g), edge_density(g), transitivity(g, "global")))
  g
}

generer_graphe_BA <- function(n) {
  m <- ba_m(n)
  g <- sample_pa(n, m = m, directed = FALSE)
  E(g)$weight <- pmax(rbeta(ecount(g), W_ALPHA, W_BETA), W_MIN)
  cat(sprintf("  [BA] n=%d : m=%d | arêtes=%d | densité=%.4f | clustering=%.3f\n",
              n, m, ecount(g), edge_density(g), transitivity(g, "global")))
  g
}

generer_graphe <- function(n, methode = "WS") {
  if (methode == "WS") return(generer_graphe_WS(n))
  if (methode == "BA") return(generer_graphe_BA(n))
  stop("methode doit être 'WS' ou 'BA'")
}

# =============================================================================
# INITIALISATION DES AGENTS
# =============================================================================

initialiser_agents <- function(g) {
  n   <- vcount(g)
  btw <- betweenness(g, normalized = TRUE)
  rang <- rank(-btw, ties.method = "average") / n
  
  agents <- vector("list", n)
  for (id in 1:n) {
    r_i <- rang[id]
    
    # h ∈ [0,1] : central → élevé
    h_i <- rbeta(1, ALPHA_H * (1-r_i) + EPS, BETA_H * r_i + EPS)
    
    # e_cog ∈ [0,1] : central → élevé
    ecog_i <- (rbeta(1, ALPHA_ECOG * (1-r_i) + EPS, BETA_ECOG * r_i + EPS))*0.25
    
    # e_aff ∈ [-1,1] : tirage Beta puis décalage selon r_i
    # central (r_i=0) : décalage -0.5 → eaff ∈ [-0.5, 0.5]
    # marginal (r_i=1) : décalage 0   → eaff ∈ [0, 1]
    eaff_brut <- rbeta(1, ALPHA_EAFF * r_i + EPS, BETA_EAFF * (1-r_i) + EPS)
    eaff_i    <- max(-1, min(1, eaff_brut - 0.5 * (1 - r_i)))
    
    # Prior égotiste : distance aux types idéaux (e_aff projeté sur [0,1])
    eaff_norm  <- (eaff_i + 1) / 2
    dist_types <- sapply(1:N_TYPES, function(k)
      sqrt((h_i - H_TYPES[k])^2 + (eaff_norm - EAFF_TYPES[k])^2 + (ecog_i - ECOG_TYPES[k])^2))
    prior_type <- 1 / (dist_types + 1e-6)
    prior_type <- prior_type / sum(prior_type)
    
    voisins <- as.integer(neighbors(g, id))
    el      <- as_edgelist(g, names = FALSE)
    poids_v <- sapply(voisins, function(j) {
      idx <- which((el[,1]==id & el[,2]==j) | (el[,1]==j & el[,2]==id))
      if (length(idx) == 0) return(W_MIN)
      E(g)$weight[idx[1]]
    })
    names(poids_v) <- as.character(voisins)
    
    B_ij <- matrix(rep(prior_type, length(voisins)),
                   nrow = length(voisins), ncol = N_TYPES, byrow = TRUE,
                   dimnames = list(as.character(voisins), paste0("type", 1:N_TYPES)))
    
    
    
    p_coop_init <- THETA[which.max(prior_type)]
    strat_init  <- ifelse(runif(1) < p_coop_init, "C", "D")
    
    agents[[id]] <- list(
      id=id, rang=r_i,
      h=h_i, ecog=ecog_i, eaff=eaff_i,
      B_ij=B_ij, voisins=voisins, poids=poids_v,
      A_C=0.0, A_D=0.0,
      hist_pi_C=numeric(0), hist_pi_D=numeric(0), n_tours=0L,
      strategie=strat_init, strategie_prev=strat_init, payoff_cumul=0.0
    )
  }
  agents
}

# =============================================================================
# FONCTION PRINCIPALE
# =============================================================================

init_communaute <- function(n, methode = "WS", seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  cat(sprintf("\n=== Initialisation communauté n=%d [%s] ===\n", n, methode))
  
  g      <- generer_graphe(n, methode = methode)
  agents <- initialiser_agents(g)
  
  # C_JEU proportionnel au ratio 
  C_JEU <- ( (n - 1)*(1-GAMMA) + GAMMA ) * R_JEU
  
  rangs  <- sapply(agents, `[[`, "rang")
  eaffs  <- sapply(agents, `[[`, "eaff")
  hs     <- sapply(agents, `[[`, "h")
  n_coop <- sum(sapply(agents, function(a) a$strategie == "C"))
  
  cat(sprintf("  Paramètres jeu : R=%.2f C=%.4f c/r=%.2f (condition: 1 < %.2f < %d)\n",
              R_JEU, C_JEU, GAMMA, C_JEU/R_JEU, n-1))
  cat(sprintf("  Complexions moy : h=%.3f | e_cog=%.3f | e_aff=%.3f [%.3f, %.3f]\n",
              mean(hs), mean(sapply(agents, `[[`, "ecog")), mean(eaffs), min(eaffs), max(eaffs)))
  cat(sprintf("  Coopérants init : %d / %d (%.1f%%)\n", n_coop, n, 100*n_coop/n))
  cat(sprintf("  Corr(rang, h)    : %.3f | Corr(rang, e_aff): %.3f\n",
              cor(rangs, hs), cor(rangs, eaffs)))
  cat(sprintf("=== Communauté n=%d prête. ===\n\n", n))
  
  list(agents=agents, g=g, n=n)
}

# =============================================================================
# LANCEMENT
# =============================================================================

tailles <- c(50, 500)

cat("\n====== WATTS-STROGATZ ======\n")
communautes_WS <- lapply(tailles, function(n) init_communaute(n, methode="WS", seed=42))
names(communautes_WS) <- paste0("n", tailles)

cat("\n====== BARABÁSI-ALBERT ======\n")
communautes_BA <- lapply(tailles, function(n) init_communaute(n, methode="BA", seed=42))
names(communautes_BA) <- paste0("n", tailles)

cat("\n=== Toutes les communautés initialisées. ===\n")