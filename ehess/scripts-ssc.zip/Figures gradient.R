# =============================================================================
# FIGURES GRADIENT DE DIFFICULTÉ — n=500, jeu collectif à N joueurs
# =============================================================================
# GAMMA ∈ (0,1) : proche de 1 = facile (c/r proche de 1)
#                  proche de 0 = difficile (c/r proche de n-1)
# c_jeu = ((n-1)*(1-GAMMA) + GAMMA) * R_JEU
# =============================================================================

source("simulation_lvl1.R")
library(ggplot2)
library(dplyr)
library(scales)

# ── Gradient resserré près de 1 — zone de transition ──
RATIOS <- seq(0.700, 0.710, by = 0.001)
N_GRAD <- 100L

# Palette dégradée vert → violet (facile → difficile, de droite à gauche)
PAL_GRAD <- setNames(
  colorRampPalette(c("#CC79A7", "#D55E00", "#E69F00", "#56B4E9", "#009E73"))(length(RATIOS)),
  as.character(RATIOS)
)

theme_sim <- function()
  theme_minimal(base_size = 12) +
  theme(panel.grid.minor = element_blank(), legend.position = "right",
        plot.title    = element_text(face = "bold", size = 13),
        plot.subtitle = element_text(size = 10, color = "grey40"))

#fonction de moyenne glissante
ma <- function(x, w = 15) {
  n <- length(x)
  result <- numeric(n)
  for (i in 1:n) {
    debut <- max(1, i - w + 1)
    result[i] <- mean(x[debut:i])
  }
  result
}

# =============================================================================
# SIMULATIONS 
# =============================================================================

cat("\n====== Gradient de difficulté — n=100 ======\n")

#Choix de la méthode WS ou BA
methode = "BA"
#methode = "WS"

comm_base <- init_communaute(N_GRAD, methode = methode, seed = 42)


resultats_grad <- lapply(RATIOS, function(gamma) {
  cat(sprintf("\n--- GAMMA = %.3f ---\n", gamma))
  
  # c/r effectif
  c_eff <- ((N_GRAD - 1) * (1 - gamma) + gamma) * R_JEU
  cat(sprintf("    c_jeu=%.3f (c/r=%.2f)\n", c_eff, c_eff / R_JEU))
  
  res <- simuler_communaute(comm_base, params = list(GAMMA = gamma, r_jeu = R_JEU))
  m   <- res$metriques
  
  cat(sprintf("    coop_fin=%.2f | eaff=%.3f | ecog=%.3f\n",
              m$taux_coop[T_MAX], m$eaff_moy[T_MAX], m$ecog_moy[T_MAX]))
  
  m$gamma_label <- as.character(gamma)
  list(metriques = m, agents = res$agents, g = res$g)  # ← stocker tout
})

df_grad <- do.call(rbind, lapply(resultats_grad, function(r) r$metriques))
df_grad$gamma_label <- factor(df_grad$gamma_label, levels = as.character(RATIOS))

# Labels lisibles : γ et c/r effectif
cr_eff <- ((N_GRAD - 1) * (1 - RATIOS) + RATIOS) / R_JEU
labels_gamma <- setNames(
  sprintf("γ=%.3f (c/r=%.1f)", RATIOS, cr_eff),
  as.character(RATIOS)
)

cat("\n=== Tracé des figures... ===\n")

# =============================================================================
# FIGURE 1 — Taux de coopération
# =============================================================================

ggplot(df_grad, aes(x = tour, y = taux_coop, color = gamma_label)) +
  geom_line(linewidth = 0.85, alpha = 0.9) +
  scale_color_manual(values = PAL_GRAD, name = "γ (difficulté)",
                     labels = labels_gamma) +
  scale_y_continuous(labels = percent, limits = c(0, 1)) +
  labs(title    = "Taux de coopération — gradient de difficulté",
       subtitle = sprintf("n=%d · méthode =%s · %d tours · jeu collectif", N_GRAD, methode, T_MAX),
       x = "Tour", y = "P(C) = K_total / n") +
  theme_sim()

# =============================================================================
# FIGURE 2 — Empathies
# =============================================================================

df_emp <- df_grad %>%
  mutate(elo = pmax(-1, eaff_moy - eaff_sd),
         ehi = pmin( 1, eaff_moy + eaff_sd))

ggplot(df_emp, aes(x = tour, color = gamma_label, fill = gamma_label)) +
  geom_ribbon(aes(ymin = elo, ymax = ehi), alpha = 0.10, color = NA) +
  geom_line(aes(y = eaff_moy), linewidth = 1.0) +
  geom_line(aes(y = ecog_moy), linewidth = 0.8, linetype = "dashed") +
  geom_hline(yintercept = 0, linetype = "dotted", color = "grey50", linewidth = 0.3) +
  scale_color_manual(values = PAL_GRAD, name = "γ", labels = labels_gamma) +
  scale_fill_manual( values = PAL_GRAD, name = "γ", labels = labels_gamma) +
  scale_y_continuous(limits = c(-1, 1)) +
  annotate("text", x = 5, y = 0.93, label = "Plein = e_aff ∈ [−1,1]",
           hjust = 0, size = 3.2, color = "grey30") +
  annotate("text", x = 5, y = 0.83, label = "Pointillé = e_cog ∈ [0,1]",
           hjust = 0, size = 3.2, color = "grey30") +
  labs(title    = "Empathies selon la difficulté du dilemme",
       subtitle = "Signal e_aff = 2·K/n − 1 · Ruban = ±1σ inter-agents",
       x = "Tour", y = "Valeur") +
  theme_sim()

# =============================================================================
# FIGURE 3 — Termes EWA, cognitif, affectif
# =============================================================================

df3 <- bind_rows(
  df_grad %>% transmute(tour, gamma_label,
                        val = tewa_moy, val_lo = tewa_moy - tewa_sd,
                        val_hi = tewa_moy + tewa_sd, terme = "EWA"),
  df_grad %>% transmute(tour, gamma_label,
                        val = tc_moy, val_lo = tc_moy - tc_sd,
                        val_hi = tc_moy + tc_sd, terme = "Cognitif"),
  df_grad %>% transmute(tour, gamma_label,
                        val = ta_moy, val_lo = ta_moy - ta_sd,
                        val_hi = ta_moy + ta_sd, terme = "Affectif")
)
df3$terme <- factor(df3$terme, levels = c("EWA","Cognitif","Affectif"))

ggplot(df3, aes(x = tour, y = val,
                color = gamma_label, fill = gamma_label, linetype = terme)) +
  geom_ribbon(aes(ymin = val_lo, ymax = val_hi), alpha = 0.08, color = NA) +
  geom_line(linewidth = 0.85) +
  geom_hline(yintercept = 0, linetype = "dotted", color = "grey50", linewidth = 0.35) +
  scale_color_manual(values = PAL_GRAD, name = "γ", labels = labels_gamma) +
  scale_fill_manual( values = PAL_GRAD, name = "γ", labels = labels_gamma) +
  scale_linetype_manual(
    values = c("EWA" = "solid", "Cognitif" = "dashed", "Affectif" = "dotted"),
    name = "Terme") +
  labs(title    = "Termes EWA (plein), Cognitif (tirets), Affectif (pointillé)",
       subtitle = "Gradient de difficulté · Ruban = ±1σ",
       x = "Tour", y = "Valeur du terme") +
  theme_sim()

# =============================================================================
# FIGURE 4 — Coopération centraux vs marginaux (MA30)
# =============================================================================

df4 <- bind_rows(
  df_grad %>% filter(!is.na(taux_coop_central)) %>%
    transmute(tour, gamma_label, taux = taux_coop_central,  groupe = "Central"),
  df_grad %>% filter(!is.na(taux_coop_marginal)) %>%
    transmute(tour, gamma_label, taux = taux_coop_marginal, groupe = "Marginal")
) %>%
  group_by(gamma_label, groupe) %>%
  mutate(taux_ma = ma(taux, 30)) %>%
  ungroup()

ggplot(df4, aes(x = tour, color = gamma_label, linetype = groupe)) +
  geom_line(aes(y = taux),    linewidth = 0.20, alpha = 0.18) +
  geom_line(aes(y = taux_ma), linewidth = 1.0,  alpha = 0.90, na.rm = TRUE) +
  scale_color_manual(values = PAL_GRAD, name = "γ", labels = labels_gamma) +
  scale_linetype_manual(
    values = c("Central" = "solid", "Marginal" = "dashed"), name = "Position") +
  scale_y_continuous(labels = percent, limits = c(0, 1)) +
  labs(title    = "Coopération : centraux vs marginaux",
       subtitle = "Trait fin = brut · trait épais = MA30",
       x = "Tour", y = "P(C)") +
  theme_sim()

# =============================================================================
# FIGURE 5 — Poids total du réseau
# =============================================================================

ggplot(df_grad, aes(x = tour, y = w_total, color = gamma_label)) +
  geom_line(linewidth = 0.85, alpha = 0.9) +
  scale_color_manual(values = PAL_GRAD, name = "γ", labels = labels_gamma) +
  labs(title    = "Poids total du réseau",
       subtitle = "Renforcement si coop. mutuelle · dégradation si trahison",
       x = "Tour", y = "Σ w_ij") +
  theme_sim()

# =============================================================================
# FIGURE 6 — Force des liens : centraux vs marginaux
# =============================================================================

bind_rows(
  df_grad %>% filter(!is.na(w_central_moy)) %>%
    transmute(tour, gamma_label, w = w_central_moy,  groupe = "Central"),
  df_grad %>% filter(!is.na(w_marginal_moy)) %>%
    transmute(tour, gamma_label, w = w_marginal_moy, groupe = "Marginal")
) %>%
  ggplot(aes(x = tour, y = w, color = gamma_label, linetype = groupe)) +
  geom_line(linewidth = 0.85, alpha = 0.85) +
  scale_color_manual(values = PAL_GRAD, name = "γ", labels = labels_gamma) +
  scale_linetype_manual(
    values = c("Central" = "solid", "Marginal" = "dashed"), name = "Position") +
  labs(title    = "Force moyenne des liens — centraux vs marginaux",
       subtitle = "Selon la difficulté du dilemme",
       x = "Tour", y = "Poids moyen w_ij") +
  theme_sim()

# =============================================================================
# FIGURE 7 — P(C) stationnaire en fonction de gamma (courbe de transition)
# =============================================================================

df_stat <- df_grad %>%
  group_by(gamma_label) %>%
  summarise(
    gamma     = as.numeric(as.character(gamma_label[1])),
    coop_stat = mean(taux_coop[max(1, T_MAX-49):T_MAX]),
    coop_sd   = sd(taux_coop[max(1, T_MAX-49):T_MAX]),
    .groups = "drop"
  )

ggplot(df_stat, aes(x = gamma, y = coop_stat)) +
  geom_ribbon(aes(ymin = pmax(0, coop_stat - coop_sd),
                  ymax = pmin(1, coop_stat + coop_sd)),
              alpha = 0.15, fill = "#0072B2") +
  geom_line(color = "#0072B2", linewidth = 1.2) +
  geom_point(color = "#0072B2", size = 2.5) +
  scale_y_continuous(labels = percent, limits = c(0, 1)) +
  scale_x_continuous(breaks = RATIOS, labels = round(RATIOS, 3)) +
  labs(title    = "Courbe de transition — P(C) stationnaire vs γ",
       subtitle = "Ruban = ±1σ sur les 50 derniers tours · transition de phase ?",
       x = "γ (difficulté)", y = "P(C) stat.") +
  theme_sim() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

cat(sprintf("\n=== 7 figures tracées — %d valeurs de γ : [%.3f, %.3f] ===\n",
            length(RATIOS), min(RATIOS), max(RATIOS)))

# # =============================================================================
# # FIGURE 8 — Scatter agents : betweenness × e_aff × coopération
# # =============================================================================
# 
# library(ggplot2)
# library(igraph)
# 
# plots_fig8 <- list()
# 
# #On trace pour tous les gammas
# for(idx_gamma in 1:length(resultats_grad)){
# 
#   gamma_val <- RATIOS[idx_gamma]
#   g_fin   <- resultats_grad[[idx_gamma]]$g
#   W_total <- sum(E(g_fin)$weight)
#   w_moy   <- W_total / max(ecount(g_fin), 1)
#   
#   agents_base <- comm_base$agents
#   agents_fin  <- resultats_grad[[idx_gamma]]$agents
#   n           <- comm_base$n
#   
#   c_eff <- ((n - 1) * (1 - gamma_val) + gamma_val) * R_JEU
#   
#   btw <- betweenness(comm_base$g, normalized = TRUE)
#   
#   df_agents <- data.frame(
#     id     = 1:n,
#     rang   = sapply(agents_base, `[[`, "rang"),
#     btw    = btw,
#     h      = sapply(agents_fin,  `[[`, "h"),
#     ecog   = sapply(agents_fin,  `[[`, "ecog"),
#     eaff   = sapply(agents_fin,  `[[`, "eaff"),
#     coop   = sapply(agents_fin,  function(a) as.numeric(a$strategie == "C")),
#     p_coop = sapply(seq_along(agents_fin), function(id) {
#       ag       <- agents_fin[[id]]
#       v        <- ag$voisins
#       lambda_i <- LAMBDA_BAR * ag$h
#       delta_A  <- ag$A_C - ag$A_D
#       tc <- if (length(v) > 0)
#         MU_BAR * ag$ecog * (mean(sapply(seq_along(v), function(k) sum(ag$B_ij[k,] * THETA))) * R_JEU - c_eff / n)
#       else 0
#       ta <- NU_BAR * ag$eaff * mean(ag$poids) / max(w_moy, 1e-12)
#       1 / (1 + exp(-lambda_i * delta_A - tc - ta))
#     })
#   )
#   
#   
#   
#   plots_fig8[[idx_gamma]] <- ggplot(df_agents, aes(x = rang, y = eaff)) +
#     geom_point(aes(size = btw, color = p_coop), alpha = 0.75) +
#     scale_color_gradient2(
#       low      = "#D55E00",
#       mid      = "#F0E442",
#       high     = "#009E73",
#       midpoint = 0.5,
#       name     = "P(C) estimée"
#     ) +
#     scale_size_continuous(
#       range = c(1, 8),
#       name  = "betweenness"
#     ) +
#     geom_hline(yintercept = 0, linetype = "dotted", color = "grey50") +
#     labs(
#       title    = sprintf("Agents — γ = %.3f (c/r = %.1f)", gamma_val, c_eff),
#       subtitle = "x = rang centralité · y = e_aff final · taille = betweenness · couleur = P(C)",
#       x        = "Rang r_i  (0 = central · 1 = marginal)",
#       y        = "e_aff final"
#     ) +
#     theme_minimal(base_size = 12) +
#     theme(panel.grid.minor = element_blank())
#   
# }
# 
# # Afficher après
# for (p in plots_fig8) print(p)
# 
# # # Ou sauvegarder en PDF
# # pdf("figures_agents.pdf", width = 12, height = 8)
# # for (p in plots_fig8) print(p)
# # dev.off()
# 
# # =============================================================================
# # FIGURE 9 — Réseau
# # =============================================================================
# 
# library(ggraph)
# library(igraph)
# 
# plots_fig9 <- list()
# 
# #On trace pour tous les gammas
# for(idx_gamma in 1:length(resultats_grad)){
#   
#   gamma_val <- RATIOS[idx_gamma]
#   g_fin   <- resultats_grad[[idx_gamma]]$g
#   W_total <- sum(E(g_fin)$weight)
#   w_moy   <- W_total / max(ecount(g_fin), 1)
#   
#   agents_fin <- resultats_grad[[idx_gamma]]$agents
#   g_fin      <- resultats_grad[[idx_gamma]]$g
#   n           <- comm_base$n
#   
#   c_eff <- ((n - 1) * (1 - gamma_val) + gamma_val) * R_JEU
#   
#   btw_fixe <- betweenness(comm_base$g, normalized = TRUE)
#   btw_range <- range(btw_fixe)
#   
#   # Attributs des nœuds
#   V(g_fin)$coop   <- sapply(agents_fin, function(a) as.numeric(a$strategie == "C"))
#   V(g_fin)$p_coop = sapply(seq_along(agents_fin), function(id) {
#     ag       <- agents_fin[[id]]
#     v        <- ag$voisins
#     lambda_i <- LAMBDA_BAR * ag$h
#     delta_A  <- ag$A_C - ag$A_D
#     tc <- if (length(v) > 0)
#       MU_BAR * ag$ecog * (mean(sapply(seq_along(v), function(k) sum(ag$B_ij[k,] * THETA))) * R_JEU - c_eff / n)
#     else 0
#     ta <- NU_BAR * ag$eaff * mean(ag$poids) / max(w_moy, 1e-12)
#     1 / (1 + exp(-lambda_i * delta_A - tc - ta))
#   })
#   V(g_fin)$eaff   <- sapply(agents_fin, `[[`, "eaff")
#   V(g_fin)$rang   <- sapply(agents_fin, `[[`, "rang")
#   V(g_fin)$btw <- btw_fixe
#   
#   # Layout
#   set.seed(42)
#   layout_g <- create_layout(g_fin, layout = "fr")   # Fruchterman-Reingold
#   
#   plots_fig9[[idx_gamma]] <- ggraph(layout_g) +
#     # Liens : épaisseur = poids, couleur = gris
#     geom_edge_link(aes(width = weight, alpha = weight),
#                    color = "grey60") +
#     scale_edge_width_continuous(range = c(0.2, 2.5), guide = "none") +
#     scale_edge_alpha_continuous(range = c(0.1, 0.6), guide = "none") +
#     # Nœuds : couleur = p_coop, taille = betweenness
#     geom_node_point(aes(color = p_coop, size = btw + 0.01)) +
#     scale_color_gradient2(
#       low      = "#D55E00",
#       mid      = "#F0E442",
#       high     = "#009E73",
#       midpoint = 0.5,
#       name     = "P(C)"
#     ) +
#     scale_size_continuous(range = c(0.5, 10),limits = btw_range, guide = "none") +
#     labs(
#       title    = sprintf("Topologie du réseau — γ = %.3f", gamma_val),
#       subtitle = "Épaisseur liens = poids · Taille nœuds = betweenness · Couleur = propension à coopérer"
#     ) +
#     theme_void(base_size = 12) +
#     theme(
#       plot.title    = element_text(face = "bold", size = 13),
#       plot.subtitle = element_text(size = 10, color = "grey40"),
#       legend.position = "right"
#     )
#   
# }
# 
# # Afficher après
# for (p in plots_fig9) print(p)
# 
# # # Ou sauvegarder en PDF
# # pdf("figures_agents_scatter.pdf", width = 12, height = 8)
# # for (p in plots_fig9) print(p)
# # dev.off()